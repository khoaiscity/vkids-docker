-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 08, 2020 at 09:20 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_vkids_duy`
--

-- --------------------------------------------------------

--
-- Table structure for table `activation_code`
--

CREATE TABLE `activation_code` (
  `id` int(10) UNSIGNED NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `price` double DEFAULT NULL,
  `stuff_information` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activation_code`
--

INSERT INTO `activation_code` (`id`, `member_id`, `code`, `status`, `created_at`, `updated_at`, `price`, `stuff_information`) VALUES
(1, 2, 'VKDC-D136-5H7D-Y3NX', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(2, 2, 'VKIV-2754-NFX5-H5MG', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(3, 2, 'VKXJ-QTP6-N7MS-G53Q', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(4, 2, 'VKME-QTLQ-DBR8-7KTK', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(5, 2, 'VK8Q-W2AT-IQL9-K78E', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(6, 2, 'VK5Y-2CRI-85ZV-QDX4', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(7, 2, 'VKDL-9KBA-QIYH-JC9D', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(8, 2, 'VKFM-4216-GHVG-QQR1', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(9, 2, 'VKKL-X61D-5KT6-SYP1', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(10, 2, 'VKF4-F611-DFZS-K81A', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(11, 2, 'VKG2-BNKU-LZRS-ZARH', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(12, 2, 'VKR9-HCWT-KZY6-G8PQ', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(13, 2, 'VK2F-G2CB-57NC-2KV4', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(14, 2, 'VKL6-TUPL-DKWC-7UZR', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(15, 2, 'VK8N-9VHH-XZQQ-AER9', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(16, 2, 'VKNK-6RL4-WJVM-NCG2', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(17, 2, 'VKSS-UR11-MEQ8-PSBK', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(18, 2, 'VKG2-PW22-T1GV-8LKL', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(19, 2, 'VKTX-ZU5L-KR8Z-57LH', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(20, 2, 'VKUX-1KWN-UHI4-XGII', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(21, 2, 'VKKJ-NJCV-EMNJ-P5DY', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(22, 2, 'VKRU-7CNQ-5I6T-VZ22', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(23, 2, 'VKK7-CAIM-S2V8-U8EZ', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(24, 2, 'VK78-M595-BTMQ-YT71', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(25, 2, 'VKMJ-WX7K-D6DP-GKZZ', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(26, 2, 'VKQ4-G7UE-TZ4R-8AGE', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(27, 2, 'VKAB-M3KH-KIZR-2DKF', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(28, 2, 'VKMI-IQXA-TZ2U-RCSE', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(29, 2, 'VKSK-F5YB-VY8W-42GC', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(30, 2, 'VKT3-7LFU-QR86-ZQ9J', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(31, 2, 'VK4J-TDX7-Y7YG-YBZH', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(32, 2, 'VK9U-JM1J-9WQ7-2449', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(33, 2, 'VK56-R3W5-6CD5-3K58', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(34, 2, 'VKW5-HNWQ-CZFE-F6IF', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(35, 2, 'VKKP-ZG3X-KP5M-DEYD', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(36, 2, 'VKX1-1PQH-N41T-1EE9', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(37, 2, 'VKMU-1CA5-PG5F-LBC6', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(38, 2, 'VKQQ-BDVG-9LTD-5NMS', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(39, 2, 'VKDC-TYDR-XNKG-RHWW', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(40, 2, 'VK9T-CNGZ-BAI6-MJJE', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(41, 2, 'VKMY-LD2W-V22Z-929B', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(42, 2, 'VK5T-5PQP-KUQF-KBLW', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(43, 2, 'VKY2-4TD2-63P8-768W', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(44, 2, 'VKG1-1U4N-71KW-E2FF', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(45, 2, 'VKH1-WXQ8-G8ZV-AF2U', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(46, 2, 'VKRX-INZF-S8NA-BNGA', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(47, 2, 'VKGK-P89I-DS77-CQPQ', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(48, 2, 'VK6Z-ZKTN-QFDG-8HVT', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(49, 2, 'VKT3-DVBQ-VBRG-Q9WY', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(50, 2, 'VK6C-NDJC-B62J-KHTP', 'I', '2020-01-08 10:19:30', NULL, 388, ''),
(51, 14, 'VKL9-KL6C-I734-6N6G', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(52, 14, 'VKN2-SAPX-K96M-FWXQ', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(53, 14, 'VK4P-FHN4-KXSJ-ENFD', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(54, 14, 'VKBP-88PD-6HD7-JZ24', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(55, 14, 'VKQN-P1A5-JU5D-58JJ', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(56, 14, 'VKE8-7ND1-1PZD-J1N4', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(57, 14, 'VKP5-4X9Q-1SMZ-XSM4', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(58, 14, 'VKQV-JKWU-YQYT-8Y72', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(59, 14, 'VKES-KD94-GJQ2-FSRX', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(60, 14, 'VK5Y-RH3X-MKL7-6SP9', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(61, 14, 'VKD8-SSEJ-8EEC-VITY', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(62, 14, 'VKBA-RZ49-1WDG-ABJG', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(63, 14, 'VKBZ-XQMN-HL2Y-JXY4', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(64, 14, 'VKFY-T6P1-MCHL-MAMR', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(65, 14, 'VK4H-N3D4-JIAM-E38J', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(66, 14, 'VKJV-QBIY-EE2H-NDAY', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(67, 14, 'VKFL-YREL-7DCF-ERR1', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(68, 14, 'VKU5-R6BJ-K513-HT5P', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(69, 14, 'VKPD-1BHA-RBB4-GKNZ', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(70, 14, 'VKYT-VB75-HDJJ-53VH', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(71, 14, 'VK1S-664D-4Q2W-XRWS', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(72, 14, 'VKVE-DRCU-B6PU-K1IA', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(73, 14, 'VKPA-JG6N-YALV-ED17', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(74, 14, 'VKI5-NTSD-DEPX-NDM1', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(75, 22, 'VKPJ-WCV9-ETBR-Y9JL', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(76, 22, 'VKDV-76MI-DECE-VMRA', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(77, 22, 'VKQ4-1UBR-H9XP-LPGI', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(78, 22, 'VK63-YKJB-7A2A-WXJ2', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(79, 22, 'VKYJ-VARD-PHS2-ENER', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(80, 22, 'VK49-EHRL-VDKH-BXMM', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(81, 22, 'VK8L-UIHK-SN2U-L2X2', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(82, 22, 'VKKW-YY1F-H37L-GWHL', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(83, 22, 'VKGQ-WDMY-3X9S-6K8T', 'I', '2020-01-08 10:19:31', NULL, 388, ''),
(84, 26, 'VKBP-LCLZ-9AY6-3F6Y', 'I', '2020-01-08 10:19:32', NULL, 388, '');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `company_code` varchar(30) DEFAULT NULL,
  `location_id` longtext,
  `user_group_id` int(11) DEFAULT '0',
  `nick_name` varchar(100) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL,
  `path` varchar(100) DEFAULT NULL,
  `remember_token` longtext,
  `t_set_mode` tinyint(4) DEFAULT '0' COMMENT 'translation manager setting',
  `t_set_enter_to_save` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'translation manager setting',
  `t_set_auto_save` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'translation manager setting',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `country_id`, `company_id`, `company_code`, `location_id`, `user_group_id`, `nick_name`, `name`, `email`, `password`, `status`, `avatar`, `path`, `remember_token`, `t_set_mode`, `t_set_enter_to_save`, `t_set_auto_save`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 0, 0, NULL, NULL, 1, 'dev', 'Admin', 'admin@iscity.com.my', '$2a$10$.2GdxBz4vkk75yJHMFjvBe9T5D1WDvsH5w4YozYFswpfTgEvuCRYK', 'A', '', '', '', 0, 1, 1, 1, '2020-01-01 00:00:00', NULL, NULL),
(2, 0, 0, NULL, NULL, 2, 'admin', 'Luong Den', 'den@iscity.com.my', '$2a$10$y/laxUuyqZv0b2ZDmTUMBuEbOpHMStCvJo.k45yO5k7O322mDZJdG', 'A', '', NULL, NULL, 0, 1, 1, 1, '2020-01-08 10:19:27', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admins_2fa`
--

CREATE TABLE `admins_2fa` (
  `id` int(11) NOT NULL,
  `admins_id` int(11) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `codeurl` varchar(255) NOT NULL,
  `b_enable` tinyint(1) NOT NULL COMMENT '0 = off, 1=on',
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_password_resets`
--

CREATE TABLE `admin_password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `album_photo`
--

CREATE TABLE `album_photo` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `cover` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `album_video`
--

CREATE TABLE `album_video` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `cover` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `blockchain_tran`
--

CREATE TABLE `blockchain_tran` (
  `id` int(11) NOT NULL,
  `crypto_from` varchar(255) NOT NULL,
  `crypto_to` varchar(255) NOT NULL,
  `amount` decimal(25,10) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `api_type` varchar(50) NOT NULL,
  `method` varchar(25) DEFAULT NULL,
  `url_link` varchar(255) NOT NULL,
  `data_sent` varchar(255) DEFAULT NULL,
  `data_received` varchar(255) DEFAULT NULL,
  `server_data` varchar(255) DEFAULT NULL,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bonus_detail`
--

CREATE TABLE `bonus_detail` (
  `bonus_id` int(10) UNSIGNED NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `invoice_code` varchar(255) DEFAULT NULL,
  `bonus_type` varchar(255) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `wallet_type_id` int(11) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_entity`
--

CREATE TABLE `catalog_category_entity` (
  `entity_id` int(10) UNSIGNED NOT NULL,
  `attribute_set_id` int(11) DEFAULT NULL,
  `children_count` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_entity_int`
--

CREATE TABLE `catalog_category_entity_int` (
  `value_id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_entity_text`
--

CREATE TABLE `catalog_category_entity_text` (
  `value_id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_image`
--

CREATE TABLE `catalog_category_image` (
  `id` int(10) UNSIGNED NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `width` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `catalog_category_product`
--

CREATE TABLE `catalog_category_product` (
  `entity_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_datetime`
--

CREATE TABLE `catalog_product_entity_datetime` (
  `value_id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `value` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_decimal`
--

CREATE TABLE `catalog_product_entity_decimal` (
  `value_id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `value` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_entity_decimal`
--

INSERT INTO `catalog_product_entity_decimal` (`value_id`, `attribute_id`, `entity_id`, `store_id`, `value`) VALUES
(1, 12, 1, 0, 0),
(2, 13, 1, 0, 0),
(3, 14, 1, 0, 0),
(4, 15, 1, 0, 0),
(5, 26, 1, 0, 388),
(6, 12, 2, 0, 0),
(7, 13, 2, 0, 0),
(8, 14, 2, 0, 0),
(9, 15, 2, 0, 0),
(10, 26, 2, 0, 388),
(11, 12, 3, 0, 0),
(12, 13, 3, 0, 0),
(13, 14, 3, 0, 0),
(14, 15, 3, 0, 0),
(15, 26, 3, 0, 388),
(16, 12, 4, 0, 0),
(17, 13, 4, 0, 0),
(18, 14, 4, 0, 0),
(19, 15, 4, 0, 0),
(20, 26, 4, 0, 388),
(21, 12, 5, 0, 0),
(22, 13, 5, 0, 0),
(23, 14, 5, 0, 0),
(24, 15, 5, 0, 0),
(25, 26, 5, 0, 388),
(26, 12, 6, 0, 0),
(27, 13, 6, 0, 0),
(28, 14, 6, 0, 0),
(29, 15, 6, 0, 0),
(30, 26, 6, 0, 388),
(31, 12, 7, 0, 0),
(32, 13, 7, 0, 0),
(33, 14, 7, 0, 0),
(34, 15, 7, 0, 0),
(35, 26, 7, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_int`
--

CREATE TABLE `catalog_product_entity_int` (
  `value_id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_entity_int`
--

INSERT INTO `catalog_product_entity_int` (`value_id`, `attribute_id`, `entity_id`, `store_id`, `value`) VALUES
(1, 16, 1, 0, 1),
(2, 17, 1, 0, 0),
(3, 18, 1, 0, 1),
(4, 19, 1, 0, 1),
(5, 20, 1, 0, 0),
(6, 21, 1, 0, 0),
(7, 22, 1, 0, 0),
(8, 23, 1, 0, 0),
(9, 25, 1, 0, 1),
(10, 24, 1, 0, 1),
(11, 16, 2, 0, 3),
(12, 17, 2, 0, 0),
(13, 18, 2, 0, 1),
(14, 19, 2, 0, 1),
(15, 20, 2, 0, 0),
(16, 21, 2, 0, 0),
(17, 22, 2, 0, 0),
(18, 23, 2, 0, 0),
(19, 25, 2, 0, 9),
(20, 24, 2, 0, 2),
(21, 16, 3, 0, 7),
(22, 17, 3, 0, 0),
(23, 18, 3, 0, 1),
(24, 19, 3, 0, 1),
(25, 20, 3, 0, 0),
(26, 21, 3, 0, 0),
(27, 22, 3, 0, 0),
(28, 23, 3, 0, 0),
(29, 25, 3, 0, 24),
(30, 24, 3, 0, 3),
(31, 16, 4, 0, 11),
(32, 17, 4, 0, 0),
(33, 18, 4, 0, 1),
(34, 19, 4, 0, 1),
(35, 20, 4, 0, 0),
(36, 21, 4, 0, 0),
(37, 22, 4, 0, 0),
(38, 23, 4, 0, 0),
(39, 25, 4, 0, 50),
(40, 24, 4, 0, 4),
(41, 16, 5, 0, 0),
(42, 17, 5, 0, 0),
(43, 18, 5, 0, 1),
(44, 19, 5, 0, 0),
(45, 20, 5, 0, 0),
(46, 21, 5, 0, 0),
(47, 22, 5, 0, 0),
(48, 23, 5, 0, 0),
(49, 25, 5, 0, 0),
(50, 16, 6, 0, 0),
(51, 17, 6, 0, 0),
(52, 18, 6, 0, 1),
(53, 19, 6, 0, 0),
(54, 20, 6, 0, 0),
(55, 21, 6, 0, 0),
(56, 22, 6, 0, 0),
(57, 23, 6, 0, 0),
(58, 25, 6, 0, 0),
(59, 16, 7, 0, 0),
(60, 17, 7, 0, 0),
(61, 18, 7, 0, 0),
(62, 19, 7, 0, 0),
(63, 20, 7, 0, 1),
(64, 21, 7, 0, 0),
(65, 22, 7, 0, 0),
(66, 23, 7, 0, 0),
(67, 25, 7, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_entity_text`
--

CREATE TABLE `catalog_product_entity_text` (
  `value_id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_entity_text`
--

INSERT INTO `catalog_product_entity_text` (`value_id`, `attribute_id`, `entity_id`, `store_id`, `value`) VALUES
(1, 10, 1, 2, 'V-User'),
(2, 10, 1, 3, 'V-User (zh)'),
(3, 10, 1, 1, 'V-User (my)'),
(4, 11, 1, 2, 'Lorem Ipsum is simply dummy text'),
(5, 11, 1, 3, 'Lorem Ipsum只是假文字'),
(6, 11, 1, 1, 'Lorem Ipsum is simply dummy text'),
(7, 10, 2, 2, 'V-Pro'),
(8, 10, 2, 3, 'V-Pro (zh)'),
(9, 10, 2, 1, 'V-Pro (my)'),
(10, 11, 2, 2, 'Lorem Ipsum is simply dummy text'),
(11, 11, 2, 3, 'Lorem Ipsum只是假文字'),
(12, 11, 2, 1, 'Lorem Ipsum hanya teks dummy'),
(13, 10, 3, 2, 'V-Master'),
(14, 10, 3, 3, 'V-Master (zh)'),
(15, 10, 3, 1, 'V-Master (my)'),
(16, 11, 3, 2, 'Lorem Ipsum is simply dummy text'),
(17, 11, 3, 3, 'Lorem Ipsum只是假文字'),
(18, 11, 3, 1, 'Lorem Ipsum is simply dummy text'),
(19, 10, 4, 2, 'V-Expert'),
(20, 10, 4, 3, 'V-Expert (zh)'),
(21, 10, 4, 1, 'V-Exprt (my)'),
(22, 11, 4, 2, 'Lorem Ipsum is simply dummy text'),
(23, 11, 4, 3, 'Lorem Ipsum只是假文字'),
(24, 11, 4, 1, 'Lorem Ipsum is simply dummy text'),
(25, 10, 5, 2, 'Special Package 1'),
(26, 10, 5, 3, 'Special Package 1 (zh)'),
(27, 10, 5, 1, 'Special Package 1 (my)'),
(28, 11, 5, 2, 'Lorem Ipsum is simply dummy text'),
(29, 11, 5, 3, 'Lorem Ipsum只是假文字'),
(30, 11, 5, 1, 'Lorem Ipsum is simply dummy text'),
(31, 10, 6, 2, 'Special Package 2'),
(32, 10, 6, 3, 'Special Package 2 (zh)'),
(33, 10, 6, 1, 'Special Package 2 (my)'),
(34, 11, 6, 2, 'Lorem Ipsum is simply dummy text'),
(35, 11, 6, 3, 'Lorem Ipsum只是假文字'),
(36, 11, 6, 1, 'Lorem Ipsum is simply dummy text'),
(37, 10, 7, 2, 'Maintenance Package'),
(38, 10, 7, 3, 'Maintenance Package (zh)'),
(39, 10, 7, 1, 'Maintenance Package (my)'),
(40, 11, 7, 2, 'Lorem Ipsum is simply dummy text'),
(41, 11, 7, 3, 'Lorem Ipsum只是假文字'),
(42, 11, 7, 1, 'Lorem Ipsum is simply dummy text');

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_index_price`
--

CREATE TABLE `catalog_product_index_price` (
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `customer_group_id` int(10) UNSIGNED DEFAULT NULL,
  `price` double DEFAULT NULL,
  `bv` double DEFAULT NULL,
  `pv` double DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `catalog_product_index_price`
--

INSERT INTO `catalog_product_index_price` (`entity_id`, `customer_group_id`, `price`, `bv`, `pv`, `status`) VALUES
(1, 1, 388, 90, 0, ''),
(1, 2, 388, 90, 0, ''),
(1, 3, 388, 90, 0, ''),
(2, 1, 2388, 550, 0, ''),
(2, 2, 2388, 550, 0, ''),
(2, 3, 2388, 550, 0, ''),
(3, 1, 5788, 1400, 0, ''),
(3, 2, 5788, 1400, 0, ''),
(3, 3, 5788, 1400, 0, ''),
(4, 1, 10888, 2600, 0, ''),
(4, 2, 10888, 2600, 0, ''),
(4, 3, 10888, 2600, 0, ''),
(5, 1, 3888, 1000, 0, ''),
(5, 2, 3888, 1000, 0, ''),
(5, 3, 3888, 1000, 0, ''),
(6, 1, 6888, 2000, 0, ''),
(6, 2, 6888, 2000, 0, ''),
(6, 3, 6888, 2000, 0, ''),
(7, 1, 198, 75, 0, ''),
(7, 2, 198, 75, 0, ''),
(7, 3, 198, 75, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_promote_price`
--

CREATE TABLE `catalog_product_promote_price` (
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `customer_group_id` int(10) UNSIGNED DEFAULT NULL,
  `from_date` int(11) DEFAULT NULL,
  `to_date` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `bv` double DEFAULT NULL,
  `pv` double DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `catalog_product_sku`
--

CREATE TABLE `catalog_product_sku` (
  `entity_id` int(11) DEFAULT NULL,
  `sku_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cms_page`
--

CREATE TABLE `cms_page` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_code` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cms_page`
--

INSERT INTO `cms_page` (`id`, `page_code`) VALUES
(1, 'admin_sku_code_list');

-- --------------------------------------------------------

--
-- Table structure for table `cms_page_filter`
--

CREATE TABLE `cms_page_filter` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(11) DEFAULT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `column_name` varchar(255) DEFAULT NULL,
  `frontend_field` varchar(255) DEFAULT NULL,
  `backend_field` varchar(255) DEFAULT NULL,
  `database_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cms_page_filter`
--

INSERT INTO `cms_page_filter` (`id`, `page_id`, `table_name`, `column_name`, `frontend_field`, `backend_field`, `database_type`) VALUES
(1, 1, 'sku_code', 'sku_code', 'sku', 'FilterSku', 'string'),
(2, 1, 'sku_code', 'product_name', 'product-name', 'FilterProductName', 'string');

-- --------------------------------------------------------

--
-- Table structure for table `connection`
--

CREATE TABLE `connection` (
  `id` int(11) NOT NULL,
  `token` longtext NOT NULL,
  `member_id` int(11) NOT NULL,
  `connection_code` varchar(255) DEFAULT NULL,
  `company_code` varchar(25) DEFAULT NULL,
  `mobile_user_id` varchar(25) DEFAULT NULL,
  `activation_code` varchar(25) DEFAULT NULL,
  `device` varchar(50) DEFAULT NULL,
  `os` varchar(25) DEFAULT NULL,
  `os_version` varchar(25) DEFAULT NULL,
  `apps_version` varchar(25) DEFAULT NULL,
  `pn_enable` tinyint(1) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `contacts_audit`
--

CREATE TABLE `contacts_audit` (
  `id` int(11) NOT NULL,
  `t_text` varchar(255) NOT NULL,
  `t_value` varchar(255) NOT NULL,
  `contact_id` varchar(25) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `crypto_addr`
--

CREATE TABLE `crypto_addr` (
  `id` int(11) NOT NULL,
  `crypto_addr` varchar(255) NOT NULL,
  `encrypted_crypto_addr` text NOT NULL COMMENT 'All the crypto address is changed to lower case before the conversion.',
  `member_id` int(25) DEFAULT NULL,
  `ewt_type_id` int(25) DEFAULT NULL,
  `qrcode_url` text,
  `dt_get_addr` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer_group`
--

CREATE TABLE `customer_group` (
  `customer_group_id` int(10) UNSIGNED NOT NULL,
  `customer_group_code` varchar(255) DEFAULT NULL,
  `customer_group_name` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_group`
--

INSERT INTO `customer_group` (`customer_group_id`, `customer_group_code`, `customer_group_name`, `is_default`) VALUES
(1, 'MY', 'Malaysia (MYR)', 1),
(2, 'SG', 'Singapore (SGD)', 0),
(3, 'TH', 'Thailand', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_group_product`
--

CREATE TABLE `customer_group_product` (
  `entity_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `customer_group_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_group_product`
--

INSERT INTO `customer_group_product` (`entity_id`, `product_id`, `customer_group_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 2, 1),
(5, 2, 2),
(6, 2, 3),
(7, 3, 1),
(8, 3, 2),
(9, 3, 3),
(10, 4, 1),
(11, 4, 2),
(12, 4, 3),
(13, 5, 1),
(14, 5, 2),
(15, 5, 3),
(16, 6, 1),
(17, 6, 2),
(18, 6, 3),
(19, 7, 1),
(20, 7, 2),
(21, 7, 3);

-- --------------------------------------------------------

--
-- Table structure for table `dl_list_category`
--

CREATE TABLE `dl_list_category` (
  `id` int(11) NOT NULL,
  `category` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `b_show` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dl_list_category`
--

INSERT INTO `dl_list_category` (`id`, `category`, `name`, `b_show`) VALUES
(1, 'picture', 'Picture', 1),
(2, 'pdf', 'PDF', 1),
(3, 'video', 'Video', 1);

-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute`
--

CREATE TABLE `eav_attribute` (
  `attribute_id` int(10) UNSIGNED NOT NULL,
  `attribute_code` varchar(255) DEFAULT NULL,
  `entity_type_id` int(11) DEFAULT NULL,
  `backend_model` varchar(255) DEFAULT NULL,
  `backend_field` varchar(255) DEFAULT NULL,
  `backend_type` varchar(255) DEFAULT NULL,
  `backend_table` varchar(255) DEFAULT NULL,
  `frontend_input` varchar(255) DEFAULT NULL,
  `frontend_label` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `backend_gateway` varchar(255) DEFAULT NULL,
  `response_field` varchar(255) DEFAULT NULL,
  `is_required` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_attribute`
--

INSERT INTO `eav_attribute` (`attribute_id`, `attribute_code`, `entity_type_id`, `backend_model`, `backend_field`, `backend_type`, `backend_table`, `frontend_input`, `frontend_label`, `note`, `backend_gateway`, `response_field`, `is_required`) VALUES
(1, 'title', 1, 'SimpleProduct', 'Title', 'string', 'catalog_product_entity_text', 'title', 'Title', '', '[]Title|', '[]Title|', 1),
(2, 'description', 1, 'SimpleProduct', 'Description', 'string', 'catalog_product_entity_text', 'description', 'Description', '', '[]Description|', '[]Description|', 1),
(3, 'weight', 1, 'SimpleProduct', 'Weight', 'float32', 'catalog_product_entity_decimal', 'weight', 'Weight', '', 'Weight', 'Weight', 1),
(4, 'dimension_depth', 1, 'SimpleProduct', '{}Dimension.D', 'float32', 'catalog_product_entity_decimal', 'dimension', 'Dimension Depth', '', '{}Dimension.D', '{}Dimension|Dimension.D', 1),
(5, 'dimension_width', 1, 'SimpleProduct', '{}Dimension.W', 'float32', 'catalog_product_entity_decimal', 'dimension', 'Dimension Width', '', '{}Dimension.W', '{}Dimension|Dimension.W', 1),
(6, 'dimension_height', 1, 'SimpleProduct', '{}Dimension.H', 'float32', 'catalog_product_entity_decimal', 'dimension', 'Dimension Height', '', '{}Dimension.H', '{}Dimension|Dimension.H', 1),
(7, 'public_shop', 1, 'SimpleProduct', 'PublicShop', 'bool', 'catalog_product_entity_int', 'public_shop', 'Public Shop', '', 'PublicShop', 'PublicShop', 1),
(8, 'member_only', 1, 'SimpleProduct', 'MemberOnly', 'bool', 'catalog_product_entity_int', 'member_only', 'Member Only', '', 'MemberOnly', 'MemberOnly', 1),
(9, 'admin_only', 1, 'SimpleProduct', 'AdminOnly', 'bool', 'catalog_product_entity_int', 'admin_only', 'Admin Only', '', 'AdminOnly', 'AdminOnly', 1),
(10, 'title', 1, 'RegistrationPackage', 'Title', 'string', 'catalog_product_entity_text', '[]title|', 'Title', '', '[]Title|', '[]Title|', 1),
(11, 'description', 1, 'RegistrationPackage', 'Description', 'string', 'catalog_product_entity_text', '[]description|', 'Description', '', '[]Description|', '[]Description|', 1),
(12, 'weight', 1, 'RegistrationPackage', 'Weight', 'float32', 'catalog_product_entity_decimal', 'weight', 'Weight', '', 'Weight', 'Weight', 1),
(13, 'dimension_depth', 1, 'RegistrationPackage', '{}Dimension.D', 'float32', 'catalog_product_entity_decimal', '{}dimension.d', 'Dimension Depth', '', '{}Dimension.D', '{}Dimension|Dimension.D', 1),
(14, 'dimension_width', 1, 'RegistrationPackage', '{}Dimension.W', 'float32', 'catalog_product_entity_decimal', '{}dimension.w', 'Dimension Width', '', '{}Dimension.W', '{}Dimension|Dimension.W', 1),
(15, 'dimension_height', 1, 'RegistrationPackage', '{}Dimension.H', 'float32', 'catalog_product_entity_decimal', '{}dimension.h', 'Dimension Height', '', '{}Dimension.H', '{}Dimension|Dimension.H', 1),
(16, 'member_of_lot', 1, 'RegistrationPackage', 'MemberOfLot', 'int', 'catalog_product_entity_int', 'member_of_lot', 'Member of Lot', '{\"MultiStore\":false}', 'MemberOfLot', 'MemberOfLot', 1),
(17, 'rank', 1, 'RegistrationPackage', 'Rank', 'int', 'catalog_product_entity_int', 'rank', 'Rank', '', 'Rank', 'Rank', 1),
(18, 'registration', 1, 'RegistrationPackage', 'Registration', 'bool', 'catalog_product_entity_int', '[]package_plan|registration', 'Registration', '', 'Registration', 'Registration', 1),
(19, 'upgrade', 1, 'RegistrationPackage', 'Upgrade', 'bool', 'catalog_product_entity_int', '[]package_plan|upgrade', 'Upgrade', '', 'Upgrade', 'Upgrade', 1),
(20, 'maintenance', 1, 'RegistrationPackage', 'Maintenance', 'bool', 'catalog_product_entity_int', '[]package_plan|maintenance', 'Maintenance', '', 'Maintenance', 'Maintenance', 1),
(21, 'public_shop', 1, 'RegistrationPackage', 'PublicShop', 'bool', 'catalog_product_entity_int', 'public_shop', 'Public Shop', '', 'PublicShop', 'PublicShop', 1),
(22, 'member_only', 1, 'RegistrationPackage', 'MemberOnly', 'bool', 'catalog_product_entity_int', 'member_only', 'Member Only', '', 'MemberOnly', 'MemberOnly', 1),
(23, 'admin_only', 1, 'RegistrationPackage', 'AdminOnly', 'bool', 'catalog_product_entity_int', 'admin_only', 'Admin Only', '', 'AdminOnly', 'AdminOnly', 1),
(24, 'level', 1, 'RegistrationPackage', 'Level', 'int', 'catalog_product_entity_int', '', 'Level', '', 'Level', 'Level', 0),
(25, 'number_of_code', 1, 'RegistrationPackage', 'NumberOfCode', 'int', 'catalog_product_entity_int', 'number_of_code', 'Number Of Code', '', 'NumberOfCode', 'NumberOfCode', 1),
(26, 'activation_code_price', 1, 'RegistrationPackage', 'ActivationCodePrice', 'float64', 'catalog_product_entity_decimal', 'activation_code_price', 'Activation Code Price', '', 'ActivationCodePrice', 'ActivationCodePrice', 1),
(27, 'maintenance_price', 1, 'RegistrationPackage', 'MaintenancePrice', 'float64', 'catalog_product_entity_decimal', 'maintenance_price', 'Maintenance Price', '', 'MaintenancePrice', 'MaintenancePrice', 0),
(28, 'title', 2, 'ProductCategory', 'Title', 'string', 'catalog_category_entity_text', 'title', 'Title', '', '', '', 1),
(29, 'public_shop', 2, 'ProductCategory', 'PublicShop', 'bool', 'catalog_category_entity_int', 'public_shop', 'Public Shop', '', '', '', 1),
(30, 'member_only', 2, 'ProductCategory', 'MemberOnly', 'bool', 'catalog_category_entity_int', 'member_only', 'Member Only', '', '', '', 1),
(31, 'admin_only', 2, 'ProductCategory', 'AdminOnly', 'bool', 'catalog_category_entity_int', 'admin_only', 'Admin Only', '', '', '', 1),
(32, 'race', 3, '', '', '', '', 'race', 'Race', '', '', '', 1),
(33, 'marital_status', 3, '', '', '', '', 'marital_status', 'Marital Status', '', '', '', 1),
(34, 'gender', 3, '', '', '', '', 'gender', 'Gender', '', '', '', 1),
(35, 'ambassador', 3, '', '', '', '', 'ambassador', 'Ambassador', '', '', '', 0),
(36, 'rank', 3, '', '', '', '', 'rank', 'Rank', '{\"MultiStore\":true}', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute_group`
--

CREATE TABLE `eav_attribute_group` (
  `attribute_group_id` int(10) UNSIGNED NOT NULL,
  `attribute_group_code` varchar(255) DEFAULT NULL,
  `attribute_group_name` varchar(255) DEFAULT NULL,
  `attribute_set_id` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_attribute_group`
--

INSERT INTO `eav_attribute_group` (`attribute_group_id`, `attribute_group_code`, `attribute_group_name`, `attribute_set_id`, `sort_order`) VALUES
(1, 'general', 'General', 1, 1),
(2, 'basic', 'Basic Information', 1, 2),
(3, 'membership', 'Membership Information', 1, 3),
(4, 'price', 'Price', 1, 4),
(5, 'available_at', 'Available At', 1, 5),
(6, 'general', 'General', 2, 1),
(7, 'basic', 'Basic Information', 2, 2),
(8, 'price', 'Price', 2, 3),
(9, 'available_at', 'Available At', 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute_option`
--

CREATE TABLE `eav_attribute_option` (
  `option_id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_attribute_option`
--

INSERT INTO `eav_attribute_option` (`option_id`, `attribute_id`) VALUES
(1, 16),
(2, 35),
(3, 36);

-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute_option_value`
--

CREATE TABLE `eav_attribute_option_value` (
  `value_id` int(10) UNSIGNED NOT NULL,
  `option_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_attribute_option_value`
--

INSERT INTO `eav_attribute_option_value` (`value_id`, `option_id`, `store_id`, `key`, `value`, `sort_order`) VALUES
(1, 1, 0, '1', '1', 1),
(2, 1, 0, '3', '3', 2),
(3, 1, 0, '7', '7', 3),
(4, 1, 0, '11', '11', 4),
(5, 2, 0, '1', 'Remy & Derlin', 0),
(6, 2, 0, '2', 'Alan & Cindy', 0),
(7, 2, 0, '3', 'Kelly Ong', 0),
(8, 2, 0, '4', 'David & Janice', 0),
(9, 2, 0, '5', 'Pinky Yap', 0),
(10, 2, 0, '6', 'Ethan & Vikki', 0),
(11, 2, 0, '7', 'Bronny Yew', 0),
(12, 2, 0, '8', 'Jes Tan', 0),
(13, 2, 0, '9', 'Jen Chun Kiat', 0),
(14, 2, 0, '10', 'Krystle & Sean ', 0),
(15, 2, 0, '11', 'Lim Lea Shuan', 0),
(16, 2, 0, '12', 'Andy & Vicky', 0),
(17, 3, 2, '6', 'LEGEND AMBASSADOR CLUB', 6),
(18, 3, 2, '5', 'ROYAL AMBASSADOR CLUB', 5),
(19, 3, 2, '4', 'STAR AMBASSADOR CLUB', 4),
(20, 3, 2, '3', 'ELITE CLUB', 3),
(21, 3, 2, '2', 'PLATINUM CLUB', 2),
(22, 3, 2, '1', 'GOLD CLUB', 1);

-- --------------------------------------------------------

--
-- Table structure for table `eav_attribute_set`
--

CREATE TABLE `eav_attribute_set` (
  `attribute_set_id` int(10) UNSIGNED NOT NULL,
  `attribute_set_name` varchar(255) DEFAULT NULL,
  `entity_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_attribute_set`
--

INSERT INTO `eav_attribute_set` (`attribute_set_id`, `attribute_set_name`, `entity_type_id`) VALUES
(1, 'Simple Product', 1),
(2, 'Package', 1),
(3, 'Grouped Product', 1),
(4, 'Configurable Product', 1),
(5, 'Downloadable Product', 1),
(6, 'Virtual Product', 1),
(7, 'Product Category', 2),
(8, 'Customer', 3);

-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_attribute`
--

CREATE TABLE `eav_entity_attribute` (
  `eav_entity_attribute` int(10) UNSIGNED NOT NULL,
  `attribute_group_id` int(11) DEFAULT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `attribute_set_id` int(11) DEFAULT NULL,
  `entity_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_entity_attribute`
--

INSERT INTO `eav_entity_attribute` (`eav_entity_attribute`, `attribute_group_id`, `attribute_id`, `attribute_set_id`, `entity_type_id`) VALUES
(1, 1, 1, 1, 1),
(2, 1, 2, 1, 1),
(3, 2, 3, 1, 1),
(4, 2, 4, 1, 1),
(5, 2, 5, 1, 1),
(6, 2, 6, 1, 1),
(7, 5, 7, 1, 1),
(8, 5, 8, 1, 1),
(9, 5, 9, 1, 1),
(10, 1, 10, 2, 1),
(11, 1, 11, 2, 1),
(12, 2, 12, 2, 1),
(13, 2, 13, 2, 1),
(14, 2, 14, 2, 1),
(15, 2, 15, 2, 1),
(16, 3, 16, 2, 1),
(17, 3, 17, 2, 1),
(18, 3, 18, 2, 1),
(19, 3, 19, 2, 1),
(20, 3, 20, 2, 1),
(21, 5, 21, 2, 1),
(22, 5, 22, 2, 1),
(23, 5, 23, 2, 1),
(24, 1, 24, 2, 1),
(25, 1, 25, 2, 1),
(26, 1, 26, 2, 1),
(27, 1, 27, 2, 1),
(28, 1, 28, 7, 2),
(29, 5, 29, 7, 2),
(30, 5, 30, 7, 2),
(31, 5, 31, 7, 2),
(32, 1, 32, 8, 3),
(33, 1, 33, 8, 3),
(34, 1, 34, 8, 3),
(35, 1, 35, 8, 3),
(36, 1, 36, 8, 3);

-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_store`
--

CREATE TABLE `eav_entity_store` (
  `entity_store_id` int(10) UNSIGNED NOT NULL,
  `entity_type_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_entity_store`
--

INSERT INTO `eav_entity_store` (`entity_store_id`, `entity_type_id`, `store_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 1, 2),
(4, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `eav_entity_type`
--

CREATE TABLE `eav_entity_type` (
  `entity_type_id` int(10) UNSIGNED NOT NULL,
  `entity_type_code` varchar(255) DEFAULT NULL,
  `entity_table` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eav_entity_type`
--

INSERT INTO `eav_entity_type` (`entity_type_id`, `entity_type_code`, `entity_table`) VALUES
(1, 'catalog_product', 'prd_master'),
(2, 'catalog_category', 'catalog_category_entity'),
(3, 'customer_entity', 'customer_entity');

-- --------------------------------------------------------

--
-- Table structure for table `eml_template`
--

CREATE TABLE `eml_template` (
  `id` int(11) NOT NULL,
  `email_category_id` int(11) DEFAULT NULL,
  `name` varchar(300) DEFAULT NULL,
  `subject` varchar(300) DEFAULT NULL,
  `content` longtext,
  `status` varchar(30) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_center`
--

CREATE TABLE `ent_center` (
  `id` int(11) NOT NULL,
  `center_type` varchar(30) NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `company_reg_no` varchar(30) DEFAULT NULL,
  `addr1` varchar(100) DEFAULT NULL,
  `addr2` varchar(100) DEFAULT NULL,
  `addr3` varchar(100) DEFAULT NULL,
  `addr4` varchar(100) DEFAULT NULL,
  `city_code` varchar(30) DEFAULT NULL,
  `state_code` varchar(30) DEFAULT NULL,
  `country_code` varchar(30) DEFAULT NULL,
  `zip` varchar(30) DEFAULT NULL,
  `office_no` varchar(30) DEFAULT NULL,
  `mobile_no` varchar(30) DEFAULT NULL,
  `fax_no` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company`
--

CREATE TABLE `ent_company` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `code` varchar(30) NOT NULL DEFAULT '',
  `merchant_code` varchar(25) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `app_name` varchar(100) DEFAULT NULL,
  `domain` longtext,
  `project_code` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `referral_nick_name` varchar(100) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_no` varchar(100) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `business_nature` text NOT NULL,
  `prefer_language_code` varchar(30) DEFAULT NULL,
  `date_format` varchar(100) DEFAULT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `symbol_decimal_separator` char(1) DEFAULT '.',
  `symbol_thousand_separator` char(1) DEFAULT ',',
  `prefix_calling_code` varchar(30) DEFAULT NULL,
  `prefix_price_type` varchar(30) DEFAULT NULL,
  `tax_type_code` varchar(30) DEFAULT NULL,
  `tax_inclusive` tinyint(1) DEFAULT NULL,
  `reg_placement` tinyint(1) NOT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `logo_url` varchar(100) DEFAULT NULL,
  `login_logo` varchar(100) DEFAULT NULL,
  `login_logo_url` varchar(100) DEFAULT NULL,
  `icon` varchar(30) DEFAULT NULL,
  `ico_url` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `remark` text,
  `ecom` tinyint(1) DEFAULT '0',
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company_address`
--

CREATE TABLE `ent_company_address` (
  `id` int(11) NOT NULL,
  `ent_company_id` int(11) NOT NULL,
  `addr_type` varchar(30) DEFAULT NULL,
  `name` varchar(300) DEFAULT NULL,
  `contact_no` varchar(30) DEFAULT NULL,
  `addr1` varchar(300) DEFAULT NULL,
  `addr2` varchar(100) DEFAULT NULL,
  `addr3` varchar(100) DEFAULT NULL,
  `addr4` varchar(100) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `state_id` int(11) DEFAULT '0',
  `country_id` int(11) DEFAULT '0',
  `zip` varchar(30) DEFAULT NULL,
  `default_billing` tinyint(1) DEFAULT '0',
  `default_shipping` tinyint(1) DEFAULT '0',
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company_announcement`
--

CREATE TABLE `ent_company_announcement` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `language_id` varchar(30) NOT NULL,
  `icon` varchar(30) NOT NULL,
  `title` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `desc` longtext CHARACTER SET utf8,
  `avatar` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `path` text,
  `file_name` varchar(300) DEFAULT NULL,
  `path_2` text,
  `status` varchar(30) DEFAULT NULL,
  `seq_no` varchar(30) DEFAULT NULL,
  `type_show` varchar(100) NOT NULL,
  `country_id` text,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company_attach`
--

CREATE TABLE `ent_company_attach` (
  `id` int(11) NOT NULL,
  `ent_company_id` int(11) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `file_path` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` varchar(30) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company_bak`
--

CREATE TABLE `ent_company_bak` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `code` varchar(30) NOT NULL DEFAULT '',
  `merchant_code` varchar(25) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `app_name` varchar(100) DEFAULT NULL,
  `domain` longtext,
  `project_code` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `referral_nick_name` varchar(100) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_no` varchar(100) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `business_nature` text NOT NULL,
  `prefer_language_code` varchar(30) DEFAULT NULL,
  `date_format` varchar(100) DEFAULT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `symbol_decimal_separator` char(1) DEFAULT '.',
  `symbol_thousand_separator` char(1) DEFAULT ',',
  `prefix_calling_code` varchar(30) DEFAULT NULL,
  `prefix_price_type` varchar(30) DEFAULT NULL,
  `tax_type_code` varchar(30) DEFAULT NULL,
  `tax_inclusive` tinyint(1) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `logo_url` varchar(100) DEFAULT NULL,
  `login_logo` varchar(100) DEFAULT NULL,
  `login_logo_url` varchar(100) DEFAULT NULL,
  `icon` varchar(30) DEFAULT NULL,
  `ico_url` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `remark` text,
  `ecom` tinyint(1) DEFAULT '0',
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company_bank`
--

CREATE TABLE `ent_company_bank` (
  `id` int(11) NOT NULL,
  `ent_company_id` int(11) NOT NULL,
  `bank_country_id` int(11) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `bank_branch_id` int(11) DEFAULT NULL,
  `bank_acc_no` varchar(30) DEFAULT NULL,
  `bank_acc_name` varchar(100) DEFAULT NULL,
  `bank_addr` varchar(92) DEFAULT NULL,
  `bank_swift_code` varchar(8) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company_downloads`
--

CREATE TABLE `ent_company_downloads` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `language_id` varchar(30) NOT NULL,
  `icon` varchar(30) NOT NULL,
  `title` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `desc` longtext CHARACTER SET utf8,
  `file_name` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `path` text,
  `status` varchar(30) DEFAULT NULL,
  `seq_no` varchar(30) DEFAULT NULL,
  `type_show` varchar(100) NOT NULL,
  `country_id` text,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company_link`
--

CREATE TABLE `ent_company_link` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `desc` longtext,
  `path` text,
  `status` varchar(30) DEFAULT NULL,
  `seq_no` varchar(30) DEFAULT NULL,
  `type_show` varchar(100) NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company_temp`
--

CREATE TABLE `ent_company_temp` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `code` varchar(30) NOT NULL DEFAULT '',
  `merchant_code` varchar(25) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `app_name` varchar(100) DEFAULT NULL,
  `domain` longtext,
  `project_code` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `referral_nick_name` varchar(100) DEFAULT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_no` varchar(30) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `business_nature` text,
  `prefer_language_code` varchar(30) DEFAULT NULL,
  `date_format` varchar(100) DEFAULT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `symbol_decimal_separator` char(1) DEFAULT '.',
  `symbol_thousand_separator` char(1) DEFAULT ',',
  `prefix_calling_code` varchar(30) DEFAULT NULL,
  `prefix_price_type` varchar(30) DEFAULT NULL,
  `tax_type_code` varchar(30) DEFAULT NULL,
  `tax_inclusive` tinyint(1) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `logo_url` varchar(100) DEFAULT NULL,
  `login_logo` varchar(100) DEFAULT NULL,
  `login_logo_url` varchar(100) DEFAULT NULL,
  `icon` varchar(30) DEFAULT NULL,
  `ico_url` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `remark` text,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_company_tnc`
--

CREATE TABLE `ent_company_tnc` (
  `id` int(11) NOT NULL,
  `title` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `desc` longtext CHARACTER SET utf8,
  `file_name` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `path` text,
  `status` varchar(30) DEFAULT NULL,
  `seq_no` varchar(30) DEFAULT NULL,
  `type_show` varchar(100) DEFAULT NULL,
  `country_id` varchar(100) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_country`
--

CREATE TABLE `ent_country` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '0',
  `code` varchar(30) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL,
  `prefer_language_code` varchar(30) DEFAULT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `withdraw_currency_code` varchar(30) NOT NULL DEFAULT 'CNY',
  `symbol_decimal` char(1) DEFAULT '.',
  `symbol_thousand_separator` char(1) DEFAULT ',',
  `prefix_calling_code` varchar(30) DEFAULT NULL,
  `prefix_price_type` varchar(30) DEFAULT NULL,
  `tax_type_code` varchar(30) DEFAULT NULL,
  `tax_inclusive` tinyint(1) DEFAULT NULL,
  `ecommerce` tinyint(1) DEFAULT '0',
  `decimal_point` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ent_country`
--

INSERT INTO `ent_country` (`id`, `country_id`, `code`, `name`, `prefer_language_code`, `currency_code`, `withdraw_currency_code`, `symbol_decimal`, `symbol_thousand_separator`, `prefix_calling_code`, `prefix_price_type`, `tax_type_code`, `tax_inclusive`, `ecommerce`, `decimal_point`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 1, 'MY', 'Malaysia', 'en', 'MYR', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(69, 69, 'CN', 'China', 'cn', 'CNY', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(127, 430, 'ID', 'Indonesia', 'en', 'IDR', 'CNY', '.', ',', '', '', '', 0, 1, 0, NULL, NULL, NULL, NULL),
(224, 224, 'SG', 'Singapore', 'en', 'SGD', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL),
(225, 241, 'TW', 'Taiwan', 'zh-TW', 'TWD', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(228, 243, 'TH', 'Thailand', 'en', 'THB', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(229, 200, 'PH', 'Philippine', 'en', 'PHP', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(230, 123, 'HK', 'Hong Kong', 'zh-TW', 'HKD', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(231, 267, 'VN', 'Vietnam', 'en', 'VN', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(232, 152, 'MO', 'Macau', 'zh-TW', 'MOP', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(233, 424, 'AR', 'Argentina', 'en', 'ARS', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(235, 61, 'KH', 'Cambodia', 'en', 'KHR', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(236, 596, 'GU', 'Guam (USA)', 'en', 'USD', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(237, 435, 'IN', 'India', 'en', 'INR', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(238, 432, 'JP', 'Japan', 'jp', 'JPY', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(239, 431, 'NZ', 'New Zealand', 'en', 'NZD', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(240, 433, 'KR', 'South Korea', 'en', 'KRW', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(241, 400, 'US', 'United States', 'en', 'USD', 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(242, 487, 'ZW', 'Zimbabwe', 'en', 'ZWL', 'CNY', '.', ',', '', '', '', 0, 0, 0, NULL, NULL, NULL, NULL),
(243, 399, 'CA', 'Canada', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(244, 401, 'KZ', 'Kazakhstan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(245, 402, 'RU', 'Russia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(246, 403, 'EG', 'Egypt', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(247, 404, 'ZA', 'South Africa', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(248, 405, 'GR', 'Greece', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(249, 406, 'NL', 'Netherlands', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(250, 407, 'BE', 'Belgium', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(251, 408, 'FR', 'France', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(252, 409, 'ES', 'Spain', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(253, 410, 'HU', 'Hungary', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(254, 411, 'IT', 'Italy', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(255, 412, 'RO', 'Romania', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(256, 413, 'CH', 'Switzerland', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(257, 414, 'AT', 'Austria', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(258, 415, 'GB', 'United Kingdom', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(259, 416, 'DK', 'Denmark', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(260, 417, 'SE', 'Sweden', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(261, 418, 'NO', 'Norway', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(262, 419, 'PL', 'Poland', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(263, 420, 'DE', 'Germany', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(264, 421, 'PE', 'Peru', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(265, 422, 'MX', 'Mexico', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(266, 423, 'CU', 'Cuba', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(267, 425, 'BR', 'Brazil', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(268, 426, 'CL', 'Chile', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(269, 427, 'CO', 'Colombia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(270, 428, 'VE', 'Venezuela', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(271, 429, 'AU', 'Australia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(272, 434, 'TR', 'Turkey', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(273, 436, 'PK', 'Pakistan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(274, 437, 'AF', 'Afghanistan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(275, 438, 'LK', 'Sri Lanka', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(276, 439, 'MM', 'Myanmar', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(277, 440, 'IR', 'Iran', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(278, 441, 'SS', 'South Sudan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(279, 442, 'MA', 'Morocco', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(280, 443, 'DZ', 'Algeria', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(281, 444, 'TN', 'Tunisia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(282, 445, 'LY', 'Libya', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(283, 446, 'GM', 'Gambia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(284, 447, 'SN', 'Senegal', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(285, 448, 'MR', 'Mauritania', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(286, 449, 'ML', 'Mali', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(287, 450, 'GN', 'Guinea', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(288, 451, 'CI', 'Ivory Coast', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(289, 452, 'BF', 'Burkina Faso', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(290, 453, 'NE', 'Niger', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(291, 454, 'TG', 'Togo', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(292, 455, 'BJ', 'Benin', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(293, 456, 'MU', 'Mauritius', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(294, 457, 'LR', 'Liberia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(295, 458, 'SL', 'Sierra Leone', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(296, 459, 'GH', 'Ghana', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(297, 460, 'NG', 'Nigeria', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(298, 461, 'TD', 'Chad', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(299, 462, 'CF', 'Central African Republic', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(300, 463, 'CM', 'Cameroon', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(301, 464, 'CV', 'Cape Verde', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(302, 465, 'ST', 'Sao Tome and Principe', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(303, 466, 'GQ', 'Equatorial Guinea', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(304, 467, 'GA', 'Gabon', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(305, 468, 'CG', 'Congo', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(306, 469, 'CD', 'Democratic Republic of the Congo', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(307, 470, 'AO', 'Angola', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(308, 471, 'GW', 'Guinea-Bissau', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(309, 473, 'SC', 'Seychelles', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(310, 474, 'SD', 'Sudan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(311, 475, 'RW', 'Rwanda', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(312, 476, 'ET', 'Ethiopia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(313, 477, 'SO', 'Somalia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(314, 478, 'DJ', 'Djibouti', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(315, 479, 'KE', 'Kenya', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(316, 480, 'TZ', 'Tanzania', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(317, 481, 'UG', 'Uganda', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(318, 482, 'BI', 'Burundi', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(319, 483, 'MZ', 'Mozambique', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(320, 484, 'ZM', 'Zambia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(321, 485, 'MG', 'Madagascar', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(322, 486, 'RE', 'Réunion', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(323, 488, 'NA', 'Namibia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(324, 489, 'MW', 'Malawi', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(325, 490, 'LS', 'Lesotho', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(326, 491, 'BW', 'Botswana', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(327, 492, 'SZ', 'Swaziland', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(328, 493, 'KM', 'Comoros', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(329, 494, 'YT', 'Mayotte', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(330, 495, 'AW', 'Aruba', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(331, 496, 'FO', 'Faroe Islands', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(332, 497, 'GL', 'Greenland', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(333, 498, 'GI', 'Gibraltar', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(334, 499, 'PT', 'Portugal', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(335, 500, 'LU', 'Luxembourg', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(336, 501, 'MK', 'Macedonia, the former Yugoslav Republic of', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(337, 502, 'IE', 'Ireland', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(338, 503, 'IS', 'Iceland', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(339, 504, 'AL', 'Albania', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(340, 505, 'MT', 'Malta', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(341, 506, 'CY', 'Cyprus', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(342, 507, 'FI', 'Finland', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(343, 508, 'BG', 'Bulgaria', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(344, 509, 'LT', 'Lithuania', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(345, 510, 'LV', 'Latvia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(346, 511, 'EE', 'Estonia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(347, 512, 'MD', 'Moldova, Republic of', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(348, 513, 'AM', 'Armenia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(349, 514, 'BY', 'Belarus', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(350, 515, 'AD', 'Andorra', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(351, 516, 'MC', 'Monaco', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(352, 517, 'SM', 'San Marino', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(353, 518, 'UA', 'Ukraine', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(354, 519, 'RS', 'Serbia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(355, 520, 'ME', 'Montenegro', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(356, 521, 'HR', 'Croatia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(357, 522, 'SI', 'Slovenia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(358, 523, 'BA', 'Bosnia and Herzegovina', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(359, 524, 'CZ', 'Czech Republic', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(360, 525, 'SK', 'Slovakia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(361, 526, 'LI', 'Liechtenstein', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(362, 527, 'BZ', 'Belize', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(363, 528, 'GT', 'Guatemala', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(364, 529, 'SV', 'El Salvador', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(365, 530, 'HN', 'Honduras', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(366, 531, 'NI', 'Nicaragua', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(367, 532, 'CR', 'Costa Rica', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(368, 533, 'PA', 'Panama', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(369, 534, 'PM', 'Saint Pierre and Miquelon', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(370, 535, 'HT', 'Haiti', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(371, 536, 'GP', 'Guadeloupe', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(372, 537, 'MF', 'Saint Martin', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(373, 538, 'BO', 'Bolivia, Plurinational', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(374, 539, 'GY', 'Guyana', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(375, 540, 'EC', 'Ecuador', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(376, 541, 'GF', 'French Guiana', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(377, 542, 'PY', 'Paraguay', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(378, 543, 'SR', 'Suriname', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(379, 544, 'UY', 'Uruguay', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(380, 545, 'AN', 'Netherlands Antilles', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(381, 546, 'CW', 'Curacao', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(382, 547, 'TL', 'Timor', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(383, 548, 'BN', 'Brunei Darussalam', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(384, 549, 'PG', 'Papua New Guinea', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(385, 550, 'TO', 'Tonga', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(386, 551, 'SB', 'Solomon Islands', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(387, 552, 'VU', 'Vanuatu', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(388, 553, 'FJ', 'Fiji', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(389, 554, 'PW', 'Palau', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(390, 555, 'CK', 'Cook Islands', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(391, 556, 'WS', 'Samoa', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(392, 557, 'KI', 'Kiribati', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(393, 558, 'NC', 'New Caledonia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(394, 559, 'PF', 'French Polynesia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(395, 560, 'LA', 'Lao People\'s Democratic Republic', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(396, 561, 'BD', 'Bangladesh', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(397, 562, 'PS', 'Palestine', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(398, 563, 'MV', 'Maldives', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(399, 564, 'LB', 'Lebanon', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(400, 565, 'JO', 'Jordan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(401, 566, 'SY', 'Syrian Arab Republic', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(402, 567, 'IQ', 'Iraq', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(403, 568, 'KW', 'Kuwait', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(404, 569, 'SA', 'Saudi Arabia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(405, 570, 'YE', 'Yemen', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(406, 571, 'OM', 'Oman', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(407, 572, 'AE', 'United Arab Emirates', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(408, 573, 'IL', 'Israel', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(409, 574, 'BH', 'Bahrain', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(410, 575, 'QA', 'Qatar', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(411, 576, 'BT', 'Bhutan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(412, 577, 'MN', 'Mongolia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(413, 578, 'NP', 'Nepal', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(414, 579, 'TJ', 'Tajikistan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(415, 580, 'TM', 'Turkmenistan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(416, 581, 'AZ', 'Azerbaijan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(417, 582, 'GE', 'Georgia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(418, 583, 'KG', 'Kyrgyzstan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(419, 584, 'UZ', 'Uzbekistan', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(420, 585, 'BS', 'Bahamas', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(421, 586, 'BB', 'Barbados', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(422, 587, 'AI', 'Anguilla', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(423, 588, 'AG', 'Antigua and Barbuda', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(424, 589, 'VG', 'British Virgin Islands', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(425, 590, 'VI', 'United States Virgin Islands', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(426, 591, 'KY', 'Cayman Islands', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(427, 592, 'BM', 'Bermuda', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(428, 593, 'GD', 'Grenada', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(429, 594, 'TC', 'Turks and Caicos Islands', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(430, 595, 'MS', 'Montserrat', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(431, 597, 'AS', 'American Samoa', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(432, 598, 'LC', 'Saint Lucia', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(433, 599, 'DM', 'Dominica', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(434, 600, 'VC', 'Saint Vincent and the Grenadines', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(435, 601, 'PR', 'Puerto Rico', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(436, 602, 'DO', 'Dominican Republic', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(437, 603, 'TT', 'Trinidad and Tobago', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(438, 604, 'KN', 'Saint Kitts and Nevis', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(439, 605, 'JM', 'Jamaica', 'en', NULL, 'CNY', '.', ',', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ent_location`
--

CREATE TABLE `ent_location` (
  `id` int(11) NOT NULL,
  `location_type_code` varchar(30) NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `company_reg_no` varchar(30) DEFAULT NULL,
  `company_gst_no` varchar(30) DEFAULT NULL,
  `addr1` varchar(100) DEFAULT NULL,
  `addr2` varchar(100) DEFAULT NULL,
  `addr3` varchar(100) DEFAULT NULL,
  `addr4` varchar(100) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `state_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `post_code` varchar(30) DEFAULT NULL,
  `office_no` varchar(30) DEFAULT NULL,
  `mobile_no` varchar(30) DEFAULT NULL,
  `fax_no` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member`
--

CREATE TABLE `ent_member` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `member_type` varchar(30) DEFAULT NULL,
  `entity_type` varchar(30) DEFAULT NULL,
  `source` varchar(30) DEFAULT NULL,
  `code` varchar(30) NOT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `first_name` varchar(300) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `maintain` tinyint(4) DEFAULT '1',
  `disable_topup` tinyint(1) DEFAULT '0',
  `replicator_name` varchar(100) DEFAULT NULL,
  `replicator_nick_name` varchar(100) DEFAULT NULL,
  `identity_type` varchar(30) DEFAULT NULL,
  `identity_no` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `wechat` varchar(100) DEFAULT NULL,
  `avatar` longtext,
  `path` varchar(150) DEFAULT NULL,
  `qr_path` longtext,
  `pin_no` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `company_form_no` varchar(30) DEFAULT NULL,
  `tax_gst_no` varchar(30) DEFAULT NULL,
  `tax_income_no` varchar(30) DEFAULT NULL,
  `nationality_id` int(11) DEFAULT NULL,
  `gender_id` int(11) DEFAULT NULL,
  `race_id` int(11) DEFAULT NULL,
  `marital_id` int(111) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `religion_id` int(11) DEFAULT NULL,
  `birth_date` varchar(11) DEFAULT NULL,
  `bns_payout_type` varchar(30) DEFAULT NULL,
  `spouse_name` varchar(100) DEFAULT NULL,
  `spouse_ic` varchar(30) DEFAULT NULL,
  `spouse_dob` date DEFAULT NULL,
  `beneficiary_relation_id` int(11) DEFAULT NULL,
  `beneficiary_name` varchar(100) DEFAULT NULL,
  `beneficiary_ic` varchar(30) DEFAULT NULL,
  `beneficiary_dob` date DEFAULT NULL,
  `prefer_language_code` varchar(30) DEFAULT NULL,
  `join_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `upgrade_mem` tinyint(1) DEFAULT '0',
  `upgraded_at` datetime DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `update_profile` tinyint(1) DEFAULT NULL,
  `sms` tinyint(1) DEFAULT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `agreement` tinyint(1) DEFAULT '0',
  `remark` varchar(300) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `suspended_by` varchar(30) DEFAULT NULL,
  `suspended_on` timestamp NULL DEFAULT NULL,
  `cancelled_by` varchar(11) DEFAULT NULL,
  `cancelled_on` timestamp NULL DEFAULT NULL,
  `terminated_by` varchar(30) DEFAULT NULL,
  `terminated_on` timestamp NULL DEFAULT NULL,
  `tmp_member_id` int(11) DEFAULT NULL,
  `trading_wallet_id` varchar(255) DEFAULT NULL,
  `date_of_birth` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `postcode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `beneficiary_relation_name` varchar(255) DEFAULT NULL,
  `maintenance_expire_date` timestamp NULL DEFAULT NULL,
  `upgrade_date` timestamp NULL DEFAULT NULL,
  `upgrade_expire_date` timestamp NULL DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  `congratulate_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ent_member`
--

INSERT INTO `ent_member` (`id`, `country_id`, `company_id`, `member_type`, `entity_type`, `source`, `code`, `nick_name`, `first_name`, `last_name`, `status`, `maintain`, `disable_topup`, `replicator_name`, `replicator_nick_name`, `identity_type`, `identity_no`, `email`, `wechat`, `avatar`, `path`, `qr_path`, `pin_no`, `password`, `company_name`, `company_form_no`, `tax_gst_no`, `tax_income_no`, `nationality_id`, `gender_id`, `race_id`, `marital_id`, `region_id`, `religion_id`, `birth_date`, `bns_payout_type`, `spouse_name`, `spouse_ic`, `spouse_dob`, `beneficiary_relation_id`, `beneficiary_name`, `beneficiary_ic`, `beneficiary_dob`, `prefer_language_code`, `join_date`, `upgrade_mem`, `upgraded_at`, `expiry_date`, `update_profile`, `sms`, `ip`, `agreement`, `remark`, `created_by`, `created_at`, `updated_by`, `updated_at`, `suspended_by`, `suspended_on`, `cancelled_by`, `cancelled_on`, `terminated_by`, `terminated_on`, `tmp_member_id`, `trading_wallet_id`, `date_of_birth`, `address`, `postcode`, `state`, `city`, `beneficiary_relation_name`, `maintenance_expire_date`, `upgrade_date`, `upgrade_expire_date`, `rank`, `congratulate_date`) VALUES
(1, 1, 1, 'MEM', NULL, 'web', 'MEM00000001', 'COM', 'COM', NULL, 'A', 1, 0, NULL, NULL, NULL, NULL, 'com@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1989-06-13', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-09-05 08:32:24', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, 'sammy', '2018-09-05 07:32:24', NULL, '2018-11-26 06:40:43', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 1, 1, 'NETTED', NULL, 'web', 'MEM58845864', 'vkids-ex', 'Alisan (V-Expert)', NULL, 'A', 1, 0, NULL, NULL, 'nric', '1234567891', 'alisan@gmail.com', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 'zh', '2020-01-08 09:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, '1', '2020-01-08 09:19:29', NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', '2020-02-07 10:19:30', '2020-01-08 10:19:30', '2020-02-22 10:19:30', 0, NULL),
(3, 1, 0, 'LOT', NULL, '', 'MEM58845864-1', '', 'MEM58845864-1', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(4, 1, 0, 'LOT', NULL, '', 'MEM58845864-2', '', 'MEM58845864-2', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(5, 1, 0, 'LOT', NULL, '', 'MEM58845864-3', '', 'MEM58845864-3', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(6, 1, 0, 'LOT', NULL, '', 'MEM58845864-4', '', 'MEM58845864-4', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(7, 1, 0, 'LOT', NULL, '', 'MEM58845864-5', '', 'MEM58845864-5', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(8, 1, 0, 'LOT', NULL, '', 'MEM58845864-6', '', 'MEM58845864-6', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(9, 1, 0, 'LOT', NULL, '', 'MEM58845864-7', '', 'MEM58845864-7', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(10, 1, 0, 'LOT', NULL, '', 'MEM58845864-8', '', 'MEM58845864-8', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(11, 1, 0, 'LOT', NULL, '', 'MEM58845864-9', '', 'MEM58845864-9', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(12, 1, 0, 'LOT', NULL, '', 'MEM58845864-10', '', 'MEM58845864-10', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(13, 1, 0, 'LOT', NULL, '', 'MEM58845864-11', '', 'MEM58845864-11', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(14, 1, 1, 'NETTED', NULL, 'web', 'MEM84342648', 'vkids-ma', 'Amanda (V-Master)', NULL, 'A', 1, 0, NULL, NULL, 'nric', '1234567891', 'amande@gmail.com', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 'zh', '2020-01-08 09:19:30', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, '1', '2020-01-08 09:19:30', NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', '2020-02-07 10:19:31', '2020-01-08 10:19:31', '2020-02-22 10:19:31', 0, NULL),
(15, 1, 0, 'LOT', NULL, '', 'MEM84342648-1', '', 'MEM84342648-1', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(16, 1, 0, 'LOT', NULL, '', 'MEM84342648-2', '', 'MEM84342648-2', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(17, 1, 0, 'LOT', NULL, '', 'MEM84342648-3', '', 'MEM84342648-3', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(18, 1, 0, 'LOT', NULL, '', 'MEM84342648-4', '', 'MEM84342648-4', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(19, 1, 0, 'LOT', NULL, '', 'MEM84342648-5', '', 'MEM84342648-5', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(20, 1, 0, 'LOT', NULL, '', 'MEM84342648-6', '', 'MEM84342648-6', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(21, 1, 0, 'LOT', NULL, '', 'MEM84342648-7', '', 'MEM84342648-7', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(22, 1, 1, 'NETTED', NULL, 'web', 'MEM46947908', 'vkids-pr', 'Amy (V-Pro)', NULL, 'A', 1, 0, NULL, NULL, 'nric', '1234567891', 'amy@gmail.com', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 'zh', '2020-01-08 09:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, '1', '2020-01-08 09:19:31', NULL, '2020-01-08 09:19:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', '2020-02-07 10:19:31', '2020-01-08 10:19:31', '2020-02-22 10:19:31', 0, NULL),
(23, 1, 0, 'LOT', NULL, '', 'MEM46947908-1', '', 'MEM46947908-1', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(24, 1, 0, 'LOT', NULL, '', 'MEM46947908-2', '', 'MEM46947908-2', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(25, 1, 0, 'LOT', NULL, '', 'MEM46947908-3', '', 'MEM46947908-3', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(26, 1, 1, 'NETTED', NULL, 'web', 'MEM53882013', 'vkids-us', 'Nicola (V-User)', NULL, 'A', 1, 0, NULL, NULL, 'nric', '1234567891', 'nicola@gmail.com', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 'zh', '2020-01-08 09:19:31', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, '1', '2020-01-08 09:19:31', NULL, '2020-01-08 09:19:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', '2020-02-07 10:19:32', '2020-01-08 10:19:32', '2020-02-22 10:19:32', 0, NULL),
(27, 1, 0, 'LOT', NULL, '', 'MEM53882013-1', '', 'MEM53882013-1', NULL, 'A', 1, 0, NULL, NULL, '', '', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, '', '2020-01-08 10:19:32', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2020-01-08 09:19:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', NULL, NULL, NULL, 0, NULL),
(28, 1, 1, 'NON-NET', NULL, 'web', 'MEM48815426', 'vkids-sp1', 'Olivia', NULL, 'A', 1, 0, NULL, NULL, 'nric', '1234567891', 'ilivia@gmail.com', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 'zh', '2020-01-08 10:19:32', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, '1', '2020-01-08 09:19:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', '2020-02-07 10:19:32', '2020-01-08 10:19:32', '2020-02-22 10:19:32', 0, NULL),
(29, 1, 1, 'NON-NET', NULL, 'web', 'MEM98065962', 'vkids-sp2', 'Rachel', NULL, 'A', 1, 0, NULL, NULL, 'nric', '1234567891', 'rose@gmail.com', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL, 'zh', '2020-01-08 10:19:32', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL, '1', '2020-01-08 09:19:32', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '', '', '', '', '', '2020-02-07 10:19:32', '2020-01-08 10:19:32', '2020-02-22 10:19:32', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_2fa`
--

CREATE TABLE `ent_member_2fa` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `codeurl` varchar(255) NOT NULL,
  `b_enable` tinyint(1) NOT NULL COMMENT '0 = off, 1=on',
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_address`
--

CREATE TABLE `ent_member_address` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `addr_type` varchar(30) DEFAULT NULL,
  `name` varchar(300) DEFAULT NULL,
  `contact_no` varchar(30) DEFAULT NULL,
  `addr1` varchar(300) DEFAULT NULL,
  `addr2` varchar(100) DEFAULT NULL,
  `addr3` varchar(100) DEFAULT NULL,
  `addr4` varchar(100) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `state_id` int(11) DEFAULT '0',
  `country_id` int(11) DEFAULT '0',
  `zip` varchar(30) DEFAULT NULL,
  `default_billing` tinyint(1) DEFAULT '0',
  `default_shipping` tinyint(1) DEFAULT '0',
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ent_member_address`
--

INSERT INTO `ent_member_address` (`id`, `member_id`, `addr_type`, `name`, `contact_no`, `addr1`, `addr2`, `addr3`, `addr4`, `city_id`, `state_id`, `country_id`, `zip`, `default_billing`, `default_shipping`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, NULL, 0, 0, '', '2020-01-08 09:19:29', NULL, NULL),
(2, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, NULL, 0, 0, '', '2020-01-08 09:19:30', NULL, NULL),
(3, 22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, NULL, 0, 0, '', '2020-01-08 09:19:31', NULL, NULL),
(4, 26, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, NULL, 0, 0, '', '2020-01-08 09:19:31', NULL, NULL),
(5, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, NULL, 0, 0, '', '2020-01-08 09:19:31', NULL, NULL),
(6, 29, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, NULL, 0, 0, '', '2020-01-08 09:19:32', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_bank`
--

CREATE TABLE `ent_member_bank` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `bank_country_id` int(11) DEFAULT NULL,
  `bank_name` varchar(50) DEFAULT NULL,
  `bank_branch_id` int(11) DEFAULT NULL,
  `bank_branch_name` varchar(100) DEFAULT NULL,
  `bank_acc_no` varchar(30) DEFAULT NULL,
  `bank_acc_name` varchar(100) DEFAULT NULL,
  `bank_account_type` varchar(100) DEFAULT NULL,
  `card_expiry_date` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `path` varchar(300) DEFAULT NULL,
  `avatar` varchar(300) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_change_rank`
--

CREATE TABLE `ent_member_change_rank` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `current_title` varchar(30) DEFAULT NULL,
  `grp_type1` tinyint(1) NOT NULL DEFAULT '0',
  `new_title` varchar(30) DEFAULT NULL,
  `grp_type2` tinyint(1) NOT NULL DEFAULT '0',
  `sso_master_id` int(100) DEFAULT '0',
  `bns_batch` date DEFAULT NULL,
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_contact`
--

CREATE TABLE `ent_member_contact` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `contact_type` varchar(30) DEFAULT NULL,
  `prefix` varchar(11) DEFAULT NULL,
  `contact_desc` varchar(100) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ent_member_contact`
--

INSERT INTO `ent_member_contact` (`id`, `member_id`, `contact_type`, `prefix`, `contact_desc`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 2, 'mobile', '1', '0123456789', '', '0000-00-00 00:00:00', '', NULL),
(2, 14, 'mobile', '1', '0123456789', '', '0000-00-00 00:00:00', '', NULL),
(3, 22, 'mobile', '1', '0123456789', '', '0000-00-00 00:00:00', '', NULL),
(4, 26, 'mobile', '1', '0123456789', '', '0000-00-00 00:00:00', '', NULL),
(5, 28, 'mobile', '1', '0123456789', '', '0000-00-00 00:00:00', '', NULL),
(6, 29, 'mobile', '1', '0123456789', '', '0000-00-00 00:00:00', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_custom_reentry`
--

CREATE TABLE `ent_member_custom_reentry` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `b_custom` tinyint(1) NOT NULL COMMENT '0 = No , 1 = Auto',
  `ewallet_type_id` int(11) NOT NULL,
  `t_reenty_perc` varchar(25) NOT NULL,
  `b_latest` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_gold_coin_no`
--

CREATE TABLE `ent_member_gold_coin_no` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `gold_coin_no` varchar(15) NOT NULL,
  `status` varchar(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'A=Active, I=Inactive',
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_kyc`
--

CREATE TABLE `ent_member_kyc` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `file_name_1` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `file_url_1` text NOT NULL,
  `file_name_2` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `file_url_2` text NOT NULL,
  `status` varchar(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_by` varchar(30) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `approved_at` datetime DEFAULT NULL,
  `approved_by` varchar(30) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_lot_queue`
--

CREATE TABLE `ent_member_lot_queue` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `member_lot` varchar(25) NOT NULL,
  `sponsor_id` int(11) NOT NULL,
  `sponsor_lot` varchar(25) NOT NULL,
  `upline_id` int(11) NOT NULL,
  `upline_lot` varchar(25) NOT NULL,
  `leg_no` varchar(25) NOT NULL,
  `type` varchar(25) NOT NULL,
  `status` varchar(25) NOT NULL,
  `batch` varchar(25) NOT NULL,
  `dt_process` datetime NOT NULL,
  `dt_create` datetime NOT NULL,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ent_member_lot_queue`
--

INSERT INTO `ent_member_lot_queue` (`id`, `member_id`, `member_lot`, `sponsor_id`, `sponsor_lot`, `upline_id`, `upline_lot`, `leg_no`, `type`, `status`, `batch`, `dt_process`, `dt_create`, `dt_timestamp`) VALUES
(1, 2, '1', 1, '01', 1, '01', '1', 'REG', '', '', '0000-00-00 00:00:00', '2020-01-08 17:19:30', '0000-00-00 00:00:00'),
(2, 14, '1', 1, '01', 1, '01', '1', 'REG', '', '', '0000-00-00 00:00:00', '2020-01-08 17:19:31', '0000-00-00 00:00:00'),
(3, 22, '1', 1, '01', 1, '01', '1', 'REG', '', '', '0000-00-00 00:00:00', '2020-01-08 17:19:31', '0000-00-00 00:00:00'),
(4, 26, '1', 1, '01', 1, '01', '1', 'REG', '', '', '0000-00-00 00:00:00', '2020-01-08 17:19:32', '0000-00-00 00:00:00'),
(5, 28, '1', 1, '01', 1, '01', '1', 'REG', '', '', '0000-00-00 00:00:00', '2020-01-08 17:19:32', '0000-00-00 00:00:00'),
(6, 29, '1', 1, '01', 1, '01', '1', 'REG', '', '', '0000-00-00 00:00:00', '2020-01-08 17:19:32', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_lot_sponsor`
--

CREATE TABLE `ent_member_lot_sponsor` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `member_lot` varchar(25) NOT NULL,
  `i_lft` int(11) NOT NULL,
  `i_rgt` int(11) NOT NULL,
  `i_lvl` int(11) NOT NULL,
  `dt_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `member_lot_id` int(11) DEFAULT NULL,
  `is_root` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ent_member_lot_sponsor`
--

INSERT INTO `ent_member_lot_sponsor` (`id`, `member_id`, `member_lot`, `i_lft`, `i_rgt`, `i_lvl`, `dt_timestamp`, `member_lot_id`, `is_root`) VALUES
(1, 2, '1', 0, 0, 0, '2020-01-08 16:19:30', 3, 1),
(2, 2, '2', 0, 0, 0, '2020-01-08 16:19:30', 4, 0),
(3, 2, '3', 0, 0, 0, '2020-01-08 16:19:30', 5, 0),
(4, 2, '4', 0, 0, 0, '2020-01-08 16:19:30', 6, 0),
(5, 2, '5', 0, 0, 0, '2020-01-08 16:19:30', 7, 0),
(6, 2, '6', 0, 0, 0, '2020-01-08 16:19:30', 8, 0),
(7, 2, '7', 0, 0, 0, '2020-01-08 16:19:30', 9, 0),
(8, 2, '8', 0, 0, 0, '2020-01-08 16:19:30', 10, 0),
(9, 2, '9', 0, 0, 0, '2020-01-08 16:19:30', 11, 0),
(10, 2, '10', 0, 0, 0, '2020-01-08 16:19:30', 12, 0),
(11, 2, '11', 0, 0, 0, '2020-01-08 16:19:30', 13, 0),
(12, 14, '1', 0, 0, 0, '2020-01-08 16:19:30', 15, 1),
(13, 14, '2', 0, 0, 0, '2020-01-08 16:19:30', 16, 0),
(14, 14, '3', 0, 0, 0, '2020-01-08 16:19:30', 17, 0),
(15, 14, '4', 0, 0, 0, '2020-01-08 16:19:30', 18, 0),
(16, 14, '5', 0, 0, 0, '2020-01-08 16:19:30', 19, 0),
(17, 14, '6', 0, 0, 0, '2020-01-08 16:19:30', 20, 0),
(18, 14, '7', 0, 0, 0, '2020-01-08 16:19:30', 21, 0),
(19, 22, '1', 0, 0, 0, '2020-01-08 16:19:31', 23, 1),
(20, 22, '2', 0, 0, 0, '2020-01-08 16:19:31', 24, 0),
(21, 22, '3', 0, 0, 0, '2020-01-08 16:19:31', 25, 0),
(22, 26, '1', 0, 0, 0, '2020-01-08 16:19:31', 27, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_oauth_login`
--

CREATE TABLE `ent_member_oauth_login` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `t_token` text NOT NULL,
  `b_login` tinyint(1) NOT NULL,
  `b_logout` tinyint(1) NOT NULL,
  `dt_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_pin`
--

CREATE TABLE `ent_member_pin` (
  `id` int(11) NOT NULL,
  `sls_master_id` int(11) DEFAULT '0',
  `prd_master_id` int(11) DEFAULT '0',
  `country_id` int(11) DEFAULT NULL,
  `doc_no` varchar(30) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `pin_code` varchar(100) DEFAULT NULL,
  `qty` int(11) DEFAULT '0',
  `qr_code` varchar(100) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `sub_total` decimal(12,2) DEFAULT NULL,
  `total_tax` decimal(12,2) DEFAULT NULL,
  `total_pv` decimal(12,2) DEFAULT NULL,
  `total_bv` decimal(12,2) DEFAULT NULL,
  `total_sv` decimal(12,2) DEFAULT NULL,
  `conversation_rate` decimal(12,2) DEFAULT NULL,
  `converted_total_amount` decimal(12,2) DEFAULT NULL,
  `converted_sub_total` decimal(12,2) DEFAULT NULL,
  `converted_total_tax` decimal(12,2) DEFAULT NULL,
  `redeem_sls_master_id` int(11) DEFAULT '0',
  `member_id_redeem` int(11) DEFAULT '0',
  `redeem_date` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_removed_tree_sponsor`
--

CREATE TABLE `ent_member_removed_tree_sponsor` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `member_lot` int(11) DEFAULT '0',
  `upline_id` int(11) DEFAULT '0',
  `upline_lot` int(11) DEFAULT '0',
  `leg_no` varchar(10) NOT NULL,
  `sponsor_id` int(11) DEFAULT '0',
  `sponsor_lot` int(11) DEFAULT '0',
  `lvl` int(12) NOT NULL DEFAULT '1',
  `elite_id` int(11) DEFAULT '0',
  `elite_lot` int(11) DEFAULT '0',
  `rank` varchar(30) DEFAULT '0',
  `highest_rank` varchar(30) DEFAULT '0',
  `last_rank` varchar(30) DEFAULT '0',
  `package` varchar(30) DEFAULT '0',
  `leverage` varchar(30) NOT NULL,
  `grp_type` varchar(25) NOT NULL,
  `highest_package` varchar(100) DEFAULT NULL,
  `normal_package` varchar(100) DEFAULT NULL,
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `master_account_id` int(11) DEFAULT '0',
  `mapping_sponsor` varchar(100) DEFAULT NULL,
  `mapping_upline` varchar(30) DEFAULT NULL,
  `mapping_elite` varchar(30) DEFAULT NULL,
  `mapping_bigleg` varchar(100) DEFAULT NULL,
  `deleted_by` varchar(30) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_replicate`
--

CREATE TABLE `ent_member_replicate` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `about_us` longtext,
  `about_us_type` int(11) DEFAULT NULL,
  `contact_us` longtext,
  `facebook` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  `instagram` varchar(100) DEFAULT NULL,
  `youtube` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_replicate_slider`
--

CREATE TABLE `ent_member_replicate_slider` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `caption` varchar(300) DEFAULT NULL,
  `path` varchar(100) DEFAULT NULL,
  `avatar` varchar(300) DEFAULT NULL,
  `slider_type` varchar(100) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_replicate_testimonial`
--

CREATE TABLE `ent_member_replicate_testimonial` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `content_auth` varchar(100) DEFAULT NULL,
  `content` varchar(300) DEFAULT NULL,
  `background_img` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_reset_bank`
--

CREATE TABLE `ent_member_reset_bank` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `ent_member_bank_id` int(11) NOT NULL,
  `additional_msg` longtext CHARACTER SET utf8,
  `status` varchar(300) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_setting`
--

CREATE TABLE `ent_member_setting` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `placement_mode` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=manual, 2=auto_left, 2=auto_right',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_status_log`
--

CREATE TABLE `ent_member_status_log` (
  `id` int(11) NOT NULL COMMENT 'This is a insert only table',
  `member_id` int(11) NOT NULL,
  `status` varchar(11) NOT NULL COMMENT 'A=Reactivate, S=Suspend, T=Terminate, C=Cancelled',
  `remark` varchar(50) DEFAULT NULL,
  `created_by` varchar(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_subscription`
--

CREATE TABLE `ent_member_subscription` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `sls_master_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `nick_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `join_date` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `paid_month` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `status` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `remark` varchar(300) DEFAULT NULL,
  `created_by` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_tree_sponsor`
--

CREATE TABLE `ent_member_tree_sponsor` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `member_lot` int(11) DEFAULT '0',
  `upline_id` int(11) DEFAULT '0',
  `upline_lot` int(11) DEFAULT '0',
  `leg_no` varchar(10) NOT NULL,
  `sponsor_id` int(11) DEFAULT '0',
  `sponsor_lot` int(11) DEFAULT '0',
  `lvl` int(12) NOT NULL DEFAULT '1',
  `rank` varchar(30) DEFAULT '0',
  `highest_rank` varchar(30) DEFAULT '0',
  `package` varchar(30) DEFAULT '0',
  `leverage` varchar(30) NOT NULL,
  `grp_type` varchar(25) NOT NULL COMMENT '0 = normal, 1 = free',
  `loan` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `package_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ent_member_tree_sponsor`
--

INSERT INTO `ent_member_tree_sponsor` (`id`, `member_id`, `member_lot`, `upline_id`, `upline_lot`, `leg_no`, `sponsor_id`, `sponsor_lot`, `lvl`, `rank`, `highest_rank`, `package`, `leverage`, `grp_type`, `loan`, `created_by`, `created_at`, `updated_by`, `updated_at`, `package_id`) VALUES
(1, 2, 0, 0, 0, '0', 1, 0, 1, '', '', 'PVEXPERT', '', '0', 0, '1', '2020-01-08 09:19:29', '', '2020-01-08 09:19:29', 4),
(2, 3, 1, 0, 0, '0', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:29', 4),
(3, 4, 2, 3, 0, '1', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(4, 5, 3, 3, 0, '2', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(5, 6, 4, 4, 0, '1', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(6, 7, 5, 4, 0, '2', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(7, 8, 6, 5, 0, '1', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(8, 9, 7, 5, 0, '2', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(9, 10, 8, 6, 0, '1', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(10, 11, 9, 7, 0, '1', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(11, 12, 10, 8, 0, '1', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(12, 13, 11, 9, 0, '1', 0, 0, 1, '', '', 'PVEXPERT', '', '', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 4),
(13, 14, 0, 0, 0, '0', 1, 0, 1, '', '', 'PVMASTER', '', '0', 0, '1', '2020-01-08 09:19:30', '', '2020-01-08 09:19:30', 3),
(14, 15, 1, 0, 0, '0', 0, 0, 1, '', '', 'PVMASTER', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:30', 3),
(15, 16, 2, 15, 0, '1', 0, 0, 1, '', '', 'PVMASTER', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:30', 3),
(16, 17, 3, 15, 0, '2', 0, 0, 1, '', '', 'PVMASTER', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:30', 3),
(17, 18, 4, 16, 0, '1', 0, 0, 1, '', '', 'PVMASTER', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:30', 3),
(18, 19, 5, 16, 0, '2', 0, 0, 1, '', '', 'PVMASTER', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:30', 3),
(19, 20, 6, 17, 0, '1', 0, 0, 1, '', '', 'PVMASTER', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:30', 3),
(20, 21, 7, 17, 0, '2', 0, 0, 1, '', '', 'PVMASTER', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:30', 3),
(21, 22, 0, 0, 0, '0', 1, 0, 1, '', '', 'PVPRO', '', '0', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:31', 2),
(22, 23, 1, 0, 0, '0', 0, 0, 1, '', '', 'PVPRO', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:31', 2),
(23, 24, 2, 23, 0, '1', 0, 0, 1, '', '', 'PVPRO', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:31', 2),
(24, 25, 3, 23, 0, '2', 0, 0, 1, '', '', 'PVPRO', '', '', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:31', 2),
(25, 26, 0, 0, 0, '0', 1, 0, 1, '', '', 'PVUSER', '', '0', 0, '1', '2020-01-08 09:19:31', '', '2020-01-08 09:19:31', 1),
(26, 27, 1, 0, 0, '0', 0, 0, 1, '', '', 'PVUSER', '', '', 0, '1', '2020-01-08 09:19:32', '', '2020-01-08 09:19:31', 1),
(27, 28, 0, 0, 0, '0', 1, 0, 1, '', '', 'PS1', '', '0', 0, '1', '2020-01-08 09:19:32', '', '2020-01-08 09:19:31', 5),
(28, 29, 0, 0, 0, '0', 1, 0, 1, '', '', 'PS2', '', '0', 0, '1', '2020-01-08 09:19:32', '', '2020-01-08 09:19:32', 6);

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_tree_sponsor_log`
--

CREATE TABLE `ent_member_tree_sponsor_log` (
  `id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `eff_date` date DEFAULT NULL,
  `current_sponsor` varchar(30) DEFAULT '0',
  `new_sponsor` varchar(30) DEFAULT '0',
  `current_upline` varchar(30) DEFAULT '0',
  `new_upline` varchar(30) DEFAULT '0',
  `old_leg_no` varchar(10) NOT NULL,
  `new_leg_no` varchar(10) NOT NULL,
  `current_elite` varchar(30) DEFAULT '0',
  `new_elite` varchar(30) DEFAULT '0',
  `date` date DEFAULT NULL,
  `elite_gbv` int(19) DEFAULT '-1',
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ent_member_type_menu`
--

CREATE TABLE `ent_member_type_menu` (
  `id` int(11) NOT NULL,
  `member_type_id` int(11) NOT NULL,
  `sys_menu_id` longtext NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ent_member_type_menu`
--

INSERT INTO `ent_member_type_menu` (`id`, `member_type_id`, `sys_menu_id`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 207, '[500,501,502,503,504,506,507,1000,1001,1100,1201,1202,1400,1401,1402,1410,1411,1412]', 0, '2020-01-08 09:19:15', NULL, NULL),
(2, 208, '[500,501,502,503,504,505,506,1000,1001,1100,1202,1300,1412]', 0, '2020-01-08 09:19:15', NULL, NULL),
(3, 209, '[500,501,502,503,504,505,506,507,1000,1001,1100,1101,1102,1200,1201,1202,1300,1301,1400,1401,1402,1410,1411,1412]', 0, '2020-01-08 09:19:15', NULL, NULL),
(4, 206, '[74,75,76,77,78,79,80,81,82,83,85,86,87,88,89,90,91,92,93,94,95]', 0, '2020-01-08 09:19:15', NULL, NULL),
(5, 205, '[74,75,76,78,79,80,81,82,84,85,87,88,95]', 0, '2020-01-08 09:19:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ent_user`
--

CREATE TABLE `ent_user` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `user_group_id` int(11) NOT NULL,
  `user_type_id` int(11) NOT NULL,
  `register_center_id` int(11) NOT NULL,
  `user_code` varchar(30) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile_no` varchar(30) NOT NULL,
  `prefer_language` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `remember_token` varchar(100) NOT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ewt_detail`
--

CREATE TABLE `ewt_detail` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `ewallet_type_id` int(11) DEFAULT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `transaction_type` varchar(100) DEFAULT NULL,
  `trans_date` datetime DEFAULT NULL,
  `total_in` decimal(25,10) DEFAULT '0.0000000000',
  `total_out` decimal(25,10) DEFAULT '0.0000000000',
  `balance` decimal(25,10) DEFAULT '0.0000000000',
  `doc_no` varchar(25) DEFAULT NULL,
  `additional_msg` longtext CHARACTER SET utf8,
  `remark` longtext CHARACTER SET utf8,
  `ewt_withdraw_id` int(11) DEFAULT '0',
  `ewt_topup_id` int(11) DEFAULT '0',
  `ewt_transfer_id` int(11) NOT NULL,
  `sso_master_id` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ewt_detail`
--

INSERT INTO `ewt_detail` (`id`, `member_id`, `ewallet_type_id`, `currency_code`, `transaction_type`, `trans_date`, `total_in`, `total_out`, `balance`, `doc_no`, `additional_msg`, `remark`, `ewt_withdraw_id`, `ewt_topup_id`, `ewt_transfer_id`, `sso_master_id`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 2, 210, '', 'REG', '2020-01-08 17:19:30', '10888.0000000000', '10888.0000000000', '0.0000000000', '', 'Register Package #*PW*#', 'Register Package #*PW*#', 0, 0, 0, 0, '2020-01-08 10:19:30', '2', NULL, NULL),
(2, 14, 210, '', 'REG', '2020-01-08 17:19:31', '5788.0000000000', '5788.0000000000', '0.0000000000', '', 'Register Package #*PW*#', 'Register Package #*PW*#', 0, 0, 0, 0, '2020-01-08 10:19:31', '14', NULL, NULL),
(3, 22, 210, '', 'REG', '2020-01-08 17:19:31', '2388.0000000000', '2388.0000000000', '0.0000000000', '', 'Register Package #*PW*#', 'Register Package #*PW*#', 0, 0, 0, 0, '2020-01-08 10:19:31', '22', NULL, NULL),
(4, 26, 210, '', 'REG', '2020-01-08 17:19:32', '388.0000000000', '388.0000000000', '0.0000000000', '', 'Register Package #*PW*#', 'Register Package #*PW*#', 0, 0, 0, 0, '2020-01-08 10:19:32', '26', NULL, NULL),
(5, 28, 210, '', 'REG', '2020-01-08 17:19:32', '3888.0000000000', '3888.0000000000', '0.0000000000', '', 'Register Package #*PW*#', 'Register Package #*PW*#', 0, 0, 0, 0, '2020-01-08 10:19:32', '28', NULL, NULL),
(6, 29, 210, '', 'REG', '2020-01-08 17:19:33', '6888.0000000000', '6888.0000000000', '0.0000000000', '', 'Register Package #*PW*#', 'Register Package #*PW*#', 0, 0, 0, 0, '2020-01-08 10:19:33', '29', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ewt_hide`
--

CREATE TABLE `ewt_hide` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `ewallet_type_id` int(11) NOT NULL,
  `hide` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ewt_limiter`
--

CREATE TABLE `ewt_limiter` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `ewallet_type_id` int(11) NOT NULL,
  `internal_transfer` tinyint(1) NOT NULL DEFAULT '0',
  `external_transfer` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'withdrawal',
  `limit_amount` decimal(25,10) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ewt_payment`
--

CREATE TABLE `ewt_payment` (
  `id` int(11) NOT NULL,
  `ewallet_detail_id` int(11) DEFAULT NULL,
  `payment_type_id` int(11) DEFAULT NULL,
  `issue_bank_id` int(11) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `ref_no` varchar(30) DEFAULT NULL,
  `approval_code` varchar(100) DEFAULT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ewt_setup`
--

CREATE TABLE `ewt_setup` (
  `id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `ewallet_type_id` int(11) NOT NULL,
  `registration` tinyint(1) DEFAULT '0',
  `topup` tinyint(1) DEFAULT '0',
  `topup_min` decimal(12,2) DEFAULT '0.00',
  `topup_max` decimal(12,2) DEFAULT '0.00',
  `admin_show` int(11) NOT NULL,
  `member_show` int(11) NOT NULL,
  `show_amt` varchar(20) NOT NULL DEFAULT '0',
  `include_spent_balance` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'use with show_amt',
  `topup_approval` tinyint(1) DEFAULT '0',
  `transfer` tinyint(1) DEFAULT '0',
  `transfer_min` decimal(12,2) DEFAULT '0.00',
  `transfer_max` decimal(12,2) DEFAULT '0.00',
  `transfer_approval` tinyint(1) DEFAULT '0',
  `withdraw` tinyint(1) DEFAULT '0',
  `withdraw_min` decimal(12,2) DEFAULT '0.00' COMMENT '(to exchange)',
  `withdraw_max` decimal(12,2) DEFAULT '0.00' COMMENT '(to exchange)',
  `withdraw_admin_fee` tinyint(5) NOT NULL DEFAULT '0' COMMENT '(to exchange)%',
  `withdrawal_admin_fee` int(11) NOT NULL DEFAULT '0',
  `withdrawal_min` decimal(12,2) DEFAULT '0.00',
  `withdrawal_max` decimal(12,2) DEFAULT '0.00',
  `withdraw_approval` tinyint(1) DEFAULT '0',
  `value` varchar(30) DEFAULT NULL,
  `currency_code` varchar(100) DEFAULT NULL,
  `crypto_addr` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 = required crypto address from api, 0 = no need crypto address via api',
  `crypto_length` int(5) NOT NULL DEFAULT '0' COMMENT 'auto generate crypto address if the value is set more than 0. the crypto address length will be generate according to this value.',
  `decimal_point` int(11) NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ewt_setup`
--

INSERT INTO `ewt_setup` (`id`, `company_id`, `ewallet_type_id`, `registration`, `topup`, `topup_min`, `topup_max`, `admin_show`, `member_show`, `show_amt`, `include_spent_balance`, `topup_approval`, `transfer`, `transfer_min`, `transfer_max`, `transfer_approval`, `withdraw`, `withdraw_min`, `withdraw_max`, `withdraw_admin_fee`, `withdrawal_admin_fee`, `withdrawal_min`, `withdrawal_max`, `withdraw_approval`, `value`, `currency_code`, `crypto_addr`, `crypto_length`, `decimal_point`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 0, 210, 0, 0, '0.00', '0.00', 0, 0, '', 0, 0, 0, '0.00', '0.00', 0, 0, '0.00', '0.00', 0, 0, '0.00', '0.00', 0, '', '', 0, 0, 0, '', '0000-00-00 00:00:00', 0, '2020-01-08 09:19:15', NULL),
(2, 0, 211, 0, 0, '0.00', '0.00', 0, 0, '', 0, 0, 0, '0.00', '0.00', 0, 0, '0.00', '0.00', 0, 0, '0.00', '0.00', 0, '', '', 0, 0, 0, '', '0000-00-00 00:00:00', 0, '2020-01-08 09:19:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ewt_summary`
--

CREATE TABLE `ewt_summary` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `ewallet_type_id` int(11) NOT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `total_in` decimal(25,10) DEFAULT '0.0000000000',
  `total_out` decimal(25,10) DEFAULT '0.0000000000',
  `balance` decimal(25,10) DEFAULT '0.0000000000',
  `temp_balance` decimal(25,10) DEFAULT '0.0000000000',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ewt_summary`
--

INSERT INTO `ewt_summary` (`id`, `member_id`, `ewallet_type_id`, `currency_code`, `total_in`, `total_out`, `balance`, `temp_balance`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 2, 210, NULL, '10888.0000000000', '10888.0000000000', '0.0000000000', '0.0000000000', '2020-01-08 09:19:30', '2', NULL, NULL),
(2, 14, 210, NULL, '5788.0000000000', '5788.0000000000', '0.0000000000', '0.0000000000', '2020-01-08 09:19:30', '14', NULL, NULL),
(3, 22, 210, NULL, '2388.0000000000', '2388.0000000000', '0.0000000000', '0.0000000000', '2020-01-08 09:19:31', '22', NULL, NULL),
(4, 26, 210, NULL, '388.0000000000', '388.0000000000', '0.0000000000', '0.0000000000', '2020-01-08 09:19:31', '26', NULL, NULL),
(5, 28, 210, NULL, '3888.0000000000', '3888.0000000000', '0.0000000000', '0.0000000000', '2020-01-08 09:19:32', '28', NULL, NULL),
(6, 29, 210, NULL, '6888.0000000000', '6888.0000000000', '0.0000000000', '0.0000000000', '2020-01-08 09:19:32', '29', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ewt_topup`
--

CREATE TABLE `ewt_topup` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `ewallet_type_id` int(11) DEFAULT NULL,
  `doc_no` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `trans_date` datetime DEFAULT NULL,
  `total_in` decimal(25,10) DEFAULT '0.0000000000',
  `total_out` decimal(25,10) DEFAULT '0.0000000000',
  `charges` decimal(25,10) DEFAULT '0.0000000000',
  `balance` decimal(25,10) DEFAULT '0.0000000000',
  `converted_currency_code` varchar(30) DEFAULT NULL,
  `conversion_rate` decimal(25,10) DEFAULT '0.0000000000',
  `converted_total_amount` decimal(25,10) DEFAULT '0.0000000000',
  `converted_charge` decimal(25,10) DEFAULT '0.0000000000',
  `additional_msg` longtext,
  `remark` longtext,
  `pgw_trans_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ewt_topup_queue`
--

CREATE TABLE `ewt_topup_queue` (
  `id` int(10) UNSIGNED NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `receipt` varchar(255) DEFAULT NULL,
  `evidence_photo` int(11) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `request_date` timestamp NULL DEFAULT NULL,
  `process_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ewt_transfer`
--

CREATE TABLE `ewt_transfer` (
  `id` int(11) NOT NULL,
  `member_id_from` varchar(255) NOT NULL,
  `member_id_to` varchar(255) NOT NULL,
  `center_id` int(11) DEFAULT NULL,
  `prj_config_code` varchar(25) DEFAULT NULL,
  `doc_no` varchar(25) NOT NULL,
  `api_doc_no` varchar(25) DEFAULT NULL,
  `ewt_transfer_type` varchar(25) DEFAULT NULL COMMENT 'ApiIn/ApiOut/Internal',
  `ewt_type_from` int(11) NOT NULL,
  `ewt_type_to` int(11) NOT NULL,
  `transfer_amount` double(25,10) NOT NULL DEFAULT '0.0000000000',
  `rate` decimal(25,10) DEFAULT '1.0000000000',
  `transfer_amount_to` double(25,10) DEFAULT '0.0000000000',
  `reason` varchar(255) DEFAULT NULL,
  `ref_no` varchar(255) DEFAULT NULL,
  `admin_fee` double(25,10) DEFAULT NULL,
  `upload_img` varchar(255) DEFAULT NULL,
  `crypto_addr_from` text,
  `crypto_addr_to` text,
  `hash` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(30) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_by` varchar(30) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approved_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ewt_transfer_api_log`
--

CREATE TABLE `ewt_transfer_api_log` (
  `id` int(11) NOT NULL,
  `prj_config_code` varchar(30) DEFAULT NULL COMMENT 'Transaction id: sso_mast doc_no / wallet_transfer doc_no and etc',
  `api_doc_no` varchar(25) DEFAULT NULL,
  `ewt_transfer_type` varchar(25) DEFAULT NULL,
  `member_id_from` varchar(255) DEFAULT NULL,
  `member_id_to` varchar(255) DEFAULT NULL,
  `member_user_id_from` varchar(255) DEFAULT NULL,
  `member_user_id_to` varchar(255) DEFAULT NULL,
  `ewt_type_from` varchar(25) DEFAULT NULL,
  `ewt_type_to` varchar(25) DEFAULT NULL,
  `transfer_amount` decimal(25,10) DEFAULT NULL,
  `transfer_amount_to` decimal(25,10) DEFAULT NULL,
  `trans_created_at` datetime DEFAULT NULL,
  `trans_created_by` varchar(25) DEFAULT NULL,
  `trans_approved_at` datetime DEFAULT NULL,
  `trans_approved_by` varchar(25) DEFAULT NULL,
  `request` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ewt_transfer_setup`
--

CREATE TABLE `ewt_transfer_setup` (
  `prj_config_code` varchar(25) DEFAULT NULL,
  `ewt_transfer_type` varchar(25) DEFAULT NULL COMMENT 'ApiIn/ApiOut/Internal',
  `check_ewt_transfer_setup` tinyint(1) NOT NULL DEFAULT '1',
  `ewallet_type_id_from` varchar(15) NOT NULL,
  `transfer_type_id_to` varchar(15) NOT NULL,
  `transfer_same_member` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'using',
  `transfer_other_member` tinyint(1) NOT NULL DEFAULT '0',
  `transfer_upline` tinyint(1) NOT NULL DEFAULT '0',
  `transfer_sponsor` tinyint(1) NOT NULL DEFAULT '0',
  `transfer_upline_tree` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'using',
  `transfer_sponsor_tree` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'using',
  `transfer_downline` tinyint(1) NOT NULL DEFAULT '0',
  `transfer_in_api` tinyint(1) NOT NULL DEFAULT '0',
  `transfer_out_api` tinyint(1) NOT NULL DEFAULT '0',
  `member_show` tinyint(1) NOT NULL DEFAULT '1',
  `transfer_in_api_approval` tinyint(1) NOT NULL DEFAULT '0',
  `transfer_out_api_approval` tinyint(1) NOT NULL DEFAULT '0',
  `transfer_min` double(10,2) NOT NULL DEFAULT '0.00',
  `transfer_max` double(10,2) NOT NULL DEFAULT '0.00',
  `rate` double(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ewt_transfer_setup`
--

INSERT INTO `ewt_transfer_setup` (`prj_config_code`, `ewt_transfer_type`, `check_ewt_transfer_setup`, `ewallet_type_id_from`, `transfer_type_id_to`, `transfer_same_member`, `transfer_other_member`, `transfer_upline`, `transfer_sponsor`, `transfer_upline_tree`, `transfer_sponsor_tree`, `transfer_downline`, `transfer_in_api`, `transfer_out_api`, `member_show`, `transfer_in_api_approval`, `transfer_out_api_approval`, `transfer_min`, `transfer_max`, `rate`) VALUES
('', '', 1, '210', '0', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0.00, 0.00, 0.00),
('', '', 1, '211', '0', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `ewt_type_api_setup`
--

CREATE TABLE `ewt_type_api_setup` (
  `id` int(11) NOT NULL,
  `prj_config_code` varchar(25) NOT NULL COMMENT 'project config code',
  `ewt_type_id` int(11) NOT NULL,
  `ewt_type_code_api` varchar(25) NOT NULL,
  `url_api` varchar(255) NOT NULL COMMENT 'Wallet URL to call',
  `wallet_x_auth` varchar(255) NOT NULL COMMENT 'Wallet X-Authorization (Password for FVI config code)',
  `oauth` varchar(25) DEFAULT NULL COMMENT 'Append this value at the front of the OAuth Token',
  `status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ewt_withdraw`
--

CREATE TABLE `ewt_withdraw` (
  `id` int(11) NOT NULL,
  `doc_no` varchar(30) DEFAULT NULL,
  `member_id` int(11) NOT NULL,
  `ent_member_bank_id` varchar(25) DEFAULT '0',
  `ewallet_type_id` int(11) DEFAULT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `transaction_type` varchar(100) DEFAULT NULL,
  `trans_date` datetime DEFAULT NULL,
  `total_in` decimal(25,10) DEFAULT '0.0000000000',
  `total_out` decimal(25,10) DEFAULT '0.0000000000',
  `charges` decimal(25,10) DEFAULT '0.0000000000',
  `balance` decimal(25,10) DEFAULT '0.0000000000',
  `converted_currency_code` varchar(30) DEFAULT NULL,
  `conversion_rate` decimal(25,10) DEFAULT '0.0000000000',
  `converted_total_amount` decimal(25,10) DEFAULT '0.0000000000',
  `converted_charge` decimal(25,10) DEFAULT '0.0000000000',
  `re_subscript_amt` decimal(25,10) NOT NULL DEFAULT '0.0000000000',
  `additional_msg` longtext CHARACTER SET utf8,
  `remark` longtext,
  `avatar` varchar(100) DEFAULT NULL,
  `path` varchar(300) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exchange_api_log`
--

CREATE TABLE `exchange_api_log` (
  `id` int(25) NOT NULL,
  `prj_config_code` varchar(25) DEFAULT NULL,
  `url_link` varchar(255) DEFAULT NULL,
  `api_type` varchar(100) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `data_sent` text,
  `data_received` longtext,
  `server_data` text,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `exchange_profile_api_log`
--

CREATE TABLE `exchange_profile_api_log` (
  `id` int(25) NOT NULL,
  `prj_config_code` varchar(25) DEFAULT NULL,
  `url_link` varchar(255) DEFAULT NULL,
  `api_type` varchar(30) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `data_sent` text,
  `data_received` longtext,
  `server_data` text,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `exchange_trans_api_log`
--

CREATE TABLE `exchange_trans_api_log` (
  `id` int(25) NOT NULL,
  `api_type` varchar(25) DEFAULT NULL,
  `data_sent` text,
  `data_received` longtext,
  `server_data` text,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `exchange_trans_in`
--

CREATE TABLE `exchange_trans_in` (
  `id` int(30) NOT NULL,
  `prj_config_code` varchar(25) DEFAULT NULL,
  `member_id` varchar(255) NOT NULL,
  `doc_no` varchar(30) DEFAULT NULL,
  `transaction_type` varchar(30) NOT NULL,
  `t_type` varchar(30) NOT NULL,
  `ewt_type_code` varchar(30) NOT NULL,
  `amount` decimal(25,10) NOT NULL,
  `rate` decimal(25,10) NOT NULL,
  `admin_fee` decimal(25,10) NOT NULL,
  `tot_amount` decimal(25,10) NOT NULL,
  `currency_from` varchar(25) NOT NULL,
  `currency_to` varchar(25) NOT NULL,
  `currency_rate` decimal(25,10) NOT NULL,
  `crypto_addr` text NOT NULL,
  `image_url` text NOT NULL,
  `remark` text NOT NULL,
  `status` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(30) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `exchange_trans_out`
--

CREATE TABLE `exchange_trans_out` (
  `id` int(11) NOT NULL,
  `prj_config_code` varchar(25) DEFAULT NULL,
  `member_id` varchar(255) NOT NULL,
  `ewt_type_code` varchar(25) NOT NULL,
  `withdraw_type` varchar(30) DEFAULT NULL,
  `t_type` varchar(25) DEFAULT NULL,
  `transaction_type` varchar(25) DEFAULT NULL,
  `doc_no` varchar(30) NOT NULL,
  `amount` decimal(25,10) NOT NULL COMMENT 'crypto quantity',
  `rate` decimal(25,10) NOT NULL COMMENT 'acm to usd rate',
  `admin_fee` double(25,10) DEFAULT NULL,
  `tot_amount` decimal(25,10) NOT NULL COMMENT 'usd',
  `currency_from` varchar(25) DEFAULT NULL,
  `currency_to` varchar(25) DEFAULT NULL,
  `currency_rate` decimal(25,10) DEFAULT NULL,
  `bank_country_id` varchar(100) DEFAULT NULL,
  `bank_acc_no` varchar(100) DEFAULT NULL,
  `bank_acc_holder` varchar(100) DEFAULT NULL,
  `bank_id` varchar(100) DEFAULT NULL,
  `bank_branch_id` varchar(100) DEFAULT NULL,
  `bank_location` varchar(100) DEFAULT NULL,
  `bank_postal` varchar(100) DEFAULT NULL,
  `crypto_addr` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `status` varchar(25) NOT NULL,
  `trans_date` varchar(25) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `exported_report_list`
--

CREATE TABLE `exported_report_list` (
  `id` int(25) NOT NULL,
  `report_title` varchar(255) NOT NULL,
  `report_group` varchar(25) NOT NULL,
  `parent_id` varchar(25) NOT NULL,
  `report_id` varchar(25) NOT NULL,
  `report_name` varchar(100) NOT NULL,
  `file_access` varchar(255) NOT NULL,
  `report_sql` text NOT NULL,
  `report_sql_type` varchar(10) NOT NULL,
  `report_sql_search_input` text,
  `file_domain` varchar(255) NOT NULL,
  `file_directory` varchar(255) NOT NULL,
  `full_file_path` text NOT NULL,
  `file_show` tinyint(1) NOT NULL DEFAULT '1',
  `status` varchar(25) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(25) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` varchar(25) NOT NULL,
  `delete_at` datetime DEFAULT NULL,
  `delete_by` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `export_file_api_log`
--

CREATE TABLE `export_file_api_log` (
  `id` int(25) NOT NULL,
  `header_sent` text,
  `url_sent` int(11) DEFAULT NULL,
  `data_sent` text,
  `data_received` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `general_api_log`
--

CREATE TABLE `general_api_log` (
  `id` int(25) NOT NULL,
  `prj_config_code` varchar(25) DEFAULT NULL,
  `url_link` varchar(255) DEFAULT NULL,
  `api_type` varchar(30) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `data_sent` text,
  `data_received` longtext,
  `server_data` text,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `ent_member_id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `user_type_id` int(11) DEFAULT '0',
  `user_group_id` int(11) DEFAULT '0',
  `code` varchar(30) DEFAULT NULL,
  `name` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `nick_name` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `mobile_no` varchar(30) DEFAULT '0',
  `preferred_language_code` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `md5_password` varchar(300) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `tmp_password` varchar(300) DEFAULT NULL,
  `exchange_password` varchar(255) NOT NULL COMMENT 'md5(md5(password+salt))',
  `remember_token` longtext,
  `force_logout` int(1) NOT NULL DEFAULT '0',
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `ent_member_id`, `country_id`, `company_id`, `user_type_id`, `user_group_id`, `code`, `name`, `nick_name`, `email`, `mobile_no`, `preferred_language_code`, `status`, `md5_password`, `password`, `tmp_password`, `exchange_password`, `remember_token`, `force_logout`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 2, 1, 1, 206, 3, 'MEM58845864', 'Alisan (V-Expert)', 'vkids-ex', 'alisan@gmail.com', '10123456789', 'zh', 'A', NULL, '$2a$10$uKBUR8QJnpzQB51rFaJcOuJyoKJtjIBQDRuQi.WEpHXjiAT0XBW9G', '123123', '', NULL, 0, '1', '2020-01-08 10:19:30', NULL, NULL),
(2, 14, 1, 1, 206, 3, 'MEM84342648', 'Amanda (V-Master)', 'vkids-ma', 'amande@gmail.com', '10123456789', 'zh', 'A', NULL, '$2a$10$UeiCn3LqQJmcXgqzU6HbYeD6lrJUkgkjG0hVKHlVXbyf0g7DIHMvO', '123123', '', NULL, 0, '1', '2020-01-08 10:19:31', NULL, NULL),
(3, 22, 1, 1, 206, 3, 'MEM46947908', 'Amy (V-Pro)', 'vkids-pr', 'amy@gmail.com', '10123456789', 'zh', 'A', NULL, '$2a$10$2xOapX3fj1Oa1E6VI9.qsuQ8TpeRcbama5ybfVZNtFU5yppn1opL2', '123123', '', NULL, 0, '1', '2020-01-08 10:19:31', NULL, NULL),
(4, 26, 1, 1, 206, 3, 'MEM53882013', 'Nicola (V-User)', 'vkids-us', 'nicola@gmail.com', '10123456789', 'zh', 'A', NULL, '$2a$10$yBpsCHAdglbGO0AUJ0jEFORwb2GtcE5tx2TAK8b/noZt89eq4OBg6', '123123', '', NULL, 0, '1', '2020-01-08 10:19:32', NULL, NULL),
(5, 28, 1, 1, 206, 3, 'MEM48815426', 'Olivia', 'vkids-sp1', 'ilivia@gmail.com', '10123456789', 'zh', 'A', NULL, '$2a$10$18GwxkVZU3vogtjkYbSgPuvtPTNc5zUZVVc1QuOlzs1kFSg/S/tK.', '123123', '', NULL, 0, '1', '2020-01-08 10:19:32', NULL, NULL),
(6, 29, 1, 1, 206, 3, 'MEM98065962', 'Rachel', 'vkids-sp2', 'rose@gmail.com', '10123456789', 'zh', 'A', NULL, '$2a$10$3IqQr8lbh647SbvJ9ClegOsoR2rqbgSuQx9xP0nshzuMqOnjC/vlS', '123123', '', NULL, 0, '1', '2020-01-08 10:19:33', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `member_password_resets`
--

CREATE TABLE `member_password_resets` (
  `nick_name` varchar(190) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `merchants`
--

CREATE TABLE `merchants` (
  `id` int(10) UNSIGNED NOT NULL,
  `ent_company_id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '0',
  `user_group_id` int(11) NOT NULL,
  `referral_nick_name` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `nick_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'P',
  `md5_password` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `merchants_dev`
--

CREATE TABLE `merchants_dev` (
  `id` int(11) NOT NULL,
  `ent_company_id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `user_type_id` int(11) DEFAULT '0',
  `user_group_id` int(11) DEFAULT '0',
  `code` varchar(30) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(30) DEFAULT '0',
  `preferred_language_code` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `tmp_password` varchar(300) DEFAULT NULL,
  `remember_token` longtext,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `merchant_password_resets`
--

CREATE TABLE `merchant_password_resets` (
  `nick_name` varchar(190) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, 'Migrate1Up', 1),
(2, 'Migrate2Up', 1),
(3, 'Migrate3Up', 1),
(4, 'Migrate4Up', 1),
(5, 'Migrate5Up', 1),
(6, 'Migrate6Up', 1),
(7, 'Migrate7Up', 1),
(8, 'Migrate8Up', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mobile_debugger`
--

CREATE TABLE `mobile_debugger` (
  `id` tinyint(4) NOT NULL,
  `error_msg` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_type_country`
--

CREATE TABLE `payment_type_country` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `seq_no` int(11) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `album_id` int(11) DEFAULT NULL,
  `width` double DEFAULT NULL,
  `height` double DEFAULT NULL,
  `photo` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pos_withdraw`
--

CREATE TABLE `pos_withdraw` (
  `id` int(11) NOT NULL,
  `member_id` varchar(25) NOT NULL,
  `ewt_type_code` varchar(25) NOT NULL,
  `withdraw_type` varchar(30) DEFAULT NULL,
  `doc_no` varchar(30) NOT NULL,
  `amount` decimal(25,10) NOT NULL COMMENT 'crypto quantity',
  `rate` decimal(25,10) NOT NULL COMMENT 'acm to usd rate',
  `admin_fee` double(25,10) DEFAULT NULL,
  `tot_amount` decimal(25,10) NOT NULL COMMENT 'usd',
  `bank_country_id` varchar(100) DEFAULT NULL,
  `bank_acc_no` varchar(100) DEFAULT NULL,
  `bank_acc_holder` varchar(100) DEFAULT NULL,
  `bank_id` varchar(100) DEFAULT NULL,
  `bank_branch_id` varchar(100) DEFAULT NULL,
  `bank_location` varchar(100) DEFAULT NULL,
  `bank_postal` varchar(100) DEFAULT NULL,
  `crypto_addr` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `approved_at` datetime DEFAULT '0000-00-00 00:00:00',
  `approved_by` varchar(30) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT '0000-00-00 00:00:00',
  `cancelled_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `prd_brand`
--

CREATE TABLE `prd_brand` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `code` varchar(300) NOT NULL,
  `_name` longtext NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `top` tinyint(1) DEFAULT '0',
  `avatar` varchar(150) DEFAULT NULL,
  `path` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prd_category`
--

CREATE TABLE `prd_category` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL,
  `path` varchar(300) DEFAULT NULL,
  `label` varchar(100) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `seq_no` int(11) DEFAULT '0',
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prd_category_image`
--

CREATE TABLE `prd_category_image` (
  `id` int(11) NOT NULL,
  `prd_category_id` int(11) NOT NULL,
  `avatar` varchar(100) NOT NULL,
  `label` varchar(100) NOT NULL,
  `path` varchar(100) DEFAULT NULL,
  `date_upload` date NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prd_master`
--

CREATE TABLE `prd_master` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(500) NOT NULL,
  `topup` tinyint(4) DEFAULT '0',
  `register` tinyint(4) DEFAULT '0',
  `special_pkg` tinyint(1) DEFAULT '0',
  `prd_group` varchar(100) DEFAULT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `payment_charge` decimal(12,2) DEFAULT '0.00',
  `discount` decimal(12,2) DEFAULT '0.00',
  `seq_no` int(11) DEFAULT '0',
  `status` varchar(30) NOT NULL,
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `leverage` varchar(25) NOT NULL,
  `leverage_type` varchar(25) NOT NULL,
  `max_leg_no` tinyint(2) NOT NULL DEFAULT '2',
  `weekly_dividend` varchar(25) NOT NULL,
  `lot_rank` varchar(25) NOT NULL,
  `re_subscript_rate` varchar(10) NOT NULL COMMENT '%',
  `sponsor_bns` int(11) DEFAULT NULL COMMENT '%',
  `binary_bns` int(11) DEFAULT NULL COMMENT '%',
  `sto_application` varchar(25) DEFAULT NULL,
  `sto_featured` varchar(25) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `tax_type` int(11) DEFAULT NULL,
  `online` tinyint(1) DEFAULT NULL,
  `online_new` tinyint(1) DEFAULT NULL,
  `promotion` tinyint(1) DEFAULT NULL,
  `best_seller` tinyint(1) DEFAULT NULL,
  `display` tinyint(1) DEFAULT NULL,
  `admin` tinyint(1) DEFAULT NULL,
  `warranty` tinyint(1) DEFAULT NULL,
  `warranty_period` int(11) DEFAULT NULL,
  `refund` tinyint(1) DEFAULT NULL,
  `refund_period` int(11) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `brand` int(11) DEFAULT NULL,
  `attribute_set_id` int(11) DEFAULT NULL,
  `sku_code` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prd_master`
--

INSERT INTO `prd_master` (`id`, `country_id`, `company_id`, `code`, `name`, `topup`, `register`, `special_pkg`, `prd_group`, `date_start`, `date_end`, `package_id`, `payment_charge`, `discount`, `seq_no`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`, `leverage`, `leverage_type`, `max_leg_no`, `weekly_dividend`, `lot_rank`, `re_subscript_rate`, `sponsor_bns`, `binary_bns`, `sto_application`, `sto_featured`, `language`, `tax_type`, `online`, `online_new`, `promotion`, `best_seller`, `display`, `admin`, `warranty`, `warranty_period`, `refund`, `refund_period`, `weight`, `brand`, `attribute_set_id`, `sku_code`) VALUES
(1, 0, 0, '', '', 0, 0, 0, NULL, '0000-00-00', '0000-00-00', 0, '0.00', '0.00', 0, 'A', '0', '2020-01-08 10:19:28', NULL, NULL, '', '', 0, '', '', '', 0, 0, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 'PVUSER'),
(2, 0, 0, '', '', 0, 0, 0, NULL, '0000-00-00', '0000-00-00', 0, '0.00', '0.00', 0, 'A', '0', '2020-01-08 10:19:28', NULL, NULL, '', '', 0, '', '', '', 0, 0, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 'PVPRO'),
(3, 0, 0, '', '', 0, 0, 0, NULL, '0000-00-00', '0000-00-00', 0, '0.00', '0.00', 0, 'A', '0', '2020-01-08 10:19:28', NULL, NULL, '', '', 0, '', '', '', 0, 0, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 'PVMASTER'),
(4, 0, 0, '', '', 0, 0, 0, NULL, '0000-00-00', '0000-00-00', 0, '0.00', '0.00', 0, 'A', '0', '2020-01-08 10:19:29', NULL, NULL, '', '', 0, '', '', '', 0, 0, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 'PVEXPERT'),
(5, 0, 0, '', '', 0, 0, 0, NULL, '0000-00-00', '0000-00-00', 0, '0.00', '0.00', 0, 'A', '0', '2020-01-08 10:19:29', NULL, NULL, '', '', 0, '', '', '', 0, 0, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 'PS1'),
(6, 0, 0, '', '', 0, 0, 0, NULL, '0000-00-00', '0000-00-00', 0, '0.00', '0.00', 0, 'A', '0', '2020-01-08 10:19:29', NULL, NULL, '', '', 0, '', '', '', 0, 0, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 'PS2'),
(7, 0, 0, '', '', 0, 0, 0, NULL, '0000-00-00', '0000-00-00', 0, '0.00', '0.00', 0, 'A', '0', '2020-01-08 10:19:29', NULL, NULL, '', '', 0, '', '', '', 0, 0, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 'PM1');

-- --------------------------------------------------------

--
-- Table structure for table `prd_master_desc`
--

CREATE TABLE `prd_master_desc` (
  `id` int(11) NOT NULL,
  `prd_master_id` int(11) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `language_id` varchar(30) DEFAULT NULL,
  `short_desc` longtext CHARACTER SET utf8,
  `long_desc` longtext CHARACTER SET utf8mb4,
  `created_by` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prd_master_image`
--

CREATE TABLE `prd_master_image` (
  `id` int(11) NOT NULL,
  `prd_master_id` int(11) DEFAULT NULL,
  `code` varchar(100) DEFAULT NULL,
  `avatar` varchar(300) DEFAULT NULL,
  `label` varchar(100) DEFAULT NULL,
  `path` longtext,
  `date_upload` date DEFAULT NULL,
  `default_img` tinyint(1) DEFAULT '1',
  `status` varchar(30) DEFAULT NULL,
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `width` double DEFAULT NULL,
  `height` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prd_master_image`
--

INSERT INTO `prd_master_image` (`id`, `prd_master_id`, `code`, `avatar`, `label`, `path`, `date_upload`, `default_img`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`, `width`, `height`) VALUES
(1, 1, NULL, NULL, '', 'Path Image 1', '0000-00-00', 0, 'A', '1', '2020-01-08 10:19:28', NULL, NULL, 13.3100004196167, 12.210000038146973),
(2, 1, NULL, NULL, '', '/assets/images/packages/S5.png', '0000-00-00', 1, 'A', '1', '2020-01-08 10:19:28', NULL, NULL, 10.5, 11.5),
(3, 2, NULL, NULL, '', 'Path Image 1', '0000-00-00', 0, 'A', '1', '2020-01-08 10:19:28', NULL, NULL, 13.3100004196167, 12.210000038146973),
(4, 2, NULL, NULL, '', '/assets/images/packages/S10.png', '0000-00-00', 1, 'A', '1', '2020-01-08 10:19:28', NULL, NULL, 10.5, 11.5),
(5, 3, NULL, NULL, '', 'Path Image 1', '0000-00-00', 0, 'A', '1', '2020-01-08 10:19:28', NULL, NULL, 13.3100004196167, 12.210000038146973),
(6, 3, NULL, NULL, '', '/assets/images/packages/S50.png', '0000-00-00', 1, 'A', '1', '2020-01-08 10:19:28', NULL, NULL, 10.5, 11.5),
(7, 4, NULL, NULL, '', 'Path Image 1', '0000-00-00', 0, 'A', '1', '2020-01-08 10:19:29', NULL, NULL, 13.3100004196167, 12.210000038146973),
(8, 4, NULL, NULL, '', '/assets/images/packages/S100.png', '0000-00-00', 1, 'A', '1', '2020-01-08 10:19:29', NULL, NULL, 10.5, 11.5),
(9, 5, NULL, NULL, '', 'Path Image 1', '0000-00-00', 0, 'A', '1', '2020-01-08 10:19:29', NULL, NULL, 13.3100004196167, 12.210000038146973),
(10, 5, NULL, NULL, '', 'Path Image 2', '0000-00-00', 1, 'A', '1', '2020-01-08 10:19:29', NULL, NULL, 10.5, 11.5),
(11, 6, NULL, NULL, '', 'Path Image 1', '0000-00-00', 0, 'A', '1', '2020-01-08 10:19:29', NULL, NULL, 13.3100004196167, 12.210000038146973),
(12, 6, NULL, NULL, '', 'Path Image 2', '0000-00-00', 1, 'A', '1', '2020-01-08 10:19:29', NULL, NULL, 10.5, 11.5),
(13, 7, NULL, NULL, '', 'Path Image 1', '0000-00-00', 0, 'A', '1', '2020-01-08 10:19:29', NULL, NULL, 13.3100004196167, 12.210000038146973),
(14, 7, NULL, NULL, '', 'Path Image 2', '0000-00-00', 1, 'A', '1', '2020-01-08 10:19:29', NULL, NULL, 10.5, 11.5);

-- --------------------------------------------------------

--
-- Table structure for table `prd_price`
--

CREATE TABLE `prd_price` (
  `id` int(11) NOT NULL,
  `code` varchar(100) DEFAULT NULL,
  `prd_master_id` int(11) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `prd_price_type_id` int(11) DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `unit_pv` decimal(12,2) DEFAULT '0.00',
  `unit_bv` decimal(12,2) DEFAULT '0.00',
  `unit_sv` decimal(12,2) DEFAULT '0.00',
  `unit_nv` decimal(12,2) DEFAULT '0.00',
  `unit_price` decimal(12,2) DEFAULT '0.00',
  `unit_disc` decimal(12,2) DEFAULT '0.00',
  `unit_tax` decimal(12,2) NOT NULL DEFAULT '0.00',
  `unit_cost` decimal(12,2) DEFAULT '0.00',
  `disc_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `ori_unit_price` decimal(12,2) DEFAULT '0.00',
  `ewallet_type_id` int(11) DEFAULT '0',
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prd_price_calc`
--

CREATE TABLE `prd_price_calc` (
  `id` int(11) NOT NULL,
  `margin` decimal(12,2) DEFAULT '0.00',
  `payment_charge` decimal(12,2) DEFAULT '0.00',
  `gt` decimal(12,2) DEFAULT '0.00',
  `discount` decimal(12,2) DEFAULT '0.00',
  `msb` decimal(12,2) DEFAULT '0.00',
  `company_share` decimal(12,2) DEFAULT '0.00',
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prd_price_country`
--

CREATE TABLE `prd_price_country` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `prd_price_type_id` int(11) NOT NULL DEFAULT '0',
  `default_price` tinyint(1) DEFAULT '0',
  `seq_no` int(11) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prd_price_mem_type`
--

CREATE TABLE `prd_price_mem_type` (
  `id` int(11) NOT NULL,
  `mem_type` varchar(30) DEFAULT NULL,
  `prd_price_type_id` int(11) NOT NULL DEFAULT '0',
  `default_price` tinyint(1) DEFAULT '0',
  `seq_no` int(11) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prd_price_type`
--

CREATE TABLE `prd_price_type` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `seq_no` int(11) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `vmore` tinyint(1) DEFAULT NULL,
  `consign` tinyint(1) DEFAULT NULL,
  `retail` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prd_rating_review`
--

CREATE TABLE `prd_rating_review` (
  `id` int(11) NOT NULL,
  `prd_master_id` int(190) NOT NULL,
  `prd_name` varchar(190) NOT NULL,
  `member_id` varchar(190) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(190) NOT NULL,
  `rating` int(30) NOT NULL,
  `review` longtext,
  `status` varchar(30) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_type_varchar`
--

CREATE TABLE `product_attribute_type_varchar` (
  `id` int(10) UNSIGNED NOT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product_eav_attribute`
--

CREATE TABLE `product_eav_attribute` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `is_required` tinyint(1) DEFAULT NULL,
  `is_unique` tinyint(1) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product_link`
--

CREATE TABLE `product_link` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `linked_product_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE `product_master` (
  `id` int(10) UNSIGNED NOT NULL,
  `type_id` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` int(11) DEFAULT '0',
  `visibility` tinyint(1) DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `report_exchange_import`
--

CREATE TABLE `report_exchange_import` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `file_domain` varchar(255) NOT NULL,
  `file_directory` varchar(255) NOT NULL,
  `full_file_path` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `report_mast`
--

CREATE TABLE `report_mast` (
  `i_report_id` int(11) NOT NULL,
  `report_group` varchar(35) NOT NULL,
  `report_title` text NOT NULL,
  `report_desc` varchar(255) NOT NULL,
  `seq` int(11) NOT NULL,
  `b_active` tinyint(1) NOT NULL DEFAULT '1',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `sql_type` varchar(10) NOT NULL COMMENT 'json or raw',
  `file_path` varchar(255) NOT NULL,
  `compulsory_search_field` text NOT NULL,
  `optional_search_field` text NOT NULL,
  `hidden_search_field` text NOT NULL COMMENT 'trigger custom sql to be add in sql',
  `column_list` text NOT NULL,
  `sql_select` text NOT NULL,
  `sql_from` text,
  `sql_inner_join` text,
  `sql_left_join` text,
  `sql_right_join` text,
  `sql_where` text,
  `sql_where_null` text NOT NULL,
  `sql_group_by` text NOT NULL,
  `sql_having_raw` text NOT NULL,
  `sql_order_by` text NOT NULL,
  `custom_sql` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `reum_sato`
--

CREATE TABLE `reum_sato` (
  `id` int(11) NOT NULL,
  `crypto_addr` varchar(255) NOT NULL,
  `private_key` text NOT NULL COMMENT 'All the crypto address is changed to lower case before the conversion.',
  `member_id` int(25) DEFAULT NULL,
  `ewt_type_id` varchar(25) DEFAULT NULL,
  `ewt_type` varchar(25) DEFAULT NULL,
  `qrcode_url` text,
  `dt_get_addr` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `robot_trap_log`
--

CREATE TABLE `robot_trap_log` (
  `id` int(11) NOT NULL,
  `trigger_page` varchar(50) NOT NULL,
  `trigger_type` varchar(50) NOT NULL,
  `input` text,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rwd_period`
--

CREATE TABLE `rwd_period` (
  `id` int(11) NOT NULL,
  `type` varchar(30) DEFAULT NULL,
  `batch_code` varchar(30) DEFAULT NULL,
  `date_from` datetime DEFAULT NULL,
  `date_to` datetime DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `calculate` varchar(1) DEFAULT '0',
  `paid` tinyint(1) DEFAULT '0',
  `calculated_by` varchar(25) DEFAULT '0',
  `calculated_at` datetime DEFAULT NULL,
  `closed_by` varchar(25) DEFAULT '0',
  `closed_at` datetime DEFAULT NULL,
  `paid_by` varchar(25) DEFAULT '0',
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(25) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rwd_setup_master`
--

CREATE TABLE `rwd_setup_master` (
  `id` int(11) NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` varchar(30) NOT NULL,
  `reward_wallet` varchar(100) DEFAULT NULL,
  `rank_number` decimal(12,2) NOT NULL,
  `welcome_pts_desc` varchar(100) NOT NULL,
  `welcome_pts_value` decimal(12,2) DEFAULT NULL,
  `welcome_pts_wallet` varchar(100) DEFAULT NULL,
  `sponsor_pts_desc` varchar(100) DEFAULT NULL,
  `sponsor_pts_value` decimal(12,2) DEFAULT NULL,
  `sponsor_pts_wallet` varchar(100) DEFAULT NULL,
  `level_pts_desc` varchar(100) DEFAULT NULL,
  `min_purchase` decimal(12,2) DEFAULT NULL,
  `max_level` int(11) DEFAULT NULL,
  `compress` tinyint(1) DEFAULT '0',
  `ranking` longtext,
  `levels` longtext,
  `previous_setup_id` int(11) DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rwd_type`
--

CREATE TABLE `rwd_type` (
  `id` int(11) NOT NULL,
  `code` varchar(30) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `seq_no` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sdo_item`
--

CREATE TABLE `sdo_item` (
  `id` int(11) NOT NULL,
  `sdo_master_id` int(11) NOT NULL,
  `prd_master_id` int(11) NOT NULL,
  `prd_price_id` int(11) NOT NULL,
  `prd_price_code` varchar(1130) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `unit_pv` decimal(12,2) NOT NULL,
  `unit_bv` decimal(12,2) NOT NULL,
  `unit_sv` decimal(12,2) DEFAULT '0.00',
  `unit_tax` decimal(12,2) NOT NULL,
  `unit_disc` decimal(12,2) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `sub_total` decimal(12,2) NOT NULL,
  `total_tax` decimal(12,2) NOT NULL,
  `total_disc` decimal(12,2) NOT NULL,
  `total_pv` decimal(12,2) DEFAULT '0.00',
  `total_bv` decimal(12,2) DEFAULT '0.00',
  `total_sv` decimal(12,2) DEFAULT '0.00',
  `status` varchar(30) DEFAULT 'P',
  `conversion_rate` decimal(12,2) DEFAULT '0.00',
  `converted_unit_price` decimal(12,2) DEFAULT '0.00',
  `converted_total_amount` decimal(12,2) DEFAULT '0.00',
  `converted_sub_total` decimal(12,2) DEFAULT '0.00',
  `converted_total_tax` decimal(12,2) DEFAULT '0.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sdo_master`
--

CREATE TABLE `sdo_master` (
  `id` int(11) NOT NULL,
  `sls_master_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT '0',
  `center_id` int(11) DEFAULT '0',
  `member_id` int(11) DEFAULT '0',
  `sponsor_id` int(11) DEFAULT '0',
  `doc_type` varchar(30) DEFAULT NULL,
  `doc_no` varchar(30) DEFAULT NULL,
  `doc_date` date DEFAULT NULL,
  `bns_batch` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `action` varchar(30) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT '0.00',
  `sub_total` decimal(12,2) DEFAULT '0.00',
  `total_tax` decimal(12,2) DEFAULT '0.00',
  `total_disc` decimal(12,2) DEFAULT '0.00',
  `total_delivery` decimal(12,2) DEFAULT '0.00',
  `total_pv` decimal(12,2) DEFAULT '0.00',
  `total_bv` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_sv` decimal(12,2) DEFAULT '0.00',
  `wallet_redeem_value` decimal(12,2) DEFAULT '0.00',
  `wallet_redeem_type` varchar(30) DEFAULT NULL,
  `promo_code` varchar(100) DEFAULT NULL,
  `ref_no` varchar(300) DEFAULT NULL,
  `remark` varchar(300) DEFAULT NULL,
  `tracking_no` varchar(100) DEFAULT NULL,
  `courier_id` int(11) DEFAULT '0',
  `email_update` varchar(30) DEFAULT NULL,
  `shipping_address_id` int(11) DEFAULT '0',
  `billing_address_id` int(11) DEFAULT '0',
  `conversion_rate` decimal(12,2) DEFAULT '0.00',
  `converted_total_amount` decimal(12,2) DEFAULT '0.00',
  `converted_sub_total` decimal(12,2) DEFAULT '0.00',
  `converted_total_tax` decimal(12,2) DEFAULT '0.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `second_auth_setting`
--

CREATE TABLE `second_auth_setting` (
  `action_id` int(11) NOT NULL,
  `path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `send_back_return_ewt_api_log`
--

CREATE TABLE `send_back_return_ewt_api_log` (
  `id` int(25) NOT NULL,
  `ewt_transfer_type` varchar(100) DEFAULT NULL,
  `error_log` varchar(255) DEFAULT NULL,
  `request` text,
  `server` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(25) NOT NULL,
  `user_id` int(25) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `payload` text NOT NULL,
  `last_activity` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sku_code`
--

CREATE TABLE `sku_code` (
  `id` int(10) UNSIGNED NOT NULL,
  `sku_code` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `dimension_d` double DEFAULT NULL,
  `dimension_w` double DEFAULT NULL,
  `dimension_h` double DEFAULT NULL,
  `is_alert` tinyint(1) DEFAULT NULL,
  `qty_alert` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sku_code_photo_relationship`
--

CREATE TABLE `sku_code_photo_relationship` (
  `sku_id` int(11) DEFAULT NULL,
  `photo_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sls_grp_type`
--

CREATE TABLE `sls_grp_type` (
  `grp_type` varchar(25) NOT NULL,
  `grp_desc` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sls_item`
--

CREATE TABLE `sls_item` (
  `id` int(11) NOT NULL,
  `sls_master_id` int(11) NOT NULL,
  `prd_master_id` int(11) NOT NULL,
  `prd_price_id` int(11) NOT NULL,
  `prd_price_code` varchar(1130) DEFAULT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `unit_pv` decimal(12,2) NOT NULL,
  `unit_bv` decimal(12,2) NOT NULL,
  `unit_sv` decimal(12,2) DEFAULT '0.00',
  `unit_nv` decimal(12,2) DEFAULT '0.00',
  `unit_tax` decimal(12,2) NOT NULL,
  `unit_disc` decimal(12,2) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `sub_total` decimal(12,2) NOT NULL,
  `total_tax` decimal(12,2) NOT NULL,
  `total_disc` decimal(12,2) NOT NULL,
  `total_pv` decimal(12,2) DEFAULT '0.00',
  `total_bv` decimal(12,2) DEFAULT '0.00',
  `total_sv` decimal(12,2) DEFAULT '0.00',
  `total_nv` decimal(12,2) DEFAULT '0.00',
  `status` varchar(30) DEFAULT 'P',
  `conversion_rate` decimal(12,2) DEFAULT '0.00',
  `converted_unit_price` decimal(12,2) DEFAULT '0.00',
  `converted_total_amount` decimal(12,2) DEFAULT '0.00',
  `converted_sub_total` decimal(12,2) DEFAULT '0.00',
  `converted_total_tax` decimal(12,2) DEFAULT '0.00',
  `remark` varchar(30) DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sls_item`
--

INSERT INTO `sls_item` (`id`, `sls_master_id`, `prd_master_id`, `prd_price_id`, `prd_price_code`, `qty`, `unit_price`, `unit_pv`, `unit_bv`, `unit_sv`, `unit_nv`, `unit_tax`, `unit_disc`, `total_amount`, `sub_total`, `total_tax`, `total_disc`, `total_pv`, `total_bv`, `total_sv`, `total_nv`, `status`, `conversion_rate`, `converted_unit_price`, `converted_total_amount`, `converted_sub_total`, `converted_total_tax`, `remark`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, 4, 2, NULL, 1, '10888.00', '0.00', '2600.00', '0.00', '0.00', '0.00', '0.00', '10888.00', '10888.00', '0.00', '0.00', '0.00', '2600.00', '0.00', '0.00', 'P', '0.00', '0.00', '0.00', '0.00', '0.00', '0', '2020-01-08 17:19:30', 1, NULL, NULL),
(2, 2, 3, 2, NULL, 1, '5788.00', '0.00', '1400.00', '0.00', '0.00', '0.00', '0.00', '5788.00', '5788.00', '0.00', '0.00', '0.00', '1400.00', '0.00', '0.00', 'P', '0.00', '0.00', '0.00', '0.00', '0.00', '0', '2020-01-08 17:19:31', 1, NULL, NULL),
(3, 3, 2, 2, NULL, 1, '2388.00', '0.00', '550.00', '0.00', '0.00', '0.00', '0.00', '2388.00', '2388.00', '0.00', '0.00', '0.00', '550.00', '0.00', '0.00', 'P', '0.00', '0.00', '0.00', '0.00', '0.00', '0', '2020-01-08 17:19:31', 1, NULL, NULL),
(4, 4, 1, 2, NULL, 1, '388.00', '0.00', '90.00', '0.00', '0.00', '0.00', '0.00', '388.00', '388.00', '0.00', '0.00', '0.00', '90.00', '0.00', '0.00', 'P', '0.00', '0.00', '0.00', '0.00', '0.00', '0', '2020-01-08 17:19:32', 1, NULL, NULL),
(5, 5, 5, 2, NULL, 1, '3888.00', '0.00', '1000.00', '0.00', '0.00', '0.00', '0.00', '3888.00', '3888.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'P', '0.00', '0.00', '0.00', '0.00', '0.00', '0', '2020-01-08 17:19:32', 1, NULL, NULL),
(6, 6, 6, 2, NULL, 1, '6888.00', '0.00', '2000.00', '0.00', '0.00', '0.00', '0.00', '6888.00', '6888.00', '0.00', '0.00', '0.00', '2000.00', '0.00', '0.00', 'P', '0.00', '0.00', '0.00', '0.00', '0.00', '0', '2020-01-08 17:19:33', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sls_master`
--

CREATE TABLE `sls_master` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `center_id` int(11) DEFAULT '0',
  `member_id` int(11) DEFAULT '0',
  `sponsor_id` int(11) DEFAULT '0',
  `prd_master_id` int(11) NOT NULL,
  `doc_type` varchar(30) DEFAULT 'INV',
  `doc_no` varchar(30) DEFAULT NULL,
  `doc_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bns_batch` varchar(10) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `action` varchar(30) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT '0.00',
  `sub_total` decimal(12,2) DEFAULT '0.00',
  `total_tax` decimal(12,2) DEFAULT '0.00',
  `total_disc` decimal(12,2) DEFAULT '0.00',
  `total_delivery` decimal(12,2) DEFAULT '0.00',
  `total_pv` decimal(12,2) DEFAULT '0.00',
  `total_bv` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_sv` decimal(12,2) DEFAULT '0.00',
  `total_nv` decimal(12,2) DEFAULT '0.00',
  `wallet_redeem_value` decimal(12,2) DEFAULT '0.00',
  `wallet_redeem_type` varchar(30) DEFAULT NULL,
  `promo_code` varchar(100) DEFAULT NULL,
  `ref_no` varchar(300) DEFAULT NULL,
  `remark` varchar(300) DEFAULT NULL,
  `tracking_no` varchar(100) DEFAULT NULL,
  `courier_id` int(11) DEFAULT '0',
  `email_update` varchar(30) DEFAULT NULL,
  `shipping_address_id` int(11) DEFAULT '0',
  `billing_address_id` int(11) DEFAULT '0',
  `simple_id` int(11) DEFAULT '0',
  `conversion_rate` decimal(12,2) DEFAULT '0.00',
  `converted_total_amount` decimal(12,2) DEFAULT '0.00',
  `converted_sub_total` decimal(12,2) DEFAULT '0.00',
  `converted_total_tax` decimal(12,2) DEFAULT '0.00',
  `workflow` varchar(300) DEFAULT NULL,
  `leverage` varchar(30) NOT NULL,
  `bns_action` varchar(25) DEFAULT NULL,
  `grp_type` varchar(25) NOT NULL,
  `act_with_pkg` tinyint(1) NOT NULL DEFAULT '0',
  `hash` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_by` varchar(30) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `total_quantity` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sls_master`
--

INSERT INTO `sls_master` (`id`, `country_id`, `company_id`, `center_id`, `member_id`, `sponsor_id`, `prd_master_id`, `doc_type`, `doc_no`, `doc_date`, `bns_batch`, `status`, `action`, `total_amount`, `sub_total`, `total_tax`, `total_disc`, `total_delivery`, `total_pv`, `total_bv`, `total_sv`, `total_nv`, `wallet_redeem_value`, `wallet_redeem_type`, `promo_code`, `ref_no`, `remark`, `tracking_no`, `courier_id`, `email_update`, `shipping_address_id`, `billing_address_id`, `simple_id`, `conversion_rate`, `converted_total_amount`, `converted_sub_total`, `converted_total_tax`, `workflow`, `leverage`, `bns_action`, `grp_type`, `act_with_pkg`, `hash`, `created_at`, `created_by`, `updated_at`, `updated_by`, `cancelled_at`, `cancelled_by`, `approved_at`, `approved_by`, `total_quantity`) VALUES
(1, 1, 1, 0, 2, 1, 4, 'INV', 'INV96859685', '2020-01-08 10:19:30', '2020-01-08', 'A', 'REG', '10888.00', '10888.00', '0.00', '0.00', '0.00', '0.00', '2600.00', '0.00', '0.00', '0.00', NULL, NULL, NULL, NULL, '', 0, NULL, 0, 0, 0, '0.00', '0.00', '0.00', '0.00', NULL, '', 'REG', '0', 0, '', '2020-01-08 17:19:30', '1', NULL, NULL, NULL, '', NULL, NULL, 0),
(2, 1, 1, 0, 14, 1, 3, 'INV', 'INV96959695', '2020-01-08 10:19:31', '2020-01-08', 'A', 'REG', '5788.00', '5788.00', '0.00', '0.00', '0.00', '0.00', '1400.00', '0.00', '0.00', '0.00', NULL, NULL, NULL, NULL, '', 0, NULL, 0, 0, 0, '0.00', '0.00', '0.00', '0.00', NULL, '', 'REG', '0', 0, '', '2020-01-08 17:19:31', '1', NULL, NULL, NULL, '', NULL, NULL, 0),
(3, 1, 1, 0, 22, 1, 2, 'INV', 'INV97059705', '2020-01-08 10:19:31', '2020-01-08', 'A', 'REG', '2388.00', '2388.00', '0.00', '0.00', '0.00', '0.00', '550.00', '0.00', '0.00', '0.00', NULL, NULL, NULL, NULL, '', 0, NULL, 0, 0, 0, '0.00', '0.00', '0.00', '0.00', NULL, '', 'REG', '0', 0, '', '2020-01-08 17:19:31', '1', NULL, NULL, NULL, '', NULL, NULL, 0),
(4, 1, 1, 0, 26, 1, 1, 'INV', 'INV97159715', '2020-01-08 10:19:32', '2020-01-08', 'A', 'REG', '388.00', '388.00', '0.00', '0.00', '0.00', '0.00', '90.00', '0.00', '0.00', '0.00', NULL, NULL, NULL, NULL, '', 0, NULL, 0, 0, 0, '0.00', '0.00', '0.00', '0.00', NULL, '', 'REG', '0', 0, '', '2020-01-08 17:19:32', '1', NULL, NULL, NULL, '', NULL, NULL, 0),
(5, 1, 1, 0, 28, 1, 5, 'INV', 'INV97259725', '2020-01-08 10:19:32', '2020-01-08', 'A', 'REG', '3888.00', '3888.00', '0.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', '0.00', NULL, NULL, NULL, NULL, '', 0, NULL, 0, 0, 0, '0.00', '0.00', '0.00', '0.00', NULL, '', 'REG', '0', 0, '', '2020-01-08 17:19:32', '1', NULL, NULL, NULL, '', NULL, NULL, 0),
(6, 1, 1, 0, 29, 1, 6, 'INV', 'INV97359735', '2020-01-08 10:19:33', '2020-01-08', 'A', 'REG', '6888.00', '6888.00', '0.00', '0.00', '0.00', '0.00', '2000.00', '0.00', '0.00', '0.00', NULL, NULL, NULL, NULL, '', 0, NULL, 0, 0, 0, '0.00', '0.00', '0.00', '0.00', NULL, '', 'REG', '0', 0, '', '2020-01-08 17:19:33', '1', NULL, NULL, NULL, '', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sls_payment`
--

CREATE TABLE `sls_payment` (
  `id` int(11) NOT NULL,
  `sls_master_id` int(11) DEFAULT NULL,
  `payment_type_id` int(11) DEFAULT NULL,
  `payment_type_code` varchar(30) DEFAULT NULL,
  `sso_pin_id` int(50) NOT NULL DEFAULT '0',
  `ewallet_type_id` int(11) DEFAULT '0',
  `ref_no` varchar(100) DEFAULT NULL,
  `approval_no` varchar(100) DEFAULT NULL,
  `remark` longtext,
  `total_amount` decimal(25,10) DEFAULT NULL,
  `paid_date` date DEFAULT NULL,
  `paid_amount` decimal(25,10) DEFAULT NULL,
  `conversion_rate` decimal(12,2) DEFAULT '0.00',
  `converted_paid_amount` decimal(25,10) DEFAULT '0.0000000000',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `mapping_ewallet_type_id` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sms_log`
--

CREATE TABLE `sms_log` (
  `id` int(11) NOT NULL,
  `t_phone` varchar(50) CHARACTER SET utf8 NOT NULL,
  `t_msg` varchar(255) CHARACTER SET utf8 NOT NULL,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `t_url_link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sso_item`
--

CREATE TABLE `sso_item` (
  `id` int(11) NOT NULL,
  `sso_master_id` int(11) NOT NULL,
  `prd_master_id` int(11) NOT NULL,
  `currency_code` varchar(30) NOT NULL,
  `prd_price_id` int(11) NOT NULL,
  `prd_price_code` varchar(1130) DEFAULT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `unit_pv` decimal(12,2) NOT NULL,
  `unit_bv` decimal(12,2) NOT NULL,
  `unit_sv` decimal(12,2) DEFAULT '0.00',
  `unit_nv` decimal(12,2) DEFAULT '0.00',
  `unit_tax` decimal(12,2) NOT NULL DEFAULT '0.00',
  `unit_disc` decimal(12,2) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `sub_total` decimal(12,2) NOT NULL,
  `total_tax` decimal(12,2) NOT NULL,
  `total_disc` decimal(12,2) NOT NULL,
  `total_pv` decimal(12,2) DEFAULT '0.00',
  `total_bv` decimal(12,2) DEFAULT '0.00',
  `total_sv` decimal(12,2) DEFAULT '0.00',
  `total_nv` decimal(12,2) DEFAULT '0.00',
  `conversion_rate` decimal(12,2) DEFAULT '0.00',
  `converted_total_amount` decimal(12,2) DEFAULT '0.00',
  `converted_sub_total` decimal(12,2) DEFAULT '0.00',
  `converted_total_tax` decimal(12,2) DEFAULT '0.00',
  `converted_unit_price` decimal(12,2) DEFAULT '0.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sso_item`
--

INSERT INTO `sso_item` (`id`, `sso_master_id`, `prd_master_id`, `currency_code`, `prd_price_id`, `prd_price_code`, `qty`, `unit_price`, `unit_pv`, `unit_bv`, `unit_sv`, `unit_nv`, `unit_tax`, `unit_disc`, `total_amount`, `sub_total`, `total_tax`, `total_disc`, `total_pv`, `total_bv`, `total_sv`, `total_nv`, `conversion_rate`, `converted_total_amount`, `converted_sub_total`, `converted_total_tax`, `converted_unit_price`, `created_at`, `created_by`, `updated_at`, `updated_by`, `is_admin`) VALUES
(1, 1, 4, 'USD', 2, NULL, 1, '10888.00', '0.00', '2600.00', '0.00', '0.00', '0.00', '0.00', '10888.00', '10888.00', '0.00', '0.00', '0.00', '2600.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2020-01-08 17:19:30', '1', NULL, NULL, 1),
(2, 2, 3, 'USD', 2, NULL, 1, '5788.00', '0.00', '1400.00', '0.00', '0.00', '0.00', '0.00', '5788.00', '5788.00', '0.00', '0.00', '0.00', '1400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2020-01-08 17:19:31', '1', NULL, NULL, 1),
(3, 3, 2, 'USD', 2, NULL, 1, '2388.00', '0.00', '550.00', '0.00', '0.00', '0.00', '0.00', '2388.00', '2388.00', '0.00', '0.00', '0.00', '550.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2020-01-08 17:19:31', '1', NULL, NULL, 1),
(4, 4, 1, 'USD', 2, NULL, 1, '388.00', '0.00', '90.00', '0.00', '0.00', '0.00', '0.00', '388.00', '388.00', '0.00', '0.00', '0.00', '90.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2020-01-08 17:19:32', '1', NULL, NULL, 1),
(5, 5, 5, 'USD', 2, NULL, 1, '3888.00', '0.00', '1000.00', '0.00', '0.00', '0.00', '0.00', '3888.00', '3888.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2020-01-08 17:19:32', '1', NULL, NULL, 1),
(6, 6, 6, 'USD', 2, NULL, 1, '6888.00', '0.00', '2000.00', '0.00', '0.00', '0.00', '0.00', '6888.00', '6888.00', '0.00', '0.00', '0.00', '2000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2020-01-08 17:19:32', '1', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sso_master`
--

CREATE TABLE `sso_master` (
  `id` int(11) NOT NULL,
  `sls_master_id` int(11) DEFAULT '0',
  `country_id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT '0',
  `center_id` int(11) DEFAULT '0',
  `member_id` int(11) DEFAULT '0',
  `sponsor_id` int(11) DEFAULT '0',
  `shipping_address_id` int(11) DEFAULT '0',
  `billing_address_id` int(11) DEFAULT '0',
  `total_quantity` varchar(30) DEFAULT '1',
  `grp_type` varchar(25) NOT NULL COMMENT '3 = SBOP , 2 = BOS , 1 = free , 0 = normal (link_to_sso_pin)',
  `act_with_pkg` tinyint(1) NOT NULL DEFAULT '0',
  `doc_type` varchar(30) DEFAULT 'SO',
  `doc_no` varchar(30) DEFAULT NULL,
  `doc_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `action` varchar(30) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `error_desc` varchar(300) DEFAULT NULL,
  `pgw_trans_id` varchar(100) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT '0.00',
  `sub_total` decimal(12,2) DEFAULT '0.00',
  `total_tax` decimal(12,2) DEFAULT '0.00',
  `total_disc` decimal(12,2) DEFAULT '0.00',
  `total_delivery` decimal(12,2) DEFAULT '0.00',
  `total_pv` decimal(12,2) DEFAULT '0.00',
  `total_bv` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_sv` decimal(12,2) DEFAULT '0.00',
  `total_nv` decimal(12,2) DEFAULT '0.00',
  `conversion_rate` decimal(12,2) DEFAULT '0.00',
  `converted_total_amount` decimal(12,2) DEFAULT '0.00',
  `converted_sub_total` decimal(12,2) DEFAULT '0.00',
  `converted_total_tax` decimal(12,2) DEFAULT '0.00',
  `wallet_redeem_value` decimal(12,2) DEFAULT '0.00',
  `wallet_redeem_type` varchar(30) DEFAULT NULL,
  `promo_code` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sso_master`
--

INSERT INTO `sso_master` (`id`, `sls_master_id`, `country_id`, `company_id`, `center_id`, `member_id`, `sponsor_id`, `shipping_address_id`, `billing_address_id`, `total_quantity`, `grp_type`, `act_with_pkg`, `doc_type`, `doc_no`, `doc_date`, `action`, `status`, `error_desc`, `pgw_trans_id`, `total_amount`, `sub_total`, `total_tax`, `total_disc`, `total_delivery`, `total_pv`, `total_bv`, `total_sv`, `total_nv`, `conversion_rate`, `converted_total_amount`, `converted_sub_total`, `converted_total_tax`, `wallet_redeem_value`, `wallet_redeem_type`, `promo_code`, `created_at`, `created_by`, `updated_at`, `updated_by`, `cancelled_at`, `cancelled_by`, `approved_at`, `approved_by`, `is_admin`) VALUES
(1, 1, 1, 1, 0, 2, 1, 0, 0, '1', '0', 0, 'SO', 'SO0116041160', '2020-01-08 09:19:29', 'REG', '', NULL, NULL, '10888.00', '10888.00', '0.00', '0.00', '0.00', '0.00', '2600.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, NULL, '2020-01-08 17:19:30', '1', '2020-01-08 16:19:29', NULL, NULL, NULL, NULL, NULL, 1),
(2, 2, 1, 1, 0, 14, 1, 0, 0, '1', '0', 0, 'SO', 'SO0116051160', '2020-01-08 09:19:30', 'REG', '', NULL, NULL, '5788.00', '5788.00', '0.00', '0.00', '0.00', '0.00', '1400.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, NULL, '2020-01-08 17:19:31', '1', '2020-01-08 16:19:30', NULL, NULL, NULL, NULL, NULL, 1),
(3, 3, 1, 1, 0, 22, 1, 0, 0, '1', '0', 0, 'SO', 'SO0116061160', '2020-01-08 09:19:31', 'REG', '', NULL, NULL, '2388.00', '2388.00', '0.00', '0.00', '0.00', '0.00', '550.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, NULL, '2020-01-08 17:19:31', '1', '2020-01-08 16:19:31', NULL, NULL, NULL, NULL, NULL, 1),
(4, 4, 1, 1, 0, 26, 1, 0, 0, '1', '0', 0, 'SO', 'SO0116071160', '2020-01-08 09:19:31', 'REG', '', NULL, NULL, '388.00', '388.00', '0.00', '0.00', '0.00', '0.00', '90.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, NULL, '2020-01-08 17:19:32', '1', '2020-01-08 16:19:31', NULL, NULL, NULL, NULL, NULL, 1),
(5, 5, 1, 1, 0, 28, 1, 0, 0, '1', '0', 0, 'SO', 'SO0116081160', '2020-01-08 09:19:32', 'REG', '', NULL, NULL, '3888.00', '3888.00', '0.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, NULL, '2020-01-08 17:19:32', '1', '2020-01-08 16:19:32', NULL, NULL, NULL, NULL, NULL, 1),
(6, 6, 1, 1, 0, 29, 1, 0, 0, '1', '0', 0, 'SO', 'SO0116091160', '2020-01-08 09:19:32', 'REG', '', NULL, NULL, '6888.00', '6888.00', '0.00', '0.00', '0.00', '0.00', '2000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, NULL, '2020-01-08 17:19:32', '1', '2020-01-08 16:19:32', NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sso_payment`
--

CREATE TABLE `sso_payment` (
  `id` int(11) NOT NULL,
  `sso_master_id` int(11) DEFAULT NULL,
  `payment_type_id` int(11) DEFAULT NULL,
  `payment_type_code` varchar(30) DEFAULT NULL,
  `sso_pin_id` int(50) DEFAULT '0',
  `ewallet_type_id` int(11) DEFAULT '0',
  `status` varchar(30) DEFAULT NULL,
  `error_desc` varchar(300) DEFAULT NULL,
  `ref_no` varchar(100) DEFAULT NULL,
  `approval_no` varchar(100) DEFAULT NULL,
  `remark` longtext,
  `paid_date` date DEFAULT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `paid_amount` decimal(25,10) DEFAULT NULL,
  `converted_paid_amount` decimal(25,10) DEFAULT '0.0000000000',
  `conversion_rate` decimal(25,10) DEFAULT '0.0000000000',
  `settlement_currency_code` varchar(30) DEFAULT NULL,
  `settlement_amount` decimal(25,10) DEFAULT NULL,
  `settlement_remark` varchar(300) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sso_pin`
--

CREATE TABLE `sso_pin` (
  `id` int(11) NOT NULL,
  `sso_master_id` int(11) NOT NULL,
  `prd_master_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `pin_code` varchar(30) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `grp_type` varchar(25) DEFAULT NULL,
  `status` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(30) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(30) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_by` varchar(30) DEFAULT NULL,
  `redeem_at` datetime DEFAULT NULL,
  `redeem_by` varchar(30) DEFAULT NULL,
  `redeem_sls_mast_id` int(30) DEFAULT NULL,
  `sls_master_id` int(11) DEFAULT NULL,
  `stuff_information` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sso_pin_payment`
--

CREATE TABLE `sso_pin_payment` (
  `id` int(11) NOT NULL,
  `sso_pin_id` int(11) NOT NULL,
  `ewallet_type_id` int(11) NOT NULL,
  `paid_amount` decimal(25,10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `store_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`store_id`, `code`, `group_id`, `is_active`, `name`) VALUES
(1, 'MY', 1, 1, 'Malaysia'),
(2, 'EN', 1, 1, 'English'),
(3, 'ZH', 1, 1, 'China'),
(4, 'JP', 1, 0, 'Japan'),
(5, 'KR', 1, 0, 'Korea'),
(6, 'ES', 1, 0, 'Esperanto'),
(7, 'IT', 1, 0, 'Italy'),
(8, 'DE', 1, 0, 'German'),
(9, 'AR', 1, 0, 'Arabic');

-- --------------------------------------------------------

--
-- Table structure for table `store_group`
--

CREATE TABLE `store_group` (
  `group_id` int(10) UNSIGNED NOT NULL,
  `default_store_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `store_group`
--

INSERT INTO `store_group` (`group_id`, `default_store_id`, `name`) VALUES
(1, 2, 'Malaysia Group / Malaysia Store');

-- --------------------------------------------------------

--
-- Table structure for table `sys_api`
--

CREATE TABLE `sys_api` (
  `id` int(11) NOT NULL,
  `project_code` varchar(20) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `method` varchar(10) DEFAULT NULL,
  `url` varchar(200) NOT NULL,
  `client_id` varchar(50) NOT NULL,
  `secret` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_bank`
--

CREATE TABLE `sys_bank` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '0',
  `code` varchar(30) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `acc_no_length` varchar(30) DEFAULT NULL,
  `seq_no` int(11) NOT NULL DEFAULT '0',
  `status` varchar(30) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sys_bank`
--

INSERT INTO `sys_bank` (`id`, `country_id`, `code`, `name`, `acc_no_length`, `seq_no`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 1, 'PBB', 'Public Bank', '12', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(2, 1, 'MBB', 'Maybank', '', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(3, 224, 'OCBC', 'OCBC', '12', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(4, 1, 'CIMB', 'CIMB', '', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(5, 1, 'HSBC', 'HSBC', '', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(6, 1, 'RHB', 'RHB', '', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(7, 1, 'HL', 'Hong Leong Bank', '', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(8, 1, 'UOB', 'UOB', '16', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(9, 1, 'Ambank', 'Ambank', '', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(10, 1, 'BSN', 'BSN', '0', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(11, 69, 'BC', 'Bank of China', '12', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(12, 38, 'ACB', 'Act. Bank', '20', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(13, 38, 'MLB', 'Bank of Melbourne', '20', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(15, 224, 'DBS', 'DBS', '14', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(16, 224, 'FEB', 'Far Easten Bank', '16', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sys_courier`
--

CREATE TABLE `sys_courier` (
  `id` int(11) NOT NULL,
  `code` varchar(300) NOT NULL,
  `name` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `seq_no` int(11) DEFAULT '0',
  `status` varchar(30) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_courier_fees`
--

CREATE TABLE `sys_courier_fees` (
  `id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `currency_code` varchar(30) DEFAULT NULL,
  `zip` varchar(30) DEFAULT NULL,
  `courier_id` int(11) DEFAULT NULL,
  `weight_from` decimal(12,3) DEFAULT NULL,
  `weight_to` decimal(12,2) DEFAULT NULL,
  `lower_weight_limit` decimal(12,2) DEFAULT NULL,
  `sub_weight_limit` decimal(12,2) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `start_courier_fees` decimal(12,2) DEFAULT NULL,
  `sub_courier_fees` decimal(12,2) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_currency_rate`
--

CREATE TABLE `sys_currency_rate` (
  `id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `currency_code_frm` varchar(25) NOT NULL,
  `currency_code_to` varchar(25) NOT NULL,
  `in_rate` decimal(25,6) NOT NULL DEFAULT '0.000000',
  `out_rate` decimal(25,6) NOT NULL DEFAULT '0.000000',
  `status` varchar(30) NOT NULL,
  `created_by` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_datagrid`
--

CREATE TABLE `sys_datagrid` (
  `id` int(11) NOT NULL,
  `module_name` varchar(30) NOT NULL,
  `module_title` varchar(100) DEFAULT NULL,
  `module_note` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `template_code` varchar(30) DEFAULT NULL,
  `file_name` text,
  `action` varchar(100) DEFAULT NULL,
  `query` longtext,
  `columns` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_default_password`
--

CREATE TABLE `sys_default_password` (
  `id` int(11) NOT NULL,
  `default_password` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_doc_no`
--

CREATE TABLE `sys_doc_no` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `module` varchar(100) DEFAULT NULL,
  `doc_type` varchar(30) NOT NULL,
  `doc_no_prefix` varchar(100) NOT NULL DEFAULT '',
  `start_no` int(11) NOT NULL,
  `doc_length` int(11) DEFAULT '0',
  `running_no` varchar(100) DEFAULT NULL,
  `running_type` varchar(100) DEFAULT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sys_doc_no`
--

INSERT INTO `sys_doc_no` (`id`, `country_id`, `company_id`, `module`, `doc_type`, `doc_no_prefix`, `start_no`, `doc_length`, `running_no`, `running_type`, `table_name`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 1, 1, '0', 'SO', 'SO01', 11610, 8, '00000001', 'auto', 'sso_master', 1, '2020-01-08 09:16:55', 1, '2020-01-08 09:19:32'),
(2, 0, 1, '0', 'INV', 'INV', 5974, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', 1, '2020-01-08 09:19:32'),
(3, 1, 1, '0', 'MEM', 'MY', 1, 6, '00000001', 'random', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(4, 1, 1, '0', 'M', 'MYM', 1, 6, '000001', NULL, NULL, 1, '2020-01-08 09:16:55', NULL, NULL),
(5, 0, 0, 'Member', 'MEM', 'MEM', 7520, 8, NULL, 'random', 'ent_member', 1, '2020-01-08 09:16:55', 1, '2020-01-08 09:19:32'),
(7, 224, 1, 'Merchant', 'COM', 'SG', 1, 8, NULL, 'random', 'ent_company', 1, '2020-01-08 09:16:55', NULL, NULL),
(11, 1, 0, 'Merchant', 'COM', 'MYCOM', 1, 6, '000001', 'auto', 'ent_company', 1, '2020-01-08 09:16:55', NULL, NULL),
(22, 127, 1, 'Sales', 'CSB', 'CBID', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(23, 224, 0, 'Merchant', 'COM', 'SGCOM', 1, 6, '000001', 'auto', 'ent_company', 1, '2020-01-08 09:16:55', NULL, NULL),
(24, 62, 0, 'Merchant', 'COM', 'CMCOM', 1, 6, '000001', 'random', 'ent_company', 1, '2020-01-08 09:16:55', NULL, NULL),
(25, 81, 0, 'Merchant', 'COM', 'CZCOM', 1, 6, '000001', 'random', 'ent_company', 1, '2020-01-08 09:16:55', NULL, NULL),
(28, 224, 1, 'Member', 'MEM', 'SGMEM', 1, 6, '000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(29, 241, 1, 'Member', 'MEM', 'TWMEM', 1, 6, '000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(30, 241, 1, 'Sales', 'CSB', 'CBTW', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(32, 1, 1, 'Sales', 'CSB', 'CBMY', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(33, 69, 1, 'Member', 'MEM', 'CNMEM', 1, 6, '000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(34, 243, 1, 'Sales', 'CSB', 'CBTH', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(35, 267, 1, 'Sales', 'CSB', 'CBVN', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(36, 69, 1, 'Sales', 'CSB', 'CBCN', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(38, 224, 1, 'Delivery', 'DO', 'DOSG', 1, 8, NULL, 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(39, 1, 1, 'Ewallet', 'WD', 'WD', 332, 8, '00000001', 'auto', 'ewt_withdraw', 1, '2020-01-08 09:16:55', NULL, NULL),
(40, 224, 1, 'Ewallet', 'WD', 'MYWD', 1, 6, '000001', 'auto', 'ewt_withdraw', 1, '2020-01-08 09:16:55', NULL, NULL),
(41, 224, 61, 'Member', 'MEM', 'SGMEM', 1, 6, '000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(42, 1, 1, '0', 'PC', 'PC01', 1, 8, '00000001', 'random', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(44, 69, 1, 'Ewallet', 'ACK', 'ASCN', 1, 8, '000001', 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(45, 224, 1, 'Sales', 'INVXX', 'INVSG', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(46, 123, 1, 'Sales', 'CSB', 'CBHK', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(47, 1, 1, 'Ewallet', 'ACK', 'ASMY', 1, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(48, 127, 1, 'Ewallet', 'ACK', 'ASID', 1, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(49, 200, 1, 'Ewallet', 'ACK', 'ASPH', 1, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(50, 241, 1, 'Ewallet', 'ACK', 'ASTW', 1, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(51, 243, 1, 'Ewallet', 'ACK', 'ASTH', 1, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(52, 267, 1, 'Ewallet', 'ACK', 'ASVN', 1, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(53, 123, 1, 'Ewallet', 'ACK', 'ASHK', 1, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(54, 152, 1, 'Sales', 'CSB', 'CBMO', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(55, 152, 1, 'Ewallet', 'ACK', 'ASMO', 1, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(56, 200, 1, 'Member', 'MEM', 'PHMEM', 1, 8, '00000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(57, 200, 1, 'Sales', 'CSB', 'CBPH', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(58, 243, 1, 'Member', 'MEM', 'TH', 1, 8, NULL, 'random', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(59, 69, 1, 'Delivery', 'DO', 'DOCN', 1, 8, '000001', 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(60, 1, 1, 'Delivery', 'DO', 'DOMY', 1, 8, NULL, 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(61, 127, 1, 'Delivery', 'DO', 'DOID', 1, 8, NULL, 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(62, 200, 1, 'Delivery', 'DO', 'DOPH', 1, 8, NULL, 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(63, 241, 1, 'Delivery', 'DO', 'DOTW', 1, 8, NULL, 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(64, 243, 1, 'Delivery', 'DO', 'DOTH', 1, 8, NULL, 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(65, 267, 1, 'Delivery', 'DO', 'DOVN', 1, 8, NULL, 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(66, 123, 1, 'Delivery', 'DO', 'DOHK', 1, 8, NULL, 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(67, 224, 1, 'Wallet', 'ACK', 'ASSG', 1, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(68, 152, 1, 'Delivery', 'DO', 'DOMO', 1, 8, NULL, 'auto', 'sdo_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(69, 1, 1, 'Prepaid', 'PCV', 'PCVMY', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(70, 69, 1, 'Prepaid', 'PCV', 'PCVCN', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(71, 123, 1, 'Prepaid', 'PCV', 'PCVHK', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(72, 127, 1, 'Prepaid', 'PCV', 'PCVID', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(73, 200, 1, 'Prepaid', 'PCV', 'PCVPH', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(74, 224, 1, 'Prepaid', 'PCV', 'PCVSG', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(75, 241, 1, 'Prepaid', 'PCV', 'PCVTW', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(76, 243, 1, 'Prepaid', 'PCV', 'PCVTH', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(77, 267, 1, 'Prepaid', 'PCV', 'PCVVN', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(78, 152, 1, 'Prepaid', 'PCV', 'PCVMO', 1, 8, NULL, 'auto', 'ent_member_pin', 1, '2020-01-08 09:16:55', NULL, NULL),
(89, 224, 0, 'Sales', 'SPC', 'SGSPC', 1, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(92, 224, 1, 'Sales', 'VM', 'SGVM', 1, 8, NULL, 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(93, 1, 1, 'Sales', 'VM', 'MYVM', 1, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(94, 127, 1, 'Member', 'MEM', 'IDMEM', 1, 8, '00000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(95, 35, 1, 'Member', 'MEM', 'ARMEM', 1, 8, '00000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(96, 126, 1, 'Sales', 'CSB', 'CBIN', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(97, 136, 1, 'Sales', 'CSB', 'CBJP', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(98, 182, 1, 'Sales', 'CSB', 'CBNZ', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(99, 230, 1, 'Sales', 'CSB', 'CBKR', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(100, 257, 1, 'Sales', 'CSB', 'CBUS', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(101, 276, 1, 'Sales', 'CSB', 'CBZW', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(102, 115, 1, 'Sales', 'CSB', 'CBGU', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(103, 38, 1, 'Sales', 'CSB', 'CBAU', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(104, 61, 1, 'Sales', 'CSB', 'CBKH', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(105, 35, 1, 'Sales', 'CSB', 'CBAR', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(106, 398, 1, 'Sales', 'CSB', 'CBCCN', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(107, 398, 1, 'Member', 'MEM', 'CCN', 1, 8, NULL, 'random', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(108, 399, 1, 'Member', 'MEM', 'EMY', 1, 8, NULL, 'random', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(109, 400, 1, 'Member', 'MEM', 'ESG', 1, 8, NULL, 'random', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(110, 399, 1, 'Sales', 'CSB', 'CBEMY', 1, 8, '000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(112, 398, 1, 'Ewallet', 'ACK', 'CCNACK', 1, 8, '00000001', 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL),
(113, 123, 1, 'Member', 'MEM', 'HKMEM', 1, 8, '00000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(115, 1, 1, 'Member', 'MEM', 'MYMEM', 1, 8, '00000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(116, 1, 77, 'Sales', 'CSB', 'MYCSB', 1, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(117, 1, 1, 'Sales', 'INV', 'MYINV', 22, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(119, 69, 1, 'Sales', 'INV', 'CNINV', 1, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(120, 136, 1, 'Member', 'MEM', 'JPMEM', 1, 8, '00000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(121, 230, 1, 'Member', 'MEM', 'KRMEM', 1, 8, '00000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(122, 182, 1, 'Member', 'MEM', 'NZMEM', 1, 8, '00000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(123, 126, 1, 'Member', 'MEM', 'INMEM', 1, 8, '00000001', 'auto', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(124, 267, 1, 'Sales', 'INV', 'VNINV', 1, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(125, 136, 1, 'Sales', 'INV', 'JPINV', 1, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(126, 224, 1, 'Sales', 'INV', 'SGINV', 1, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(127, 1, 1, 'Member', 'WT', 'WT', 716, 8, '00000001', 'auto', 'sls_master', 1, '2020-01-08 09:16:55', NULL, NULL),
(128, 0, 0, 'Member', 'AGT', 'AGT', 0, 8, NULL, 'random', 'ent_member', 1, '2020-01-08 09:16:55', NULL, NULL),
(129, 0, 0, 'Ewallet', 'ACK', 'AS', 61, 8, NULL, 'auto', 'ewt_topup', 1, '2020-01-08 09:16:55', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sys_doc_type`
--

CREATE TABLE `sys_doc_type` (
  `id` int(11) NOT NULL,
  `module` varchar(100) DEFAULT NULL,
  `doc_prefix` varchar(30) DEFAULT NULL,
  `doc_desc` varchar(100) NOT NULL DEFAULT '',
  `table_name` varchar(30) DEFAULT NULL,
  `created_by` varchar(30) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(15) NOT NULL DEFAULT '',
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_export_setting`
--

CREATE TABLE `sys_export_setting` (
  `id` int(11) NOT NULL,
  `page` varchar(100) DEFAULT NULL,
  `controller` varchar(100) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_general`
--

CREATE TABLE `sys_general` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `seq_no` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sys_general`
--

INSERT INTO `sys_general` (`id`, `country_id`, `type`, `code`, `name`, `seq_no`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 1, 'member-status', 'A', 'Active', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(2, 1, 'gender', 'F', 'Female', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(3, 1, 'gender', 'M', 'Male', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(4, 1, 'race', 'C', 'Chinese', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(5, 1, 'race', 'M', 'Malay', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(6, 1, 'payment-type', 'CC', 'Debit Card and Credit Card', 3, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(7, 1, 'payment-type', 'Cash', 'Cash', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(8, 1, 'payment-type', 'IGB', 'Online Transfer', 7, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(9, 1, 'marital', 'S', 'Single', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(10, 1, 'marital', 'M', 'Married', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(11, 1, 'marital', 'D', 'Divorce', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(12, 1, 'contact-type', 'Mob', 'Mobile No', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(14, 1, 'contact-type', 'OFF', 'Office No', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(15, 1, 'contact-type', 'Email', 'Email', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(16, 1, 'contact-type', 'Fax', 'Fax', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(18, 1, 'address-type', 'billing', 'Billing Address', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(19, 1, 'address-type', 'delivery', 'Delivery Address', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(20, 1, 'member-status', 'I', 'Inactive', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(21, 1, 'territory-type', 'Country', 'Country', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(22, 1, 'territory-type', 'Regional', 'Regional', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(23, 1, 'territory-type', 'State', 'State', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(24, 1, 'territory-type', 'City', 'City', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(27, 1, 'location-type', 'HQ', 'Headquarters', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(28, 1, 'location-type', 'BCH', 'Outlet', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(29, 1, 'ecommerce-status', '00', 'Successful', 3, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(30, 1, 'ecommerce-status', '01', 'Unsuccessful', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(31, 0, 'ecommerce-status', '09', 'Error', 5, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(32, 0, 'ecommerce-status', '\'76\'', 'Transaction not found', 6, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(33, 1, 'ecommerce-status', 'D', 'Delivered', 7, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(34, 1, 'ecommerce-status', 'S', 'Shipped', 8, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(36, 1, 'email-category', 'GN', 'General Message', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(37, 1, 'email-category', 'WC', 'Welcome Message Member', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(38, 1, 'courier-company', 'PL', 'Pos Laju', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(39, 1, 'email-category', 'OC', 'Order Complete', 3, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(40, 1, 'address-type', 'both', 'Both', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(41, 1, 'email-category', 'WCAGT', 'Welcome Message Merchant', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(42, 1, 'ecommerce-status', 'A', 'Active', 8, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(45, 1, 'email-category', 'MFP', 'Forgot Password', 5, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(47, 1, 'email-category', 'OS', 'Order is shipped', 5, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(48, 1, 'ecommerce-status', 'P', 'Pending', 9, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(51, 1, 'member-status', 'T', 'Terminated', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(52, 1, 'template-format', 'xls', 'Excel', 1, '1', 1, '2020-01-08 09:16:55', NULL, NULL),
(53, 1, 'input-type', 'TextBox', 'Text Box', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(54, 1, 'input-type', 'Dropdown', 'Drop Down', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(55, 1, 'input-type', 'CheckBox', 'Check Box', 3, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(56, 1, 'input-type', 'Date', 'Date', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(57, 1, 'ecommerce-status', 'V', 'Void', 10, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(58, 1, 'address-type', 'COD', 'Cash on Delivery', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(67, 1, 'general-status', 'A', 'Active', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(68, 1, 'general-status', 'I', 'Inactive', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(69, 224, 'reward-rank', '0', '0 Star', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(70, 224, 'reward-rank', '100', '1 Star', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(71, 224, 'reward-rank', '200', '2 Star', 3, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(72, 224, 'reward-rank', '300', '3 Star', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(73, 224, 'reward-rank', '400', '4 Star', 5, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(74, 224, 'reward-rank', '500', '5 Star', 6, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(75, 224, 'relationship', 'HW', 'Husband and Wife', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(77, 224, 'address-type', 'AA', 'AA', 2, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(78, 224, 'relationship', 'HB', 'Husband and Wife', 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(81, 224, 'location-type', 'BR', 'Branch', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(82, 1, 'location-type', 'BRD', 'Branch', 2, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(83, 224, 'contact-type', 'WHA', 'WhatsApp', 3, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(84, 224, 'contact-type', 'SKE', 'Skype', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(92, 1, 'race', 'In', 'India', 0, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(93, 1, 'payment-type', 'DB', 'Direct Bank Debit', 2, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(95, 1, 'uom', 'box', 'BOXs', 2, '0', 1, '2020-01-08 09:16:55', NULL, NULL),
(96, 1, 'uom', 'pck', 'Pack', 2, '1', 1, '2020-01-08 09:16:55', NULL, NULL),
(97, 1, 'uom', 'unit', 'Unit', 1, '1', 1, '2020-01-08 09:16:55', NULL, NULL),
(99, 1, 'member-status', 'P', 'Pending', 10, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(100, 224, 'currency', 'SGD', 'Singapore Dollar', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(101, 1, 'currency', 'MYR', 'Malaysia Ringgit', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(102, 224, 'currency', 'IDR', 'Indonesia Ringgit', 3, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(103, 0, 'currency', 'THD', 'Thailand Dollars', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(104, 0, 'currency', 'USD', 'US Dollar', 5, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(106, 1, 'uom', 'ETC', 'Etc', 6, '1', 1, '2020-01-08 09:16:55', NULL, NULL),
(107, 1, 'member-status', 'R', 'Reject', 5, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(108, 224, 'payment-type', 'EW', 'EWallet', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(109, 224, 'general-status', 'P', 'Pending', 3, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(111, 1, 'email-category', 'NLT', 'Subscribe Newsletters', 6, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(112, 0, 'ecommerce-status', 'CFM', 'Confirm', 11, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(113, 0, 'ecommerce-status', 'DEL', 'Delivered', 13, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(114, 0, 'ecommerce-status', 'COM', 'Completed', 15, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(115, 0, 'ecommerce-status', 'CNL', 'Cancel', 17, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(117, 0, 'currency', 'TWD', 'Taiwan Dollar', 6, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(118, 224, 'email-category', 'WC-SG', 'Welcome Message Member', NULL, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(119, 69, 'email-category', 'WC-CN', 'Welcome Message Member', NULL, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(120, 1, 'email-category', 'WC-HK-TW-MO', 'Welcome Message Member', NULL, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(121, 0, 'currency', 'CNY', 'Chinese Yuan', 7, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(122, 0, 'currency', 'RMB', 'RenMinBi', 7, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(123, 224, 'general-status', 'R', 'Rejected', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(124, 224, 'general-status', 'AP', 'Approved', 5, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(125, 224, 'bank-account', 'BASG', 'Singapore Bank Account', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(126, 1, 'bank-account', 'BAMY', 'Malaysia Bank Account', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(127, 69, 'bank-account', 'BACN', 'China Bank Account', 3, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(128, 127, 'bank-account', 'BAID', 'Indonesia Bank Account', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(129, 243, 'bank-account', 'BATH', 'Thailand Bank Account', 5, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(130, 241, 'bank-account', 'BATW', 'Taiwan Bank Account', 6, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(131, 9999, 'bank-account', 'PPMY', 'Paypal', 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(132, 1, 'bank-account', 'DCMY', 'Prepaid Debit Card', 5, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(133, 1, 'payment-type', 'PC', 'Prepaid Code', 4, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(134, 224, 'general-status', 'C', 'Cancelled', 6, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(135, 241, 'bank-account', 'DCTW', 'Debit Card', 2, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(140, 224, 'general-status', 'W', 'Waiting Approval', 3, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(141, 1, 'email-category', 'PCV', 'Prepaid Code Voucher', 7, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(142, 1, 'email-category', 'ASM', 'Acknowlegement Slip Mail', 8, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(143, 1, 'member-status', 'C', 'Cancelled', 6, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(144, 1, 'email-category', 'VFP', 'Vmore Forgot Password', 5, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(145, 1, 'email-category', 'MR', 'Merchant Rejected', 10, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(146, 0, 'currency', 'AUS', 'Australia Dollar', 8, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(147, 0, 'currency', 'JPN', 'Japan Yen', 10, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(148, 0, 'currency', 'HKG', 'Hong Kong Dollar', 9, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(149, 0, 'currency', 'KHM', 'Cambodia Riel', 11, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(150, 0, 'currency', 'PRK', 'Korean Republic Won', 12, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(151, 0, 'currency', 'MAC', 'Macau Pataca', 13, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(152, 0, 'currency', 'PHL', 'Philippine Piso', 14, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(153, 0, 'currency', 'VNM', 'Vietnam Dong', 15, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(154, 0, 'currency', 'IND', 'Indian Rupee', 16, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(155, 0, 'currency', 'MMR', 'Myanmar Kyat', 17, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(156, 0, 'currency', 'NZL', 'New Zealand Dollar', 18, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(157, 0, 'currency', 'ZWE', 'Zimbabwe Dollar', 19, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(160, 1, 'email-category', 'MFSP', 'Forgot Secondary Password', 9, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(161, 224, 'payment-type', 'BTC', 'Bitcoin - Available soon on 15 April 2018', 5, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(162, 224, 'payment-type', 'ETH', 'Ethereum - Available soon on 15 April 2018', 6, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(169, 1, 'yes-no-type', '0', 'No', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(170, 1, 'yes-no-type', '1', 'Yes', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(175, 1, 'payment-type', 'PIN', 'PIN', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(180, 1, 'pin-status', 'C', 'Cancel', 6, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(181, 1, 'pin-status', 'R', 'Used', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(182, 1, 'pin-status', 'A', 'Active', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(189, 1, 'group-type', '0', 'Normal', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(190, 1, 'group-type', '1', 'Free', 2, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(191, 1, 'payment-type', 'FREE', 'Free', 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(202, 224, 'general-status', 'PR', 'Process', 4, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(203, 1, 'member-status', 'S', 'Suspended', 6, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(204, 1, 'member-type', 'AGT', 'Agent', 0, 'A', 1, '2020-01-08 10:19:15', NULL, NULL),
(205, 1, 'member-type', 'INA', 'Inactive', 0, 'A', 1, '2020-01-08 10:19:15', NULL, NULL),
(206, 1, 'member-type', 'MEM', 'Member', 0, 'A', 1, '2020-01-08 10:19:15', NULL, NULL),
(207, 1, 'member-type', 'NON-NET', 'Non-Network Member', 0, 'A', 1, '2020-01-08 10:19:15', NULL, NULL),
(208, 1, 'member-type', 'OUT-NET', 'Network Member (Binary Tree Outside)', 0, 'A', 1, '2020-01-08 10:19:15', NULL, NULL),
(209, 1, 'member-type', 'NETTED', 'Network Member (Binary Tree Joined)', 0, 'A', 1, '2020-01-08 10:19:15', NULL, NULL),
(210, 1, 'ewallet-type', 'PW', 'V TOKEN', 1, 'A', 1, '2020-01-08 09:19:15', NULL, NULL),
(211, 1, 'ewallet-type', 'CW', 'V WALLET', 2, 'A', 1, '2020-01-08 09:19:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sys_general_setup`
--

CREATE TABLE `sys_general_setup` (
  `id` int(30) NOT NULL,
  `setting_id` varchar(50) DEFAULT NULL,
  `parent_id` varchar(255) DEFAULT NULL,
  `setting_title` varchar(255) DEFAULT NULL,
  `setting_desc` varchar(255) DEFAULT NULL,
  `input_type_1` varchar(255) DEFAULT NULL,
  `input_value_1` varchar(255) DEFAULT NULL,
  `setting_value_1` varchar(255) DEFAULT NULL,
  `input_type_2` varchar(255) DEFAULT NULL,
  `input_value_2` varchar(255) DEFAULT NULL,
  `setting_value_2` varchar(255) DEFAULT NULL,
  `input_type_3` varchar(255) DEFAULT NULL,
  `input_value_3` varchar(255) DEFAULT NULL,
  `setting_value_3` varchar(255) DEFAULT NULL,
  `input_type_4` varchar(255) DEFAULT NULL,
  `input_value_4` varchar(255) DEFAULT NULL,
  `setting_value_4` varchar(255) DEFAULT NULL,
  `input_type_5` varchar(255) DEFAULT NULL,
  `input_value_5` varchar(255) DEFAULT NULL,
  `setting_value_5` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_group`
--

CREATE TABLE `sys_group` (
  `id` int(11) NOT NULL,
  `country_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `code` varchar(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `seq_no` int(11) DEFAULT '0',
  `admin_show` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sys_group`
--

INSERT INTO `sys_group` (`id`, `country_id`, `company_id`, `code`, `name`, `parent_id`, `lft`, `rgt`, `seq_no`, `admin_show`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 0, 0, 'DEV', 'Developers', 0, NULL, NULL, 0, 1, 0, '0000-00-00 00:00:00', NULL, NULL),
(2, 0, 0, 'SA', 'System Administrator', 1, NULL, NULL, 0, 1, 0, '0000-00-00 00:00:00', NULL, NULL),
(3, 0, 0, 'MEM', 'Member', 2, NULL, NULL, 0, 1, 0, '0000-00-00 00:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sys_group_menu`
--

CREATE TABLE `sys_group_menu` (
  `id` int(11) NOT NULL,
  `sys_group_id` int(11) NOT NULL,
  `sys_menu_id` longtext NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_group_menu`
--

INSERT INTO `sys_group_menu` (`id`, `sys_group_id`, `sys_menu_id`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 1, '[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76]', 0, '0000-00-00 00:00:00', NULL, NULL),
(2, 2, '[1,2,4,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,54,55,56,57,58,59,60,61,62,63,64,65,66,67,74,75,76]', 0, '0000-00-00 00:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sys_group_menu_action`
--

CREATE TABLE `sys_group_menu_action` (
  `sys_group_id` int(11) DEFAULT NULL,
  `sys_menu_id` int(11) DEFAULT NULL,
  `checked` tinyint(1) DEFAULT NULL,
  `action_permit` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sys_group_menu_action`
--

INSERT INTO `sys_group_menu_action` (`sys_group_id`, `sys_menu_id`, `checked`, `action_permit`) VALUES
(1, 1, 1, 'ADEPUV'),
(1, 2, 1, 'ADEPUV'),
(1, 3, 1, 'ADEPUV'),
(1, 4, 1, 'ADEPUV'),
(1, 5, 1, 'ADEPUV'),
(1, 6, 1, 'ADEPUV'),
(1, 7, 1, 'ADEPUV'),
(1, 8, 1, 'ADEPUV'),
(1, 9, 1, 'ADEPUV'),
(1, 10, 1, 'ADEPUV'),
(1, 11, 1, 'ADEPUV'),
(1, 12, 1, 'ADEPUV'),
(1, 13, 1, 'ADEPUV'),
(1, 14, 1, 'ADEPUV'),
(1, 15, 1, 'ADEPUV'),
(1, 16, 1, 'ADEPUV'),
(1, 17, 1, 'ADEPUV'),
(1, 18, 1, 'ADEPUV'),
(1, 19, 1, 'ADEPUV'),
(1, 20, 1, 'ADEPUV'),
(1, 21, 1, 'ADEPUV'),
(1, 22, 1, 'ADEPUV'),
(1, 23, 1, 'ADEPUV'),
(1, 24, 1, 'ADEPUV'),
(1, 25, 1, 'ADEPUV'),
(1, 26, 1, 'ADEPUV'),
(1, 27, 1, 'ADEPUV'),
(1, 28, 1, 'ADEPUV'),
(1, 29, 1, 'ADEPUV'),
(1, 30, 1, 'ADEPUV'),
(1, 31, 1, 'ADEPUV'),
(1, 32, 1, 'ADEPUV'),
(1, 33, 1, 'ADEPUV'),
(1, 34, 1, 'ADEPUV'),
(1, 35, 1, 'ADEPUV'),
(1, 36, 1, 'ADEPUV'),
(1, 37, 1, 'ADEPUV'),
(1, 38, 1, 'ADEPUV'),
(1, 39, 1, 'ADEPUV'),
(1, 40, 1, 'ADEPUV'),
(1, 41, 1, 'ADEPUV'),
(1, 42, 1, 'ADEPUV'),
(1, 43, 1, 'ADEPUV'),
(1, 44, 1, 'ADEPUV'),
(1, 45, 1, 'ADEPUV'),
(1, 46, 1, 'ADEPUV'),
(1, 47, 1, 'ADEPUV'),
(1, 48, 1, 'ADEPUV'),
(1, 49, 1, 'ADEPUV'),
(1, 50, 1, 'ADEPUV'),
(1, 51, 1, 'ADEPUV'),
(1, 52, 1, 'ADEPUV'),
(1, 53, 1, 'ADEPUV'),
(1, 54, 1, 'ADEPUV'),
(1, 55, 1, 'ADEPUV'),
(1, 56, 1, 'ADEPUV'),
(1, 57, 1, 'ADEPUV'),
(1, 58, 1, 'ADEPUV'),
(1, 59, 1, 'ADEPUV'),
(1, 60, 1, 'ADEPUV'),
(1, 61, 1, 'ADEPUV'),
(1, 62, 1, 'ADEPUV'),
(1, 63, 1, 'ADEPUV'),
(1, 64, 1, 'ADEPUV'),
(1, 65, 1, 'ADEPUV'),
(1, 66, 1, 'ADEPUV'),
(1, 67, 1, 'ADEPUV'),
(1, 68, 1, 'ADEPUV'),
(1, 69, 1, 'ADEPUV'),
(1, 70, 1, 'ADEPUV'),
(1, 71, 1, 'ADEPUV'),
(1, 72, 1, 'ADEPUV'),
(1, 73, 1, 'ADEPUV'),
(1, 74, 1, 'ADEPUV'),
(1, 75, 1, 'ADEPUV'),
(1, 76, 1, 'ADEPUV'),
(2, 1, 1, 'ADEPUV'),
(2, 2, 1, 'ADEPUV'),
(2, 4, 1, 'ADEPUV'),
(2, 6, 1, 'ADEPUV'),
(2, 7, 1, 'ADEPUV'),
(2, 8, 1, 'ADEPUV'),
(2, 9, 1, 'ADEPUV'),
(2, 11, 1, 'ADEPUV'),
(2, 12, 1, 'ADEPUV'),
(2, 13, 1, 'ADEPUV'),
(2, 14, 1, 'ADEPUV'),
(2, 15, 1, 'ADEPUV'),
(2, 16, 1, 'ADEPUV'),
(2, 17, 1, 'ADEPUV'),
(2, 18, 1, 'ADEPUV'),
(2, 19, 1, 'ADEPUV'),
(2, 20, 1, 'ADEPUV'),
(2, 21, 1, 'ADEPUV'),
(2, 22, 1, 'ADEPUV'),
(2, 23, 1, 'ADEPUV'),
(2, 24, 1, 'ADEPUV'),
(2, 25, 1, 'ADEPUV'),
(2, 26, 1, 'ADEPUV'),
(2, 27, 1, 'ADEPUV'),
(2, 28, 1, 'ADEPUV'),
(2, 29, 1, 'ADEPUV'),
(2, 30, 1, 'ADEPUV'),
(2, 31, 1, 'ADEPUV'),
(2, 32, 1, 'ADEPUV'),
(2, 33, 1, 'ADEPUV'),
(2, 34, 1, 'ADEPUV'),
(2, 35, 1, 'ADEPUV'),
(2, 36, 1, 'ADEPUV'),
(2, 37, 1, 'ADEPUV'),
(2, 38, 1, 'ADEPUV'),
(2, 39, 1, 'ADEPUV'),
(2, 40, 1, 'ADEPUV'),
(2, 41, 1, 'ADEPUV'),
(2, 42, 1, 'ADEPUV'),
(2, 43, 1, 'ADEPUV'),
(2, 44, 1, 'ADEPUV'),
(2, 45, 1, 'ADEPUV'),
(2, 46, 1, 'ADEPUV'),
(2, 47, 1, 'ADEPUV'),
(2, 48, 1, 'ADEPUV'),
(2, 49, 1, 'ADEPUV'),
(2, 50, 1, 'ADEPUV'),
(2, 51, 1, 'ADEPUV'),
(2, 54, 1, 'ADEPUV'),
(2, 55, 1, 'ADEPUV'),
(2, 56, 1, 'ADEPUV'),
(2, 57, 1, 'ADEPUV'),
(2, 58, 1, 'ADEPUV'),
(2, 59, 1, 'ADEPUV'),
(2, 60, 1, 'ADEPUV'),
(2, 61, 1, 'ADEPUV'),
(2, 62, 1, 'ADEPUV'),
(2, 63, 1, 'ADEPUV'),
(2, 64, 1, 'ADEPUV'),
(2, 65, 1, 'ADEPUV'),
(2, 66, 1, 'ADEPUV'),
(2, 67, 1, 'ADEPUV'),
(2, 74, 1, 'ADEPUV'),
(2, 75, 1, 'ADEPUV'),
(2, 76, 1, 'ADEPUV');

-- --------------------------------------------------------

--
-- Table structure for table `sys_language`
--

CREATE TABLE `sys_language` (
  `id` int(11) NOT NULL,
  `locale` varchar(30) DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_log`
--

CREATE TABLE `sys_log` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL COMMENT 'who change',
  `member_id` int(11) DEFAULT NULL COMMENT 'change who',
  `type` varchar(50) NOT NULL COMMENT 'modify',
  `event` varchar(100) NOT NULL,
  `status` varchar(11) NOT NULL COMMENT 'F=Failed, S=Success',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `submit_data` longtext,
  `old_value` longtext,
  `new_value` longtext,
  `ip_address` varchar(100) NOT NULL,
  `ip_location` text,
  `device` text,
  `server_data` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_login_attempts_log`
--

CREATE TABLE `sys_login_attempts_log` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `login_type` varchar(50) NOT NULL COMMENT 'admin/member',
  `client_ip` text NOT NULL,
  `attempts` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_login_detail_log`
--

CREATE TABLE `sys_login_detail_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `input` text,
  `status` varchar(20) NOT NULL,
  `login_type` varchar(20) NOT NULL COMMENT 'admin/member',
  `device_type` varchar(100) DEFAULT NULL,
  `client_ip` longtext,
  `source_ip` longtext,
  `country` varchar(50) DEFAULT NULL,
  `location` longtext NOT NULL,
  `domain` longtext NOT NULL,
  `server_data` longtext NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_login_failed_log`
--

CREATE TABLE `sys_login_failed_log` (
  `id` int(11) NOT NULL,
  `input` text,
  `login_type` varchar(20) NOT NULL COMMENT 'admin/member',
  `device_type` varchar(100) DEFAULT NULL,
  `client_ip` longtext,
  `source_ip` longtext,
  `country` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_login_locked_account_log`
--

CREATE TABLE `sys_login_locked_account_log` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `login_type` varchar(10) NOT NULL COMMENT 'admin/member',
  `client_ip` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_login_log`
--

CREATE TABLE `sys_login_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `login_type` varchar(20) NOT NULL COMMENT 'admin/member',
  `device_type` varchar(100) DEFAULT NULL,
  `client_ip` longtext,
  `source_ip` longtext,
  `country` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_menu`
--

CREATE TABLE `sys_menu` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `module_name` varchar(30) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `seq_no` int(11) DEFAULT NULL,
  `file_path` varchar(100) NOT NULL,
  `top_id` text,
  `menu_icon` varchar(100) DEFAULT NULL,
  `app_footer_menu` int(25) DEFAULT NULL,
  `app_ina_footer_menu` int(25) DEFAULT NULL,
  `app_menu_icon` varchar(50) DEFAULT NULL,
  `popup` tinyint(1) DEFAULT '0',
  `status` varchar(30) NOT NULL DEFAULT 'A',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `module` int(11) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `action_permit` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_menu`
--

INSERT INTO `sys_menu` (`id`, `name`, `module_name`, `parent_id`, `level`, `lft`, `rgt`, `seq_no`, `file_path`, `top_id`, `menu_icon`, `app_footer_menu`, `app_ina_footer_menu`, `app_menu_icon`, `popup`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`, `module`, `path`, `action_permit`) VALUES
(1, 'Member', '', 0, 0, NULL, NULL, 1, '', NULL, 'user', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(2, 'Member List', '', 1, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member/member-list', 'ADEPUV'),
(3, 'Register', '', 1, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member/register', 'ADEPUV'),
(4, 'Account Setting', '', 1, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member/account-setting', 'ADEPUV'),
(5, 'Add Agent', '', 1, 0, NULL, NULL, 4, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member/agent-registration', 'ADEPUV'),
(6, 'Wallet', '', 0, 0, NULL, NULL, 2, '', NULL, 'wallet', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(7, 'Adjustment', '', 6, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'ewallet/adjustment', 'ADEPUV'),
(8, 'Transfer', '', 6, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'ewallet/transfer', 'ADEPUV'),
(9, 'Statement', '', 6, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'ewallet/statement', 'ADEPUV'),
(10, 'Withdraw Approval List', '', 6, 0, NULL, NULL, 4, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'ewallet/withdraw-approval-list', 'ADEPUV'),
(11, 'Transaction List', '', 6, 0, NULL, NULL, 5, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'ewallet/transaction-list', 'ADEPUV'),
(12, 'Balance List', '', 6, 0, NULL, NULL, 6, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'ewallet/balance-list', 'ADEPUV'),
(13, 'Member wallet Lock', '', 6, 0, NULL, NULL, 7, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'ewallet/member-wallet-lock', 'ADEPUV'),
(14, 'Purchase Token List', '', 6, 0, NULL, NULL, 8, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'ewallet/purchase-token-list', 'ADEPUV'),
(15, 'System Setting', '', 0, 0, NULL, NULL, 12, '', NULL, 'setting', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(16, 'Menus', '', 15, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'system/menu', 'ADEPUV'),
(17, 'Modules', '', 15, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'system/modules', 'ADEPUV'),
(18, 'Countries', '', 15, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'system/countries', 'ADEPUV'),
(19, 'Document Type', '', 15, 0, NULL, NULL, 4, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'system/document-type', 'ADEPUV'),
(20, 'Wallet Type', '', 15, 0, NULL, NULL, 5, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'system/ewallet-type', 'ADEPUV'),
(21, 'Payment Setting', '', 15, 0, NULL, NULL, 6, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'system/payment-setting', 'ADEPUV'),
(22, 'General Setting', '', 0, 0, NULL, NULL, 13, '', NULL, 'setting', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(23, 'Gender', '', 22, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/gender', 'ADEPUV'),
(24, 'Bank', '', 22, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/bank', 'ADEPUV'),
(25, 'Relationship', '', 22, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/relationship', 'ADEPUV'),
(26, 'Center Type', '', 22, 0, NULL, NULL, 4, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/center-type', 'ADEPUV'),
(27, 'Contact Type', '', 22, 0, NULL, NULL, 5, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/contact-type', 'ADEPUV'),
(28, 'Marital Status', '', 22, 0, NULL, NULL, 6, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/marital-status', 'ADEPUV'),
(29, 'Race', '', 22, 0, NULL, NULL, 7, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/race', 'ADEPUV'),
(30, 'Payment Type', '', 22, 0, NULL, NULL, 8, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/payment-type', 'ADEPUV'),
(31, 'Member Type', '', 22, 0, NULL, NULL, 9, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/member-type', 'ADEPUV'),
(32, 'Member Status', '', 22, 0, NULL, NULL, 10, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/member-status', 'ADEPUV'),
(33, 'Territory Type', '', 22, 0, NULL, NULL, 11, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/territory-type', 'ADEPUV'),
(34, 'Territory', '', 22, 0, NULL, NULL, 12, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/territory', 'ADEPUV'),
(35, 'Withdraw Payment Type', '', 22, 0, NULL, NULL, 13, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/withdraw-payment', 'ADEPUV'),
(36, 'Currency', '', 22, 0, NULL, NULL, 14, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'general/currency', 'ADEPUV'),
(37, 'Admin', '', 0, 0, NULL, NULL, 11, '', NULL, 'user', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(38, 'User List', '', 37, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'user/user-list', 'ADEPUV'),
(39, 'User Group', '', 37, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'user/user-group', 'ADEPUV'),
(40, 'Sales', '', 0, 0, NULL, NULL, 3, '', NULL, 'shop', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(41, 'Purchase Pin', '', 40, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'sales/purchase-pin', 'ADEPUV'),
(42, 'Topup By Pin', '', 40, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'sales/topup-pin', 'ADEPUV'),
(43, 'Pin List', '', 40, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'sales/pin-list', 'ADEPUV'),
(44, 'Sales List', '', 40, 0, NULL, NULL, 4, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'sales/sales-list', 'ADEPUV'),
(45, 'Topup MW', '', 40, 0, NULL, NULL, 5, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'sales/topup-mw', 'ADEPUV'),
(46, 'Genealogy Tree', '', 0, 0, NULL, NULL, 4, '', NULL, 'cluster', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(47, 'Sponsor Tree', '', 46, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'network/referral-tree', 'ADEPUV'),
(48, 'Trace Sponsor Tree', '', 46, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'network/trace-referral-tree', 'ADEPUV'),
(49, 'Placement Tree', '', 46, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'network/node-tree', 'ADEPUV'),
(50, 'Trace Placement Tree', '', 46, 0, NULL, NULL, 4, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'network/trace-node-tree', 'ADEPUV'),
(51, 'Change Member Lot', '', 46, 0, NULL, NULL, 5, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'network/change-member-lot', 'ADEPUV'),
(52, 'Reward', '', 0, 0, NULL, NULL, 5, '', NULL, 'gift', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(53, 'Statement', '', 52, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(54, 'Announcement Setting', '', 0, 0, NULL, NULL, 6, '', NULL, 'bell', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(55, 'Announcement List', '', 54, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'announcement/announcement-list', 'ADEPUV'),
(56, 'Download List', '', 54, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'announcement/download-list', 'ADEPUV'),
(57, 'Link List', '', 54, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(58, 'Term & Condition List', '', 54, 0, NULL, NULL, 4, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(59, 'Product', '', 0, 0, NULL, NULL, 7, '', NULL, 'block', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(60, 'Product Approved List', '', 59, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'product/product-list', 'ADEPUV'),
(61, 'Product Add', '', 59, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'product/product-create', 'ADEPUV'),
(62, 'Price Type', '', 59, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'product/price-type', 'ADEPUV'),
(63, 'Price Type vs Country', '', 59, 0, NULL, NULL, 4, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'product/price-country', 'ADEPUV'),
(64, 'SKU List', '', 59, 0, NULL, NULL, 5, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'product/sku-code-list', 'ADEPUV'),
(65, 'Product Pending List', '', 59, 0, NULL, NULL, 6, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(66, 'Discount', '', 0, 0, NULL, NULL, 8, '', NULL, 'gift', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(67, 'Discount Setting', '', 66, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(68, 'Stock', '', 0, 0, NULL, NULL, 9, '', NULL, 'shop', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(69, 'Stock Report', '', 68, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(70, 'Stock Setting', '', 68, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(71, 'Delivery', '', 0, 0, NULL, NULL, 10, '', NULL, 'shop', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(72, 'Delivery Setting', '', 71, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(73, 'Delivery List', '', 71, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(74, 'Album', '', 0, 0, NULL, NULL, 14, '', NULL, 'setting', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(75, 'Photo', '', 74, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'album/photos', 'ADEPUV'),
(76, 'Video', '', 74, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'album/videos', 'ADEPUV'),
(500, 'Member Menu', '', 0, 0, NULL, NULL, 15, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(501, 'Announcement', '', 500, 0, NULL, NULL, 1, '', NULL, 'bell', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/announcement', 'ADEPUV'),
(502, 'Gallery', '', 500, 0, NULL, NULL, 2, '', NULL, 'rewards', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/gallery', 'ADEPUV'),
(503, 'Membership Profile', '', 500, 0, NULL, NULL, 3, '', NULL, 'user', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(504, 'Order', '', 500, 0, NULL, NULL, 4, '', NULL, 'sales', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(505, 'Genealogy Tree', '', 500, 0, NULL, NULL, 5, '', NULL, 'genealogy-tree', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(506, 'V-Wallet', '', 500, 0, NULL, NULL, 6, '', NULL, 'wallet', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, '', 'ADEPUV'),
(507, 'E-Code', '', 500, 0, NULL, NULL, 7, '', NULL, 'rewards', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/ecode', 'ADEPUV'),
(1000, 'Photo', '', 502, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'I', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/album/photos', 'ADEPUV'),
(1001, 'Video', '', 502, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'I', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/album/videos', 'ADEPUV'),
(1100, 'Profile', '', 503, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/profile', 'ADEPUV'),
(1101, 'Upgrade', '', 503, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/upgrade', 'ADEPUV'),
(1102, 'New Register', '', 503, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/register', 'ADEPUV'),
(1200, 'Online Order', '', 504, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/purchase', 'ADEPUV'),
(1201, 'Maintenance', '', 504, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/maintenance', 'ADEPUV'),
(1202, 'Order History', '', 504, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/order-history', 'ADEPUV'),
(1300, 'My Sponsor', '', 505, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/sponsor', 'ADEPUV'),
(1301, 'Placement', '', 505, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/placement', 'ADEPUV'),
(1400, 'Purchase V-Token', '', 506, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'temporary', 'ADEPUV'),
(1401, 'VSchool Trend Product', '', 1400, 0, NULL, NULL, 1, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/purchase-token', 'ADEPUV'),
(1402, 'V-Token History', '', 1400, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/purchase-token-history', 'ADEPUV'),
(1410, 'V-Token Transaction', '', 506, 0, NULL, NULL, 2, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/home', 'ADEPUV'),
(1411, 'Income Withdraw', '', 506, 0, NULL, NULL, 3, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/home', 'ADEPUV'),
(1412, 'Account History', '', 506, 0, NULL, NULL, 4, '', NULL, '', NULL, NULL, NULL, 0, 'A', 0, '2020-01-08 09:19:13', NULL, '2020-01-08 09:19:13', 0, 'member-menu/ewallet-statement', 'ADEPUV');

-- --------------------------------------------------------

--
-- Table structure for table `sys_mobile_api`
--

CREATE TABLE `sys_mobile_api` (
  `id` int(11) NOT NULL,
  `company_code` varchar(30) DEFAULT NULL,
  `project_code` varchar(30) NOT NULL,
  `app_key` longtext,
  `status` varchar(30) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_module`
--

CREATE TABLE `sys_module` (
  `id` int(11) NOT NULL,
  `code` varchar(30) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `seq_no` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_module`
--

INSERT INTO `sys_module` (`id`, `code`, `name`, `seq_no`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, '001', 'System', 1, 'A', 1, '2016-11-30 16:00:00', NULL, NULL),
(2, '002', 'General', 2, 'A', 1, '2016-11-30 16:00:00', NULL, NULL),
(3, '003', 'Dataview', 3, 'A', 1, '2016-12-08 16:00:00', NULL, NULL),
(4, '004', 'Company', 4, 'A', 1, '2016-12-08 16:00:00', NULL, NULL),
(5, '005', 'User', 5, 'A', 1, '2016-12-29 16:00:00', NULL, NULL),
(6, '006', 'Member', 6, 'A', 1, '2016-12-29 16:00:00', NULL, NULL),
(7, '007', 'Ewallet', 7, 'A', 1, '2016-12-29 16:00:00', NULL, NULL),
(8, '008', 'Filtering', 8, 'A', 1, '2017-01-10 09:21:48', NULL, NULL),
(9, '009', 'Product', 9, 'A', 1, '2017-01-13 02:46:02', NULL, NULL),
(10, '010', 'Sales', 10, 'A', 1, '2017-01-19 04:21:35', NULL, NULL),
(11, '011', 'Language', 11, 'A', 1, '2017-02-10 02:08:13', NULL, NULL),
(12, '012', 'Location', 12, 'A', 1, '2017-02-10 04:38:46', NULL, NULL),
(13, '013', 'Reward', 13, 'A', 1, '2017-02-21 07:22:09', NULL, NULL),
(14, '014', 'Document', 14, 'A', 1, '2017-03-13 09:43:57', NULL, NULL),
(15, '015', 'Ecommerce', 15, 'A', 1, '2017-03-13 11:41:40', NULL, NULL),
(16, '016', 'Email', 16, 'A', 1, '2017-04-24 15:12:02', NULL, NULL),
(17, '017', 'Shipping', 17, 'A', 1, '2017-06-01 04:42:49', NULL, NULL),
(18, '018', 'Merchant', 18, 'A', 1, '2017-08-24 13:24:54', NULL, NULL),
(19, '019', 'Delivery', 19, 'A', 1, '2017-11-14 04:05:34', NULL, NULL),
(20, '020', 'Prepaid', 20, 'A', 1, '2017-11-14 04:05:34', NULL, NULL),
(21, '021', 'Subscription', 21, 'A', 1, '2018-02-23 03:18:41', NULL, NULL),
(22, 'Report', 'Report', 21, 'A', 1, '2019-01-30 02:47:31', NULL, NULL),
(23, '023', 'STO', 23, 'A', 1, '2019-03-18 04:41:01', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sys_notification`
--

CREATE TABLE `sys_notification` (
  `id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `member_id` int(11) DEFAULT '0',
  `t_bns_id` varchar(20) NOT NULL,
  `icon` varchar(30) CHARACTER SET utf8 NOT NULL,
  `label` varchar(30) CHARACTER SET utf8 NOT NULL,
  `title` text NOT NULL,
  `msg` text CHARACTER SET utf8 NOT NULL,
  `b_show` int(11) NOT NULL,
  `status` varchar(30) NOT NULL,
  `redirect_url` varchar(300) NOT NULL,
  `viewed_users` text CHARACTER SET utf8 NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_package_setting`
--

CREATE TABLE `sys_package_setting` (
  `id` int(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `leverage` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(100) NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sys_payment_setting`
--

CREATE TABLE `sys_payment_setting` (
  `id` int(11) NOT NULL,
  `plan_purchase` varchar(25) NOT NULL,
  `ewallet_type_id` int(11) NOT NULL,
  `min_pay_perc` int(11) DEFAULT NULL,
  `max_pay_perc` int(11) DEFAULT NULL,
  `ss_type` tinyint(1) NOT NULL COMMENT '0=share , 1 = full',
  `ss_group` int(5) NOT NULL DEFAULT '1',
  `ss_seq` int(15) NOT NULL,
  `ss_duplicate` tinyint(1) NOT NULL,
  `status` varchar(30) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_payment_setting`
--

INSERT INTO `sys_payment_setting` (`id`, `plan_purchase`, `ewallet_type_id`, `min_pay_perc`, `max_pay_perc`, `ss_type`, `ss_group`, `ss_seq`, `ss_duplicate`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 'REP', 210, 0, 0, 0, 0, 0, 0, 'A', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00'),
(2, 'REG', 210, 0, 0, 0, 0, 0, 0, 'A', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00'),
(3, 'REP', 211, 0, 0, 0, 0, 0, 0, 'A', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00'),
(4, 'REG', 211, 0, 0, 0, 0, 0, 0, 'A', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sys_replicate`
--

CREATE TABLE `sys_replicate` (
  `id` int(11) NOT NULL,
  `member_type_id` int(11) NOT NULL,
  `allow` tinyint(1) DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_tax_type`
--

CREATE TABLE `sys_tax_type` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `code` varchar(30) DEFAULT NULL,
  `name` longtext,
  `percent` decimal(12,2) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_terms_conditions`
--

CREATE TABLE `sys_terms_conditions` (
  `id` int(11) NOT NULL,
  `user_type` varchar(30) DEFAULT NULL,
  `content` longtext,
  `status` varchar(30) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_territory`
--

CREATE TABLE `sys_territory` (
  `id` int(11) NOT NULL,
  `code` varchar(30) NOT NULL DEFAULT '',
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `territory_type` varchar(30) NOT NULL DEFAULT '',
  `calling_no_prefix` varchar(20) DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  `level` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `lft` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `rgt` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `seq_no` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sys_territory`
--

INSERT INTO `sys_territory` (`id`, `code`, `name`, `territory_type`, `calling_no_prefix`, `parent_id`, `level`, `lft`, `rgt`, `seq_no`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 'MY', 'Malaysia', 'country', '+60', 0, 1, 1, 50, 1, 'A', 1, '2020-01-08 09:16:55', NULL, NULL),
(2, 'WM', 'West Malaysia', 'Regional', NULL, 1, 2, 2, 3, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(3, 'EM', 'East Malaysia', 'Regional', NULL, 1, 2, 4, 5, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(4, 'SR', 'Selangor', 'State', NULL, 1, 3, 6, 9, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(5, 'WP', 'Wilayah Persekutuan', 'State', NULL, 1, 3, 12, 15, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(6, 'JR', 'Johor Bahru', 'State', NULL, 1, 3, 18, 21, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(7, 'KH', 'Kedah', 'State', NULL, 1, 3, 22, 23, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(8, 'KN', 'Kelantan', 'State', NULL, 1, 3, 24, 25, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(9, 'MA', 'Melaka', 'State', NULL, 1, 3, 26, 29, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(10, 'NS', 'Negeri Sembilan', 'State', NULL, 1, 3, 30, 33, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(11, 'PA', 'Pahang', 'State', NULL, 1, 3, 34, 35, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(12, 'PP', 'Penang', 'State', NULL, 1, 3, 36, 39, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(13, 'PK', 'Perak', 'State', NULL, 1, 3, 40, 43, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(14, 'PS', 'Perlis', 'State', NULL, 1, 3, 44, 45, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(15, 'SB', 'Sabah', 'State', NULL, 1, 3, 10, 11, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(16, 'SK', 'Sarawak', 'State', NULL, 1, 3, 16, 17, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(17, 'TU', 'Terengganu', 'State', NULL, 1, 3, 46, 47, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(18, 'PJ', 'Petaling Jaya', 'City', NULL, 4, 4, 67, 68, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(19, 'CHR', 'Cheras', 'City', NULL, 5, 4, 161, 162, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(20, 'STP', 'Setapak', 'City', NULL, 5, 4, 189, 190, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(21, 'TTI', 'TTDI', 'City', NULL, 5, 4, 191, 206, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(22, 'SGB', 'Sungai Besi', 'City', NULL, 5, 4, 207, 208, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(23, 'PCH1', 'Jalan Puchong', 'City', NULL, 5, 4, 13, 14, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(24, 'PCH2', 'Puchong', 'City', NULL, 4, 4, 97, 98, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(25, 'AMP', 'Ampang', 'City', NULL, 4, 4, 67, 68, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(61, 'KH', 'Cambodia', 'country', '+855', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(69, 'CN', 'China', 'country', '+86', 0, 1, 1, 2, 0, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(123, 'HK', 'Hong Kong', 'country', '+852', 0, 1, 1, 42, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(152, 'MO', 'Macau', 'country', '+853', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(200, 'PH', 'Philippines', 'country', '+63', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(224, 'SG', 'Singapore', 'Country', '+65', 0, 1, 1, 62, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(241, 'TW', 'Taiwan', 'country', '+886', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(243, 'TH', 'Thailand', 'country', '+66', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(267, 'VN', 'Vietnam', 'country', '+84', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(277, 'AK', 'Ayeh Keroh', 'City', NULL, 9, 4, 275, 276, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(278, 'AG', 'Alor Gajah', 'City', NULL, 9, 4, 161, 162, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(279, 'BKB', 'Bukit Bintang', 'City', NULL, 5, 2, 64, 65, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(280, 'BGS', 'Bangsar', 'City', NULL, 5, 4, 235, 264, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(281, 'BTR', 'Bandar Tun Razak', 'City', NULL, 5, 4, 157, 158, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(282, 'SLY', 'Selayang', 'City', NULL, 5, 4, 109, 156, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(283, 'CBJ', 'Cyberjaya', 'City', NULL, 4, 4, 79, 80, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(284, 'PTJ', 'Putrajaya', 'City', NULL, 5, 4, 107, 108, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(285, 'BLK', 'Balakong', 'City', NULL, 4, 4, 77, 78, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(286, 'BGI', 'Bangi', 'City', NULL, 4, 4, 75, 76, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(287, 'BTG', 'Banting', 'City', NULL, 4, 4, 69, 70, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(288, 'KJG', 'Kajang', 'City', NULL, 4, 4, 71, 72, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(289, 'KSLG', 'Kuala Selangor', 'City', NULL, 4, 4, 73, 74, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(290, 'RWG', 'Rawang', 'City', NULL, 4, 4, 81, 82, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(291, 'SLY', 'Selayang', 'City', NULL, 4, 4, 83, 84, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(292, 'SMY', 'Semenyih', 'City', NULL, 4, 4, 85, 86, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(293, 'SRK', 'Seri Kembangan', 'City', NULL, 4, 4, 87, 88, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(294, 'SALM', 'Shah Alam', 'City', NULL, 4, 4, 89, 90, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(295, 'SBJ', 'Subang Jaya', 'City', NULL, 4, 4, 7, 8, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(296, 'HKC', 'Central and Western', 'State', NULL, 123, 2, 2, 5, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(297, 'central', 'Central', 'City', NULL, 296, 3, 3, 4, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(298, 'eastern', 'Eastern Hong Kong Island', 'State', NULL, 123, 2, 6, 9, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(299, 'islands', 'Islands New Territories', 'State', NULL, 123, 2, 10, 11, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(300, 'kowloon', 'Kowloon City', 'State', NULL, 123, 2, 12, 13, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(301, 'kwaits', 'Kwai Tsing New Territories', 'State', NULL, 123, 2, 14, 15, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(302, 'kwun', 'Kwun Tong', 'State', NULL, 123, 2, 20, 21, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(303, 'north', 'North New Territories', 'State', NULL, 123, 2, 16, 17, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(304, 'saikung', 'Sai Kung New Territories', 'State', NULL, 123, 2, 18, 19, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(305, 'shatin', 'Sha Tin New Territories', 'State', NULL, 123, 2, 22, 23, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(306, 'shamsp', 'Sham Shui Po', 'State', NULL, 123, 2, 24, 25, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(307, 'southern', 'Southern Hong Kong Island', 'State', NULL, 123, 2, 26, 27, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(308, 'taipo', 'Tai Po New Territories', 'State', NULL, 123, 2, 28, 29, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(309, 'tsuenwan', 'Tsuen Wan New Territories', 'State', NULL, 123, 2, 30, 31, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(310, 'tuenmun', 'Tuen Mun New Territories', 'State', NULL, 123, 2, 32, 33, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(311, 'wanchai', 'Wan Chai Hong Kong Island', 'State', NULL, 123, 2, 34, 35, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(312, 'wongts', 'Wong Tai Sin', 'State', NULL, 123, 2, 40, 41, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(313, 'youtsim', 'Yau Tsim Mong', 'State', NULL, 123, 2, 36, 37, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(314, 'yuenlong', 'Yuen Long New Territories', 'State', NULL, 123, 2, 38, 39, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(315, 'batupahat', 'Batu Pahat', 'City', NULL, 6, 4, 109, 110, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(316, 'buloh', 'Buloh Kasap', 'City', NULL, 6, 4, 111, 112, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(317, 'chaah', 'Chaah', 'City', NULL, 6, 4, 113, 114, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(318, 'jb', 'Johor Bahru', 'City', NULL, 6, 4, 115, 116, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(319, 'kdungun', 'Kampong Dungun', 'City', NULL, 6, 4, 117, 118, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(320, 'kelapas', 'Kelapa Sawit', 'City', NULL, 6, 4, 119, 120, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(321, 'kluang', 'Kluang', 'City', NULL, 6, 4, 121, 122, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(322, 'kotat', 'Kota Tinggi', 'City', NULL, 6, 4, 153, 154, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(323, 'kulai', 'Kulai', 'City', NULL, 6, 4, 123, 124, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(324, 'labis', 'Labis', 'City', NULL, 6, 4, 125, 126, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(325, 'mersing', 'Mersing', 'City', NULL, 6, 4, 127, 128, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(326, 'muar', 'Muar', 'City', NULL, 6, 4, 129, 130, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(327, 'parit', 'Parit Raja', 'City', NULL, 6, 4, 131, 132, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(328, 'pasirg', 'Pasir Gudang Baru', 'City', NULL, 6, 4, 133, 134, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(329, 'pekan', 'Pekan Nenas', 'City', NULL, 6, 4, 135, 136, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(330, 'pontian', 'Pontian Kechil', 'City', NULL, 6, 4, 19, 20, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(331, 'segamat', 'Segamat', 'City', NULL, 6, 4, 151, 152, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(332, 'sekudai', 'Sekudai', 'City', NULL, 6, 4, 149, 150, 1, 'I', 1, NULL, NULL, NULL),
(333, 'SR', 'Simpang Renggam', 'City', NULL, 6, 4, 147, 148, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(334, 'TMS', 'Taman Senai', 'City', NULL, 6, 4, 145, 146, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(335, 'TNK', 'Tangkak', 'City', NULL, 6, 4, 143, 144, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(336, 'ulut', 'Ulu Tiram', 'City', NULL, 6, 4, 141, 142, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(337, 'yongp', 'Yong Peng', 'City', NULL, 6, 4, 139, 140, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(338, 'bayan', 'Bayan Lepas', 'City', NULL, 12, 4, 209, 210, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(339, 'bukitm', 'Bukit Mertajam', 'City', NULL, 12, 4, 211, 212, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(340, 'butterworth', 'Butterworth', 'City', NULL, 12, 4, 213, 214, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(341, 'georget', 'George Town', 'City', NULL, 12, 4, 215, 216, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(342, 'juru', 'Juru', 'City', NULL, 12, 4, 217, 218, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(343, 'kepalab', 'Kepala Batas', 'City', NULL, 12, 4, 219, 220, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(344, 'nibong', 'Nibong Tebal', 'City', NULL, 12, 4, 221, 222, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(345, 'perai', 'Perai', 'City', NULL, 12, 4, 223, 224, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(346, 'PMK', 'Permatang Kuching', 'City', NULL, 12, 4, 225, 226, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(347, 'SGA', 'Sungai Ara', 'City', NULL, 12, 4, 227, 228, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(348, 'TJT', 'Tanjung Tokong', 'City', NULL, 12, 4, 229, 230, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(349, 'TSG', 'Tasek Glugor', 'City', NULL, 12, 4, 37, 38, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(350, 'BH', 'Bahau', 'City', NULL, 10, 4, 191, 192, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(351, 'KLK', 'Kuala Klawang', 'City', NULL, 10, 4, 193, 194, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(352, 'KLP', 'Kuala Pilah', 'City', NULL, 10, 4, 195, 196, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(353, 'NL', 'Nilai', 'City', NULL, 10, 4, 31, 32, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(354, 'PD', 'Port Dickson', 'City', NULL, 10, 4, 203, 204, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(355, 'SBN', 'Seremban', 'City', NULL, 10, 4, 201, 202, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(356, 'TPN', 'Tampin', 'City', NULL, 10, 4, 199, 200, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(357, 'AKR', 'Ayer Keroh', 'City', NULL, 9, 4, 187, 188, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(358, 'AMK', 'Ayer Molek', 'City', NULL, 9, 4, 185, 186, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(359, 'BTB', 'Batu Berendam', 'City', NULL, 9, 4, 183, 184, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(360, 'BMB', 'Bemban', 'City', NULL, 9, 4, 181, 182, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(361, 'BKB', 'Bukit Baru', 'City', NULL, 9, 4, 179, 180, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(362, 'BKR', 'Bukit Rambai', 'City', NULL, 4, 4, 95, 96, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(363, 'BKR', 'Bukit Rambai', 'City', NULL, 9, 4, 27, 28, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(364, 'JS', 'Jasin', 'City', NULL, 9, 4, 177, 178, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(365, 'KBB', 'Klebang Besar', 'City', NULL, 9, 4, 175, 176, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(366, 'KSB', 'Kuala Sungai Baru', 'City', NULL, 9, 4, 173, 174, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(367, 'MTH', 'Masjid Tanah', 'City', NULL, 9, 4, 171, 172, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(368, 'MLK', 'Melaka', 'City', NULL, 9, 4, 169, 170, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(369, 'PLS', 'Pulau Sebang', 'City', NULL, 9, 4, 167, 168, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(370, 'SGU', 'Sungai Udang', 'City', NULL, 9, 4, 165, 166, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(371, 'BGS', 'Bagan Serai', 'City', NULL, 13, 4, 235, 236, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(372, 'BTG', 'Batu Gajah', 'City', NULL, 13, 4, 237, 238, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(373, 'BD', 'Bidor', 'City', NULL, 13, 4, 239, 240, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(374, 'IPH', 'Ipoh', 'City', NULL, 13, 4, 241, 242, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(375, 'KMP', 'Kampar', 'City', NULL, 13, 4, 243, 244, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(376, 'KLK', 'Kuala Kangsar', 'City', NULL, 13, 4, 245, 246, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(377, 'LMT', 'Lumut', 'City', NULL, 13, 4, 247, 248, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(378, 'PTR', 'Pantai Remis', 'City', NULL, 13, 4, 249, 250, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(379, 'PRB', 'Parit Buntar', 'City', NULL, 13, 4, 251, 252, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(380, 'SPE', 'Simpang Empat', 'City', NULL, 13, 4, 253, 254, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(381, 'STW', 'Sitiawan', 'City', NULL, 13, 4, 255, 256, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(382, 'TAP', 'Taiping', 'City', NULL, 13, 4, 41, 42, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(383, 'TPR', 'Tapah Road', 'City', NULL, 13, 4, 261, 262, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(384, 'TLI', 'Teluk Intan', 'City', NULL, 13, 4, 259, 260, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(385, 'HML', 'Mid-Levels', 'City', NULL, 296, 3, 5, 6, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(386, 'HSYP', 'Sai Ying Pun', 'City', NULL, 296, 3, 7, 8, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(387, 'KSW', 'Sheung Wan', 'City', NULL, 296, 3, 9, 10, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(388, 'HTP', 'The Peak', 'City', NULL, 296, 3, 11, 12, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(389, 'HMC', 'Mount Cameron', 'City', NULL, 296, 3, 3, 4, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(390, 'HCW', 'Chai Wan', 'City', NULL, 298, 3, 17, 18, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(391, 'HSSW', 'Siu Sai Wan', 'City', NULL, 298, 3, 19, 20, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(392, 'HCC', 'Cape Collinson', 'City', NULL, 298, 3, 25, 26, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(393, 'HSWS', 'Sai Wan Shan', 'City', NULL, 298, 3, 21, 22, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(394, 'HPSW', 'Pak Sha Wan', 'City', NULL, 298, 3, 7, 8, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(395, 'KLG', 'Klang', 'City', NULL, 4, 4, 93, 94, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(396, 'GB', 'Gombak', 'City', NULL, 5, 4, 103, 104, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(397, 'PU', 'Pudu', 'City', NULL, 5, 4, 101, 102, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(399, 'CA', 'Canada', 'country', '+1', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(400, 'US', 'United States', 'country', '+1', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(401, 'KZ', 'Kazakhstan', 'country', '+7', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(402, 'RU', 'Russia', 'country', '+7', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(403, 'EG', 'Egypt', 'country', '+20', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(404, 'ZA', 'South Africa', 'country', '+27', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(405, 'GR', 'Greece', 'country', '+30', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(406, 'NL', 'Netherlands', 'country', '+31', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(407, 'BE', 'Belgium', 'country', '+32', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(408, 'FR', 'France', 'country', '+33', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(409, 'ES', 'Spain', 'country', '+34', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(410, 'HU', 'Hungary', 'country', '+36', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(411, 'IT', 'Italy', 'country', '+39', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(412, 'RO', 'Romania', 'country', '+40', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(413, 'CH', 'Switzerland', 'country', '+41', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(414, 'AT', 'Austria', 'country', '+43', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(415, 'GB', 'United Kingdom', 'country', '+44', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(416, 'DK', 'Denmark', 'country', '+45', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(417, 'SE', 'Sweden', 'country', '+46', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(418, 'NO', 'Norway', 'country', '+47', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(419, 'PL', 'Poland', 'country', '+48', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(420, 'DE', 'Germany', 'country', '+49', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(421, 'PE', 'Peru', 'country', '+51', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(422, 'MX', 'Mexico', 'country', '+52', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(423, 'CU', 'Cuba', 'country', '+53', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(424, 'AR', 'Argentina', 'country', '+54', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(425, 'BR', 'Brazil', 'country', '+55', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(426, 'CL', 'Chile', 'country', '+56', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(427, 'CO', 'Colombia', 'country', '+57', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(428, 'VE', 'Venezuela', 'country', '+58', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(429, 'AU', 'Australia', 'country', '+61', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(430, 'ID', 'Indonesia', 'country', '+62', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(431, 'NZ', 'New Zealand', 'country', '+64', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(432, 'JP', 'Japan', 'country', '+81', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(433, 'KR', 'South Korea', 'country', '+82', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(434, 'TR', 'Turkey', 'country', '+90', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(435, 'IN', 'India', 'country', '+91', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(436, 'PK', 'Pakistan', 'country', '+92', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(437, 'AF', 'Afghanistan', 'country', '+93', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(438, 'LK', 'Sri Lanka', 'country', '+94', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(439, 'MM', 'Myanmar', 'country', '+95', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(440, 'IR', 'Iran', 'country', '+98', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(441, 'SS', 'South Sudan', 'country', '+211', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(442, 'MA', 'Morocco', 'country', '+212', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(443, 'DZ', 'Algeria', 'country', '+213', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(444, 'TN', 'Tunisia', 'country', '+216', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(445, 'LY', 'Libya', 'country', '+218', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(446, 'GM', 'Gambia', 'country', '+220', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(447, 'SN', 'Senegal', 'country', '+221', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(448, 'MR', 'Mauritania', 'country', '+222', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(449, 'ML', 'Mali', 'country', '+223', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(450, 'GN', 'Guinea', 'country', '+224', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(451, 'CI', 'Ivory Coast', 'country', '+225', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(452, 'BF', 'Burkina Faso', 'country', '+226', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(453, 'NE', 'Niger', 'country', '+227', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(454, 'TG', 'Togo', 'country', '+228', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(455, 'BJ', 'Benin', 'country', '+229', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(456, 'MU', 'Mauritius', 'country', '+230', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(457, 'LR', 'Liberia', 'country', '+231', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(458, 'SL', 'Sierra Leone', 'country', '+232', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(459, 'GH', 'Ghana', 'country', '+233', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(460, 'NG', 'Nigeria', 'country', '+234', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(461, 'TD', 'Chad', 'country', '+235', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(462, 'CF', 'Central African Republic', 'country', '+236', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(463, 'CM', 'Cameroon', 'country', '+237', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(464, 'CV', 'Cape Verde', 'country', '+238', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(465, 'ST', 'Sao Tome and Principe', 'country', '+239', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(466, 'GQ', 'Equatorial Guinea', 'country', '+240', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(467, 'GA', 'Gabon', 'country', '+241', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(468, 'CG', 'Congo', 'country', '+242', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(469, 'CD', 'Democratic Republic of the Congo', 'country', '+243', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(470, 'AO', 'Angola', 'country', '+244', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(471, 'GW', 'Guinea-Bissau', 'country', '+245', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(473, 'SC', 'Seychelles', 'country', '+248', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(474, 'SD', 'Sudan', 'country', '+249', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(475, 'RW', 'Rwanda', 'country', '+250', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(476, 'ET', 'Ethiopia', 'country', '+251', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(477, 'SO', 'Somalia', 'country', '+252', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(478, 'DJ', 'Djibouti', 'country', '+253', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(479, 'KE', 'Kenya', 'country', '+254', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(480, 'TZ', 'Tanzania', 'country', '+255', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(481, 'UG', 'Uganda', 'country', '+256', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(482, 'BI', 'Burundi', 'country', '+257', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(483, 'MZ', 'Mozambique', 'country', '+258', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(484, 'ZM', 'Zambia', 'country', '+260', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(485, 'MG', 'Madagascar', 'country', '+261', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(486, 'RE', 'Réunion', 'country', '+262', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(487, 'ZW', 'Republic of Zimbabwe', 'country', '+263', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(488, 'NA', 'Namibia', 'country', '+264', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(489, 'MW', 'Malawi', 'country', '+265', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(490, 'LS', 'Lesotho', 'country', '+266', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(491, 'BW', 'Botswana', 'country', '+267', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(492, 'SZ', 'Swaziland', 'country', '+268', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(493, 'KM', 'Comoros', 'country', '+269', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(494, 'YT', 'Mayotte', 'country', '+269', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(495, 'AW', 'Aruba', 'country', '+297', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(496, 'FO', 'Faroe Islands', 'country', '+298', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(497, 'GL', 'Greenland', 'country', '+299', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(498, 'GI', 'Gibraltar', 'country', '+350', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(499, 'PT', 'Portugal', 'country', '+351', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(500, 'LU', 'Luxembourg', 'country', '+352', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(501, 'MK', 'Macedonia, the former Yugoslav Republic of', 'country', '+389', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(502, 'IE', 'Ireland', 'country', '+353', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(503, 'IS', 'Iceland', 'country', '+354', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(504, 'AL', 'Albania', 'country', '+355', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(505, 'MT', 'Malta', 'country', '+356', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(506, 'CY', 'Cyprus', 'country', '+357', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(507, 'FI', 'Finland', 'country', '+358', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(508, 'BG', 'Bulgaria', 'country', '+359', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(509, 'LT', 'Lithuania', 'country', '+370', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(510, 'LV', 'Latvia', 'country', '+371', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(511, 'EE', 'Estonia', 'country', '+372', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(512, 'MD', 'Moldova, Republic of', 'country', '+373', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(513, 'AM', 'Armenia', 'country', '+374', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(514, 'BY', 'Belarus', 'country', '+375', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(515, 'AD', 'Andorra', 'country', '+376', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(516, 'MC', 'Monaco', 'country', '+377', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(517, 'SM', 'San Marino', 'country', '+378', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(518, 'UA', 'Ukraine', 'country', '+380', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(519, 'RS', 'Serbia', 'country', '+381', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(520, 'ME', 'Montenegro', 'country', '+382', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(521, 'HR', 'Croatia', 'country', '+385', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(522, 'SI', 'Slovenia', 'country', '+386', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(523, 'BA', 'Bosnia and Herzegovina', 'country', '+387', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(524, 'CZ', 'Czech Republic', 'country', '+420', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(525, 'SK', 'Slovakia', 'country', '+421', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(526, 'LI', 'Liechtenstein', 'country', '+423', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(527, 'BZ', 'Belize', 'country', '+501', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(528, 'GT', 'Guatemala', 'country', '+502', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(529, 'SV', 'El Salvador', 'country', '+503', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(530, 'HN', 'Honduras', 'country', '+504', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(531, 'NI', 'Nicaragua', 'country', '+505', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(532, 'CR', 'Costa Rica', 'country', '+506', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(533, 'PA', 'Panama', 'country', '+507', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(534, 'PM', 'Saint Pierre and Miquelon', 'country', '+508', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(535, 'HT', 'Haiti', 'country', '+509', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(536, 'GP', 'Guadeloupe', 'country', '+590', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(537, 'MF', 'Saint Martin', 'country', '+590', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(538, 'BO', 'Bolivia, Plurinational', 'country', '+591', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(539, 'GY', 'Guyana', 'country', '+592', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(540, 'EC', 'Ecuador', 'country', '+593', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(541, 'GF', 'French Guiana', 'country', '+594', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(542, 'PY', 'Paraguay', 'country', '+595', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(543, 'SR', 'Suriname', 'country', '+597', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(544, 'UY', 'Uruguay', 'country', '+598', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(545, 'AN', 'Netherlands Antilles', 'country', '+599', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(546, 'CW', 'Curacao', 'country', '+599', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(547, 'TL', 'Timor', 'country', '+670', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(548, 'BN', 'Brunei Darussalam', 'country', '+673', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(549, 'PG', 'Papua New Guinea', 'country', '+675', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(550, 'TO', 'Tonga', 'country', '+676', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(551, 'SB', 'Solomon Islands', 'country', '+677', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(552, 'VU', 'Vanuatu', 'country', '+678', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(553, 'FJ', 'Fiji', 'country', '+679', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(554, 'PW', 'Palau', 'country', '+680', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(555, 'CK', 'Cook Islands', 'country', '+682', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(556, 'WS', 'Samoa', 'country', '+685', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(557, 'KI', 'Kiribati', 'country', '+686', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(558, 'NC', 'New Caledonia', 'country', '+687', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(559, 'PF', 'French Polynesia', 'country', '+689', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(560, 'LA', 'Lao People\'s Democratic Republic', 'country', '+856', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(561, 'BD', 'Bangladesh', 'country', '+880', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(562, 'PS', 'Palestine', 'country', '+970', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(563, 'MV', 'Maldives', 'country', '+960', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(564, 'LB', 'Lebanon', 'country', '+961', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(565, 'JO', 'Jordan', 'country', '+962', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(566, 'SY', 'Syrian Arab Republic', 'country', '+963', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(567, 'IQ', 'Iraq', 'country', '+964', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(568, 'KW', 'Kuwait', 'country', '+965', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(569, 'SA', 'Saudi Arabia', 'country', '+966', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(570, 'YE', 'Yemen', 'country', '+967', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(571, 'OM', 'Oman', 'country', '+968', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(572, 'AE', 'United Arab Emirates', 'country', '+971', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(573, 'IL', 'Israel', 'country', '+972', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(574, 'BH', 'Bahrain', 'country', '+973', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(575, 'QA', 'Qatar', 'country', '+974', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(576, 'BT', 'Bhutan', 'country', '+975', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(577, 'MN', 'Mongolia', 'country', '+976', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(578, 'NP', 'Nepal', 'country', '+977', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(579, 'TJ', 'Tajikistan', 'country', '+992', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(580, 'TM', 'Turkmenistan', 'country', '+993', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(581, 'AZ', 'Azerbaijan', 'country', '+994', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(582, 'GE', 'Georgia', 'country', '+995', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(583, 'KG', 'Kyrgyzstan', 'country', '+996', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(584, 'UZ', 'Uzbekistan', 'country', '+998', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(585, 'BS', 'Bahamas', 'country', '+1242', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(586, 'BB', 'Barbados', 'country', '+1246', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(587, 'AI', 'Anguilla', 'country', '+1264', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(588, 'AG', 'Antigua and Barbuda', 'country', '+1268', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(589, 'VG', 'British Virgin Islands', 'country', '+1284', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(590, 'VI', 'United States Virgin Islands', 'country', '+1340', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(591, 'KY', 'Cayman Islands', 'country', '+1345', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(592, 'BM', 'Bermuda', 'country', '+1441', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(593, 'GD', 'Grenada', 'country', '+1473', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', 0, NULL),
(594, 'TC', 'Turks and Caicos Islands', 'country', '+1649', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(595, 'MS', 'Montserrat', 'country', '+1664', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(596, 'GU', 'Guam', 'country', '+1671', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(597, 'AS', 'American Samoa', 'country', '+1684', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(598, 'LC', 'Saint Lucia', 'country', '+1758', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(599, 'DM', 'Dominica', 'country', '+1767', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(600, 'VC', 'Saint Vincent and the Grenadines', 'country', '+1784', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(601, 'PR', 'Puerto Rico', 'country', '+1787', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(602, 'DO', 'Dominican Republic', 'country', '+1809', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(603, 'TT', 'Trinidad and Tobago', 'country', '+1868', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(604, 'KN', 'Saint Kitts and Nevis', 'country', '+1869', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL),
(605, 'JM', 'Jamaica', 'country', '+1876', 0, 1, 1, 2, 1, 'I', 1, '2020-01-08 09:16:55', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns`
--

CREATE TABLE `tbl_bns` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_user_id` varchar(30) NOT NULL DEFAULT '',
  `t_full_name` varchar(50) NOT NULL,
  `t_trade_name` varchar(50) NOT NULL,
  `t_upline_id` varchar(30) NOT NULL DEFAULT '',
  `t_upline_lot` varchar(10) NOT NULL DEFAULT '',
  `t_leg_no` varchar(2) NOT NULL DEFAULT '',
  `i_upline_lft` bigint(20) NOT NULL DEFAULT '0',
  `i_upline_rgt` bigint(20) NOT NULL DEFAULT '0',
  `i_upline_lvl` int(11) NOT NULL DEFAULT '0',
  `t_sponsor_id` varchar(30) NOT NULL DEFAULT '',
  `t_sponsor_lot` varchar(10) NOT NULL DEFAULT '',
  `i_sponsor_lft` bigint(20) NOT NULL DEFAULT '0',
  `i_sponsor_rgt` bigint(20) NOT NULL DEFAULT '0',
  `i_sponsor_lvl` int(11) NOT NULL DEFAULT '0',
  `t_elite_id` varchar(30) NOT NULL DEFAULT '',
  `t_elite_lot` varchar(5) NOT NULL DEFAULT '',
  `t_master_id` int(11) NOT NULL DEFAULT '0',
  `t_rank_cur` varchar(5) NOT NULL DEFAULT '00',
  `t_rank_pro` varchar(5) NOT NULL DEFAULT '00',
  `t_rank_eff` varchar(5) NOT NULL DEFAULT '00',
  `t_star_cur` varchar(5) NOT NULL DEFAULT '0',
  `t_star_pro` varchar(5) NOT NULL DEFAULT '0',
  `t_star_eff` varchar(5) NOT NULL DEFAULT '0',
  `t_star_group` varchar(5) NOT NULL DEFAULT '0',
  `t_status` varchar(5) NOT NULL DEFAULT '',
  `b_maintain` tinyint(1) NOT NULL DEFAULT '0',
  `d_join` date DEFAULT NULL,
  `i_dri_cycle` int(11) NOT NULL DEFAULT '0',
  `f_dri_cur` double(19,2) NOT NULL DEFAULT '0.00',
  `f_dri_eff` double(19,2) NOT NULL DEFAULT '0.00',
  `i_dri_count` int(2) NOT NULL DEFAULT '0',
  `i_cdi_countdown` int(11) NOT NULL DEFAULT '0',
  `f_cdi_mth` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv_mth` double(19,2) NOT NULL DEFAULT '0.00',
  `f_dri_income` double(19,2) NOT NULL DEFAULT '0.00',
  `f_dri_income_sub` double(19,2) NOT NULL DEFAULT '0.00',
  `f_cdi_income` double(19,2) NOT NULL DEFAULT '0.00',
  `f_cdi_income_sub` double(19,2) NOT NULL DEFAULT '0.00',
  `i_counter` int(11) NOT NULL DEFAULT '0',
  `i_count` int(11) NOT NULL DEFAULT '0',
  `i_count_sponsor_lft` int(11) NOT NULL DEFAULT '0',
  `i_count_sponsor_rgt` int(11) NOT NULL DEFAULT '0',
  `f_dp` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_sv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_dp_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_sv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_apv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_apv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgdp` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgpv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgbv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgsv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgdp_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgpv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgbv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgsv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gdp` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gpv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gbv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gsv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gdp_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gpv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gbv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gsv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_ytd` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgbv_ytd` decimal(19,2) NOT NULL DEFAULT '0.00',
  `f_gbv_ytd` decimal(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_dri` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_cdi` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_cmb` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_sai` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_msb` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_rsb` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_gross` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_adj` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_tot` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_tot_local` double(19,2) NOT NULL DEFAULT '0.00',
  `dt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `t_country_id` varchar(15) NOT NULL DEFAULT '',
  `f_rate` double(19,2) NOT NULL DEFAULT '0.00',
  `f_maintain` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pretax` double(19,2) NOT NULL DEFAULT '0.00',
  `t_bank_id` varchar(50) NOT NULL DEFAULT '',
  `t_bank_acc_no` varchar(40) NOT NULL DEFAULT '',
  `t_bank_acc_holder` varchar(100) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_cdi`
--

CREATE TABLE `tbl_bns_cdi` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL DEFAULT '01',
  `t_elite_id` varchar(50) NOT NULL DEFAULT '',
  `t_elite_lot` varchar(10) NOT NULL DEFAULT '01',
  `t_downline_id` varchar(50) NOT NULL,
  `t_downline_lot` varchar(10) NOT NULL DEFAULT '01',
  `f_bv_1_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_2_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_1_bf` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_2_bf` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_1_cur` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_2_cur` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_1_tot` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_2_tot` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_1_flush` double NOT NULL DEFAULT '0',
  `f_bv_2_flush` double NOT NULL DEFAULT '0',
  `f_bv_1_cf` double NOT NULL DEFAULT '0',
  `f_bv_2_cf` double NOT NULL DEFAULT '0',
  `f_bv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_perc` double NOT NULL DEFAULT '0',
  `f_bns` double(19,2) NOT NULL DEFAULT '0.00',
  `dt_created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Sponsor Bonus (DRI)';

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_cmb`
--

CREATE TABLE `tbl_bns_cmb` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_frontline_id` varchar(50) DEFAULT NULL,
  `t_downline_id` varchar(50) NOT NULL,
  `t_center_id` varchar(50) NOT NULL DEFAULT '',
  `t_doc_no` varchar(20) NOT NULL DEFAULT '',
  `t_item_id` varchar(20) DEFAULT '',
  `i_lvl` int(11) NOT NULL DEFAULT '0',
  `i_lvl_paid` int(11) NOT NULL DEFAULT '0',
  `f_bv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_perc` double NOT NULL DEFAULT '0',
  `f_bns` double(19,2) NOT NULL DEFAULT '0.00',
  `dt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Matching Bonus (CMB)';

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_dri`
--

CREATE TABLE `tbl_bns_dri` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL DEFAULT '01',
  `t_frontline_id` varchar(50) NOT NULL DEFAULT '',
  `t_frontline_lot` varchar(10) NOT NULL DEFAULT '01',
  `t_downline_id` varchar(50) NOT NULL,
  `t_downline_lot` varchar(10) NOT NULL DEFAULT '01',
  `t_center_id` varchar(50) NOT NULL,
  `t_doc_no` varchar(20) NOT NULL,
  `t_item_id` varchar(20) NOT NULL DEFAULT '',
  `i_lvl` int(11) NOT NULL DEFAULT '0',
  `i_lvl_paid` int(11) NOT NULL DEFAULT '0',
  `f_bv` double(19,2) NOT NULL,
  `f_perc` double NOT NULL,
  `f_bns` double(19,2) NOT NULL,
  `dt_created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Sponsor Bonus (DRI)';

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_elite_adjust`
--

CREATE TABLE `tbl_bns_elite_adjust` (
  `t_bns_id` varchar(15) NOT NULL,
  `t_member_id` varchar(25) NOT NULL,
  `t_elite_id_fr` varchar(25) NOT NULL,
  `t_elite_id_to` varchar(25) NOT NULL,
  `create_by` varchar(25) NOT NULL,
  `note` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_latest`
--

CREATE TABLE `tbl_bns_latest` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_user_id` varchar(30) NOT NULL DEFAULT '',
  `t_full_name` varchar(50) NOT NULL,
  `t_trade_name` varchar(50) NOT NULL,
  `t_upline_id` varchar(30) NOT NULL DEFAULT '',
  `t_upline_lot` varchar(10) NOT NULL DEFAULT '',
  `t_leg_no` varchar(2) NOT NULL DEFAULT '',
  `i_upline_lft` bigint(20) NOT NULL DEFAULT '0',
  `i_upline_rgt` bigint(20) NOT NULL DEFAULT '0',
  `i_upline_lvl` int(11) NOT NULL DEFAULT '0',
  `t_sponsor_id` varchar(30) NOT NULL DEFAULT '',
  `t_sponsor_lot` varchar(10) NOT NULL DEFAULT '',
  `i_sponsor_lft` bigint(20) NOT NULL DEFAULT '0',
  `i_sponsor_rgt` bigint(20) NOT NULL DEFAULT '0',
  `i_sponsor_lvl` int(11) NOT NULL DEFAULT '0',
  `t_elite_id` varchar(30) NOT NULL DEFAULT '',
  `t_elite_lot` varchar(5) NOT NULL DEFAULT '',
  `t_master_id` int(11) NOT NULL DEFAULT '0',
  `t_rank_cur` varchar(5) NOT NULL DEFAULT '00',
  `t_rank_pro` varchar(5) NOT NULL DEFAULT '00',
  `t_rank_eff` varchar(5) NOT NULL DEFAULT '00',
  `t_star_cur` varchar(5) NOT NULL DEFAULT '0',
  `t_star_pro` varchar(5) NOT NULL DEFAULT '0',
  `t_star_eff` varchar(5) NOT NULL DEFAULT '0',
  `t_star_group` varchar(5) NOT NULL DEFAULT '0',
  `t_status` varchar(5) NOT NULL DEFAULT '',
  `b_maintain` tinyint(1) NOT NULL DEFAULT '0',
  `d_join` date DEFAULT NULL,
  `i_dri_cycle` int(11) NOT NULL DEFAULT '0',
  `f_dri_cur` double(19,2) NOT NULL DEFAULT '0.00',
  `f_dri_eff` double(19,2) NOT NULL DEFAULT '0.00',
  `i_dri_count` int(2) NOT NULL DEFAULT '0',
  `i_cdi_countdown` int(11) NOT NULL DEFAULT '0',
  `f_cdi_mth` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv_mth` double(19,2) NOT NULL DEFAULT '0.00',
  `f_dri_income` double(19,2) NOT NULL DEFAULT '0.00',
  `f_cdi_income` double(19,2) NOT NULL DEFAULT '0.00',
  `i_counter` int(11) NOT NULL DEFAULT '0',
  `i_count` int(11) NOT NULL DEFAULT '0',
  `i_count_sponsor_lft` int(11) NOT NULL DEFAULT '0',
  `i_count_sponsor_rgt` int(11) NOT NULL DEFAULT '0',
  `f_dp` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_sv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_dp_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_sv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_apv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_apv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgdp` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgpv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgbv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgsv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgdp_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgpv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgbv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgsv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gdp` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gpv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gbv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gsv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gdp_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gpv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gbv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gsv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_ytd` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgbv_ytd` decimal(19,2) NOT NULL DEFAULT '0.00',
  `f_gbv_ytd` decimal(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_dri` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_cdi` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_cmb` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_sai` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_msb` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_rsb` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_gross` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_adj` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_tot` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_tot_local` double(19,2) NOT NULL DEFAULT '0.00',
  `dt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `t_country_id` varchar(15) NOT NULL DEFAULT '',
  `f_rate` double(19,2) NOT NULL DEFAULT '0.00',
  `f_maintain` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pretax` double(19,2) NOT NULL DEFAULT '0.00',
  `t_bank_id` varchar(50) NOT NULL DEFAULT '',
  `t_bank_acc_no` varchar(40) NOT NULL DEFAULT '',
  `t_bank_acc_holder` varchar(100) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_log`
--

CREATE TABLE `tbl_bns_log` (
  `i_log` bigint(20) UNSIGNED NOT NULL,
  `t_center_id` varchar(20) NOT NULL,
  `t_doc_no` varchar(30) NOT NULL,
  `t_remark` text NOT NULL,
  `dt_create` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='NTR Realtime Bonus log table';

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_msb`
--

CREATE TABLE `tbl_bns_msb` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_frontline_id` varchar(50) DEFAULT NULL,
  `t_downline_id` varchar(50) NOT NULL,
  `t_center_id` varchar(50) NOT NULL,
  `t_doc_no` varchar(20) NOT NULL,
  `t_item_id` varchar(20) DEFAULT NULL,
  `i_lvl` int(11) NOT NULL,
  `i_lvl_paid` int(11) NOT NULL DEFAULT '0',
  `f_bv` double(19,2) NOT NULL,
  `f_perc` double NOT NULL,
  `f_bns` double(19,2) NOT NULL,
  `dt_created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Merchant Sales Bonus (MSB)';

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_passup`
--

CREATE TABLE `tbl_bns_passup` (
  `t_bns_id` varchar(10) NOT NULL,
  `t_member_id` varchar(100) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_downline_id` varchar(100) NOT NULL,
  `t_downline_lot` varchar(10) NOT NULL,
  `t_leg_no` varchar(5) NOT NULL,
  `i_lvl` int(11) NOT NULL,
  `f_pv` double NOT NULL,
  `f_bv` double NOT NULL,
  `b_sponsor` tinyint(1) NOT NULL,
  `t_country_id` varchar(10) NOT NULL,
  `t_country_id_passup` varchar(10) DEFAULT NULL,
  `dt_created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_rsb`
--

CREATE TABLE `tbl_bns_rsb` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL DEFAULT '01',
  `t_frontline_id` varchar(50) NOT NULL DEFAULT '',
  `t_frontline_lot` varchar(10) NOT NULL DEFAULT '01',
  `t_downline_id` varchar(50) NOT NULL DEFAULT '',
  `t_downline_lot` varchar(10) NOT NULL DEFAULT '01',
  `t_center_id` varchar(50) NOT NULL DEFAULT '',
  `t_doc_no` varchar(20) NOT NULL DEFAULT '',
  `t_item_id` varchar(20) NOT NULL DEFAULT '',
  `i_lvl` int(11) NOT NULL DEFAULT '0',
  `i_lvl_paid` int(11) NOT NULL DEFAULT '0',
  `f_bv` double(19,2) NOT NULL,
  `f_perc` double NOT NULL,
  `f_bns` double(19,2) NOT NULL,
  `dt_created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Sponsor Bonus (DRI)';

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_sai`
--

CREATE TABLE `tbl_bns_sai` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_frontline_id` varchar(50) DEFAULT NULL,
  `t_downline_id` varchar(50) NOT NULL,
  `t_center_id` varchar(50) NOT NULL DEFAULT '',
  `t_doc_no` varchar(20) NOT NULL DEFAULT '',
  `t_item_id` varchar(20) DEFAULT '',
  `i_lvl` int(11) NOT NULL,
  `i_lvl_paid` int(11) NOT NULL DEFAULT '0',
  `f_bv` double(19,2) NOT NULL,
  `f_perc` double NOT NULL,
  `f_bns` double(19,2) NOT NULL,
  `dt_created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Performance Bonus (SAI)';

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_sales`
--

CREATE TABLE `tbl_bns_sales` (
  `t_center_id` varchar(30) NOT NULL,
  `t_doc_no` varchar(30) NOT NULL,
  `id` int(11) NOT NULL,
  `t_mobile_id` varchar(30) NOT NULL,
  `t_user_create` varchar(30) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `d_approve` date DEFAULT NULL,
  `t_bns_id` varchar(20) NOT NULL,
  `t_item_id` varchar(30) NOT NULL,
  `t_type` varchar(15) NOT NULL,
  `t_plan_type` varchar(20) DEFAULT NULL,
  `f_dp` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_sv` double(19,2) NOT NULL DEFAULT '0.00',
  `dt_user_create` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bns_summary`
--

CREATE TABLE `tbl_bns_summary` (
  `id` int(11) NOT NULL,
  `t_bns_id` varchar(30) CHARACTER SET utf8 NOT NULL,
  `t_member_id` varchar(30) CHARACTER SET utf8 NOT NULL,
  `t_user_id` varchar(30) CHARACTER SET utf8 NOT NULL,
  `t_upline_id` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `t_sponsor_id` varchar(30) DEFAULT '0',
  `d_join` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `t_rank_pro` varchar(30) DEFAULT '0',
  `f_dp_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_sv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgpv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgbv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pgsv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gpv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gbv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_gsv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_apv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_apv_acc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_adj` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_tot` double(19,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(30) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus`
--

CREATE TABLE `tbl_bonus` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(5) NOT NULL DEFAULT '01',
  `t_user_id` varchar(25) NOT NULL,
  `t_full_name` varchar(50) NOT NULL,
  `t_rank_old` varchar(15) NOT NULL,
  `t_rank_eff` varchar(15) NOT NULL,
  `t_status` varchar(5) NOT NULL,
  `f_ppv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pbv` double(19,2) NOT NULL DEFAULT '0.00',
  `b_maintain` tinyint(1) NOT NULL DEFAULT '0',
  `b_max_flush` tinyint(4) NOT NULL DEFAULT '0',
  `f_bns_sponsor` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_pair` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_matching` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_distributor` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_dividend` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_generation` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_star_leadership` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_keyin` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_gross` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_adj` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_tot` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_hold` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_tot_local` double(19,2) NOT NULL DEFAULT '0.00',
  `t_country_id` varchar(15) DEFAULT NULL,
  `b_cap` tinyint(4) NOT NULL DEFAULT '0',
  `f_eth_rate` double(19,10) NOT NULL DEFAULT '0.0000000000',
  `f_note_rate` double(19,2) NOT NULL DEFAULT '1.00',
  `f_maintain` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pretax` double(19,2) NOT NULL DEFAULT '0.00',
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `t_note` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_custom_setting`
--

CREATE TABLE `tbl_bonus_custom_setting` (
  `id` int(11) NOT NULL,
  `t_bns_id` varchar(25) NOT NULL,
  `t_member_id` varchar(25) NOT NULL,
  `t_member_lot` varchar(25) NOT NULL DEFAULT '01',
  `f_distributor` double(5,2) NOT NULL DEFAULT '-1.00',
  `f_leverage` double(5,2) NOT NULL DEFAULT '-1.00',
  `f_perc_pair` double(5,2) NOT NULL DEFAULT '-1.00',
  `f_perc_dividen` double(5,2) NOT NULL DEFAULT '-1.00',
  `f_perc_sponsor` double(5,2) NOT NULL DEFAULT '-1.00',
  `f_perc_matching` double(5,2) NOT NULL DEFAULT '-1.00',
  `b_latest` tinyint(1) NOT NULL,
  `t_center_create` varchar(25) NOT NULL,
  `t_user_create` varchar(25) NOT NULL,
  `dt_user_create` datetime NOT NULL,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_distributor_passup`
--

CREATE TABLE `tbl_bonus_distributor_passup` (
  `id` int(11) NOT NULL,
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_downline_id` varchar(50) NOT NULL,
  `t_downline_lot` varchar(10) NOT NULL,
  `t_center_id` varchar(25) NOT NULL,
  `t_doc_no` varchar(25) NOT NULL,
  `t_item_id` varchar(25) NOT NULL,
  `i_lvl` int(11) NOT NULL,
  `i_lvl_paid` int(11) NOT NULL,
  `f_bv` double(19,2) NOT NULL,
  `f_perc` double NOT NULL,
  `f_bns` double(19,2) NOT NULL,
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `t_note` varchar(25) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Direct Bonus Detail Table';

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_dividend`
--

CREATE TABLE `tbl_bonus_dividend` (
  `id` int(11) NOT NULL,
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_item_id` varchar(25) NOT NULL,
  `f_bv` double(19,8) NOT NULL,
  `f_perc` double(8,5) NOT NULL,
  `f_ethpay` double(19,8) NOT NULL,
  `f_rate` double(19,2) NOT NULL,
  `f_bns` double(19,8) NOT NULL,
  `dt_paid` datetime NOT NULL,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_generation_passup`
--

CREATE TABLE `tbl_bonus_generation_passup` (
  `id` int(11) NOT NULL,
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_downline_id` varchar(50) NOT NULL,
  `t_downline_lot` varchar(10) NOT NULL,
  `t_center_id` varchar(25) NOT NULL,
  `t_doc_no` varchar(25) NOT NULL,
  `t_item_id` varchar(25) NOT NULL,
  `i_lvl` int(11) NOT NULL,
  `i_lvl_paid` int(11) NOT NULL,
  `f_bv` double(19,2) NOT NULL,
  `f_perc` double NOT NULL,
  `f_bns` double(19,2) NOT NULL,
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_leverage_passup`
--

CREATE TABLE `tbl_bonus_leverage_passup` (
  `id` int(11) NOT NULL,
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_downline_id` varchar(50) NOT NULL,
  `t_downline_lot` varchar(10) NOT NULL,
  `t_center_id` varchar(25) NOT NULL,
  `t_doc_no` varchar(25) NOT NULL,
  `t_item_id` varchar(25) NOT NULL,
  `i_lvl` int(11) NOT NULL,
  `i_lvl_paid` int(11) NOT NULL,
  `f_bv` double(19,2) NOT NULL,
  `f_perc` double NOT NULL,
  `f_bns` double(19,2) NOT NULL,
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_live_queue`
--

CREATE TABLE `tbl_bonus_live_queue` (
  `id` int(11) NOT NULL,
  `process_id` varchar(25) NOT NULL,
  `dt_create` datetime NOT NULL,
  `t_batch` varchar(35) NOT NULL,
  `dt_process` datetime DEFAULT NULL,
  `t_ref` varchar(255) NOT NULL,
  `t_status` varchar(25) DEFAULT NULL,
  `d_update` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_pair`
--

CREATE TABLE `tbl_bonus_pair` (
  `t_bns_fr` varchar(20) NOT NULL,
  `t_bns_to` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_rank_eff` varchar(2) NOT NULL DEFAULT '00',
  `t_status` varchar(5) NOT NULL,
  `i_lft` int(12) NOT NULL,
  `i_rgt` int(12) NOT NULL,
  `i_lvl` int(12) NOT NULL,
  `f_b_bf_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_bf_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_bf_3` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_3` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_tot_1` double(19,2) NOT NULL,
  `f_b_tot_2` double(19,2) NOT NULL,
  `f_b_tot_3` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_flush_1` double(19,2) NOT NULL,
  `f_b_flush_2` double(19,2) NOT NULL,
  `f_b_flush_3` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cf_1` double(19,2) NOT NULL,
  `f_b_cf_2` double(19,2) NOT NULL,
  `f_b_cf_3` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_match` double(19,2) NOT NULL DEFAULT '0.00',
  `i_b_pair` int(11) NOT NULL,
  `i_b_pair_acc` int(10) NOT NULL,
  `f_b_pair_perc` double(19,2) NOT NULL DEFAULT '0.00',
  `i_b_pair1` int(12) NOT NULL,
  `f_bns_pair` double(19,2) NOT NULL,
  `i_b_pair2` int(12) NOT NULL,
  `f_b_pair2_perc` double(19,2) NOT NULL,
  `f_bns_pair2` double(19,2) NOT NULL,
  `f_point` double(7,2) NOT NULL DEFAULT '1.00',
  `f_bns` double(19,2) NOT NULL DEFAULT '0.00',
  `b_cap` tinyint(4) NOT NULL DEFAULT '0',
  `b_latest` tinyint(4) NOT NULL DEFAULT '0',
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_pair_1ab`
--

CREATE TABLE `tbl_bonus_pair_1ab` (
  `t_bns_fr` varchar(20) NOT NULL,
  `t_bns_to` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_rank_eff` varchar(2) NOT NULL DEFAULT '00',
  `t_status` varchar(5) NOT NULL,
  `i_lft` int(12) NOT NULL,
  `i_rgt` int(12) NOT NULL,
  `i_lvl` int(12) NOT NULL,
  `f_b_bf_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_bf_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_tot_1` double(19,2) NOT NULL,
  `f_b_tot_2` double(19,2) NOT NULL,
  `f_b_flush_1` double(19,2) NOT NULL,
  `f_b_flush_2` double(19,2) NOT NULL,
  `f_b_cf_1` double(19,2) NOT NULL,
  `f_b_cf_2` double(19,2) NOT NULL,
  `f_b_acc_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_acc_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_match` double(19,2) NOT NULL DEFAULT '0.00',
  `i_b_pair` int(11) NOT NULL,
  `i_b_pair_acc` int(10) NOT NULL,
  `f_b_pair_perc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_pair` double(19,2) NOT NULL,
  `f_point` double(7,2) NOT NULL DEFAULT '1.00',
  `f_bns` double(19,2) NOT NULL DEFAULT '0.00',
  `b_cap` tinyint(4) NOT NULL DEFAULT '0',
  `b_latest` tinyint(4) NOT NULL DEFAULT '0',
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_pair_2ac`
--

CREATE TABLE `tbl_bonus_pair_2ac` (
  `t_bns_fr` varchar(20) NOT NULL,
  `t_bns_to` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_rank_eff` varchar(2) NOT NULL DEFAULT '00',
  `t_status` varchar(5) NOT NULL,
  `i_lft` int(12) NOT NULL,
  `i_rgt` int(12) NOT NULL,
  `i_lvl` int(12) NOT NULL,
  `f_b_bf_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_bf_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_tot_1` double(19,2) NOT NULL,
  `f_b_tot_2` double(19,2) NOT NULL,
  `f_b_flush_1` double(19,2) NOT NULL,
  `f_b_flush_2` double(19,2) NOT NULL,
  `f_b_cf_1` double(19,2) NOT NULL,
  `f_b_cf_2` double(19,2) NOT NULL,
  `f_b_acc_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_acc_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_match` double(19,2) NOT NULL DEFAULT '0.00',
  `i_b_pair` int(11) NOT NULL,
  `i_b_pair_acc` int(10) NOT NULL,
  `f_b_pair_perc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_pair` double(19,2) NOT NULL,
  `f_point` double(7,2) NOT NULL DEFAULT '1.00',
  `f_bns` double(19,2) NOT NULL DEFAULT '0.00',
  `b_cap` tinyint(4) NOT NULL DEFAULT '0',
  `b_latest` tinyint(4) NOT NULL DEFAULT '0',
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_pair_3bc`
--

CREATE TABLE `tbl_bonus_pair_3bc` (
  `t_bns_fr` varchar(20) NOT NULL,
  `t_bns_to` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_rank_eff` varchar(2) NOT NULL DEFAULT '00',
  `t_status` varchar(5) NOT NULL,
  `i_lft` int(12) NOT NULL,
  `i_rgt` int(12) NOT NULL,
  `i_lvl` int(12) NOT NULL,
  `f_b_bf_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_bf_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_tot_1` double(19,2) NOT NULL,
  `f_b_tot_2` double(19,2) NOT NULL,
  `f_b_flush_1` double(19,2) NOT NULL,
  `f_b_flush_2` double(19,2) NOT NULL,
  `f_b_cf_1` double(19,2) NOT NULL,
  `f_b_cf_2` double(19,2) NOT NULL,
  `f_b_acc_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_acc_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_match` double(19,2) NOT NULL DEFAULT '0.00',
  `i_b_pair` int(11) NOT NULL,
  `i_b_pair_acc` int(10) NOT NULL,
  `f_b_pair_perc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_pair` double(19,2) NOT NULL,
  `f_point` double(7,2) NOT NULL DEFAULT '1.00',
  `f_bns` double(19,2) NOT NULL DEFAULT '0.00',
  `b_cap` tinyint(4) NOT NULL DEFAULT '0',
  `b_latest` tinyint(4) NOT NULL DEFAULT '0',
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_pair_4ad`
--

CREATE TABLE `tbl_bonus_pair_4ad` (
  `t_bns_fr` varchar(20) NOT NULL,
  `t_bns_to` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_rank_eff` varchar(2) NOT NULL DEFAULT '00',
  `t_status` varchar(5) NOT NULL,
  `i_lft` int(12) NOT NULL,
  `i_rgt` int(12) NOT NULL,
  `i_lvl` int(12) NOT NULL,
  `f_b_bf_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_bf_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_tot_1` double(19,2) NOT NULL,
  `f_b_tot_2` double(19,2) NOT NULL,
  `f_b_flush_1` double(19,2) NOT NULL,
  `f_b_flush_2` double(19,2) NOT NULL,
  `f_b_cf_1` double(19,2) NOT NULL,
  `f_b_cf_2` double(19,2) NOT NULL,
  `f_b_acc_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_acc_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_match` double(19,2) NOT NULL DEFAULT '0.00',
  `i_b_pair` int(11) NOT NULL,
  `i_b_pair_acc` int(10) NOT NULL,
  `f_b_pair_perc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_pair` double(19,2) NOT NULL,
  `f_point` double(7,2) NOT NULL DEFAULT '1.00',
  `f_bns` double(19,2) NOT NULL DEFAULT '0.00',
  `b_cap` tinyint(4) NOT NULL DEFAULT '0',
  `b_latest` tinyint(4) NOT NULL DEFAULT '0',
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_pair_5bd`
--

CREATE TABLE `tbl_bonus_pair_5bd` (
  `t_bns_fr` varchar(20) NOT NULL,
  `t_bns_to` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_rank_eff` varchar(2) NOT NULL DEFAULT '00',
  `t_status` varchar(5) NOT NULL,
  `i_lft` int(12) NOT NULL,
  `i_rgt` int(12) NOT NULL,
  `i_lvl` int(12) NOT NULL,
  `f_b_bf_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_bf_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_tot_1` double(19,2) NOT NULL,
  `f_b_tot_2` double(19,2) NOT NULL,
  `f_b_flush_1` double(19,2) NOT NULL,
  `f_b_flush_2` double(19,2) NOT NULL,
  `f_b_cf_1` double(19,2) NOT NULL,
  `f_b_cf_2` double(19,2) NOT NULL,
  `f_b_acc_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_acc_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_match` double(19,2) NOT NULL DEFAULT '0.00',
  `i_b_pair` int(11) NOT NULL,
  `i_b_pair_acc` int(10) NOT NULL,
  `f_b_pair_perc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_pair` double(19,2) NOT NULL,
  `f_point` double(7,2) NOT NULL DEFAULT '1.00',
  `f_bns` double(19,2) NOT NULL DEFAULT '0.00',
  `b_cap` tinyint(4) NOT NULL DEFAULT '0',
  `b_latest` tinyint(4) NOT NULL DEFAULT '0',
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_pair_6cd`
--

CREATE TABLE `tbl_bonus_pair_6cd` (
  `t_bns_fr` varchar(20) NOT NULL,
  `t_bns_to` varchar(20) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_rank_eff` varchar(2) NOT NULL DEFAULT '00',
  `t_status` varchar(5) NOT NULL,
  `i_lft` int(12) NOT NULL,
  `i_rgt` int(12) NOT NULL,
  `i_lvl` int(12) NOT NULL,
  `f_b_bf_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_bf_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_cur_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_tot_1` double(19,2) NOT NULL,
  `f_b_tot_2` double(19,2) NOT NULL,
  `f_b_flush_1` double(19,2) NOT NULL,
  `f_b_flush_2` double(19,2) NOT NULL,
  `f_b_cf_1` double(19,2) NOT NULL,
  `f_b_cf_2` double(19,2) NOT NULL,
  `f_b_acc_1` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_acc_2` double(19,2) NOT NULL DEFAULT '0.00',
  `f_b_match` double(19,2) NOT NULL DEFAULT '0.00',
  `i_b_pair` int(11) NOT NULL,
  `i_b_pair_acc` int(10) NOT NULL,
  `f_b_pair_perc` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bns_pair` double(19,2) NOT NULL,
  `f_point` double(7,2) NOT NULL DEFAULT '1.00',
  `f_bns` double(19,2) NOT NULL DEFAULT '0.00',
  `b_cap` tinyint(4) NOT NULL DEFAULT '0',
  `b_latest` tinyint(4) NOT NULL DEFAULT '0',
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_payout`
--

CREATE TABLE `tbl_bonus_payout` (
  `id` int(11) NOT NULL,
  `t_bns_id` varchar(20) NOT NULL,
  `member_id` varchar(30) NOT NULL,
  `deduct_ewallet_type_id` varchar(25) NOT NULL,
  `bns_type` varchar(25) NOT NULL,
  `paid_ewallet_type_id` varchar(25) DEFAULT NULL,
  `deduct_amount` decimal(19,2) NOT NULL,
  `paid_amount` decimal(25,10) NOT NULL,
  `rate` decimal(15,4) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_rank`
--

CREATE TABLE `tbl_bonus_rank` (
  `t_bns_fr` varchar(25) NOT NULL,
  `t_bns_to` varchar(25) NOT NULL,
  `t_member_id` varchar(25) NOT NULL,
  `t_member_lot` varchar(25) NOT NULL,
  `t_rank_old` varchar(25) NOT NULL DEFAULT '00',
  `t_rank_eff` varchar(25) NOT NULL,
  `t_package_id` varchar(25) NOT NULL,
  `t_status` varchar(15) NOT NULL,
  `b_latest` tinyint(4) NOT NULL,
  `dt_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_sales`
--

CREATE TABLE `tbl_bonus_sales` (
  `t_center_id` varchar(30) NOT NULL,
  `t_doc_no` varchar(30) NOT NULL,
  `t_mobile_id` varchar(30) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `d_approve` date NOT NULL,
  `t_bns_id` varchar(20) NOT NULL,
  `t_item_id` varchar(30) NOT NULL,
  `t_type` varchar(15) NOT NULL,
  `t_plan_type` varchar(30) NOT NULL,
  `t_price_type` varchar(25) NOT NULL,
  `t_currency_code` varchar(15) NOT NULL,
  `f_dp` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_sv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_leverage` varchar(30) NOT NULL DEFAULT '0',
  `t_user_create` varchar(30) NOT NULL,
  `dt_user_create` datetime NOT NULL,
  `dt_bns_cal` datetime DEFAULT NULL,
  `t_batch` varchar(25) DEFAULT NULL,
  `dt_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_sales_adj`
--

CREATE TABLE `tbl_bonus_sales_adj` (
  `t_center_id` varchar(30) NOT NULL,
  `t_doc_no` varchar(30) NOT NULL,
  `t_mobile_id` varchar(30) NOT NULL,
  `t_member_id` varchar(30) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `d_approve` date DEFAULT NULL,
  `t_bns_id` varchar(20) NOT NULL,
  `t_item_id` varchar(30) NOT NULL,
  `t_type` varchar(15) NOT NULL,
  `t_plan_type` varchar(20) NOT NULL,
  `t_price_type` varchar(25) NOT NULL,
  `t_currency_code` varchar(15) NOT NULL,
  `f_dp` double(19,2) NOT NULL DEFAULT '0.00',
  `f_pv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_bv` double(19,2) NOT NULL DEFAULT '0.00',
  `f_sv` double(19,2) NOT NULL DEFAULT '0.00',
  `t_user_create` varchar(30) NOT NULL,
  `dt_user_create` datetime DEFAULT NULL,
  `dt_bns_cal` datetime NOT NULL,
  `t_batch` varchar(25) NOT NULL,
  `dt_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bonus_sponsor`
--

CREATE TABLE `tbl_bonus_sponsor` (
  `t_bns_id` varchar(20) NOT NULL,
  `t_member_id` varchar(50) NOT NULL,
  `t_member_lot` varchar(10) NOT NULL,
  `t_downline_id` varchar(50) NOT NULL,
  `t_downline_lot` varchar(10) NOT NULL,
  `t_center_id` varchar(50) NOT NULL,
  `t_doc_no` varchar(20) NOT NULL,
  `t_item_id` varchar(20) NOT NULL,
  `i_lvl` int(11) NOT NULL,
  `i_lvl_paid` int(11) NOT NULL,
  `f_bv` double(19,2) NOT NULL,
  `f_perc` double NOT NULL,
  `f_bns` double(19,2) NOT NULL,
  `dt_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Direct Bonus Detail Table';

-- --------------------------------------------------------

--
-- Table structure for table `temp_mobile_prefix`
--

CREATE TABLE `temp_mobile_prefix` (
  `id` int(11) NOT NULL,
  `country` varchar(42) DEFAULT NULL,
  `country_code` varchar(11) DEFAULT NULL,
  `prefix` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_member_reg`
--

CREATE TABLE `tmp_member_reg` (
  `id` int(11) NOT NULL,
  `member_type` varchar(30) DEFAULT NULL,
  `nick_name` varchar(30) DEFAULT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `secondary_password` varchar(30) DEFAULT NULL,
  `nric` varchar(30) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `zip` varchar(30) DEFAULT NULL,
  `country_id` varchar(30) DEFAULT NULL,
  `sponsor_id` varchar(30) DEFAULT NULL,
  `sponsor_name` varchar(30) DEFAULT NULL,
  `package_id` varchar(30) DEFAULT NULL,
  `prd_master_id` varchar(30) DEFAULT NULL,
  `prd_price_type_id` varchar(30) DEFAULT NULL,
  `prd_price_id` varchar(30) DEFAULT NULL,
  `qty` varchar(100) DEFAULT NULL,
  `total_amount` float(12,2) DEFAULT NULL,
  `total_tax_amount` float(12,2) DEFAULT NULL,
  `payment_type_id` varchar(30) DEFAULT NULL,
  `ewallet_type_id` varchar(30) DEFAULT NULL,
  `prepaid_code` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `translations`
--

CREATE TABLE `translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `group` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `viewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(10) UNSIGNED NOT NULL,
  `album_id` int(11) DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wallet_api_log`
--

CREATE TABLE `wallet_api_log` (
  `id` int(11) NOT NULL,
  `prj_config_code` varchar(25) DEFAULT NULL,
  `side` varchar(25) NOT NULL,
  `api_type` varchar(50) NOT NULL,
  `method` varchar(25) DEFAULT NULL,
  `url_link` varchar(255) NOT NULL,
  `data_sent` varchar(255) DEFAULT NULL,
  `data_received` varchar(255) DEFAULT NULL,
  `server_data` varchar(255) DEFAULT NULL,
  `dt_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activation_code`
--
ALTER TABLE `activation_code`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins_2fa`
--
ALTER TABLE `admins_2fa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_password_resets`
--
ALTER TABLE `admin_password_resets`
  ADD KEY `merchant_password_resets_email_index` (`email`),
  ADD KEY `merchant_password_resets_token_index` (`token`);

--
-- Indexes for table `album_photo`
--
ALTER TABLE `album_photo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `album_video`
--
ALTER TABLE `album_video`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blockchain_tran`
--
ALTER TABLE `blockchain_tran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bonus_detail`
--
ALTER TABLE `bonus_detail`
  ADD PRIMARY KEY (`bonus_id`);

--
-- Indexes for table `catalog_category_entity`
--
ALTER TABLE `catalog_category_entity`
  ADD PRIMARY KEY (`entity_id`);

--
-- Indexes for table `catalog_category_entity_int`
--
ALTER TABLE `catalog_category_entity_int`
  ADD PRIMARY KEY (`value_id`);

--
-- Indexes for table `catalog_category_entity_text`
--
ALTER TABLE `catalog_category_entity_text`
  ADD PRIMARY KEY (`value_id`);

--
-- Indexes for table `catalog_category_image`
--
ALTER TABLE `catalog_category_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catalog_category_product`
--
ALTER TABLE `catalog_category_product`
  ADD PRIMARY KEY (`entity_id`);

--
-- Indexes for table `catalog_product_entity_datetime`
--
ALTER TABLE `catalog_product_entity_datetime`
  ADD PRIMARY KEY (`value_id`);

--
-- Indexes for table `catalog_product_entity_decimal`
--
ALTER TABLE `catalog_product_entity_decimal`
  ADD PRIMARY KEY (`value_id`);

--
-- Indexes for table `catalog_product_entity_int`
--
ALTER TABLE `catalog_product_entity_int`
  ADD PRIMARY KEY (`value_id`);

--
-- Indexes for table `catalog_product_entity_text`
--
ALTER TABLE `catalog_product_entity_text`
  ADD PRIMARY KEY (`value_id`);

--
-- Indexes for table `cms_page`
--
ALTER TABLE `cms_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_page_filter`
--
ALTER TABLE `cms_page_filter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `connection`
--
ALTER TABLE `connection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `connection_code` (`connection_code`),
  ADD KEY `mobile_user_id` (`mobile_user_id`),
  ADD KEY `device` (`device`),
  ADD KEY `os` (`os`),
  ADD KEY `company_code` (`company_code`),
  ADD KEY `connection_code_2` (`connection_code`,`company_code`),
  ADD KEY `connection_code_3` (`connection_code`,`device`);

--
-- Indexes for table `contacts_audit`
--
ALTER TABLE `contacts_audit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crypto_addr`
--
ALTER TABLE `crypto_addr`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t_addr` (`crypto_addr`),
  ADD KEY `t_member_id` (`member_id`);

--
-- Indexes for table `customer_group`
--
ALTER TABLE `customer_group`
  ADD PRIMARY KEY (`customer_group_id`);

--
-- Indexes for table `customer_group_product`
--
ALTER TABLE `customer_group_product`
  ADD PRIMARY KEY (`entity_id`);

--
-- Indexes for table `dl_list_category`
--
ALTER TABLE `dl_list_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eav_attribute`
--
ALTER TABLE `eav_attribute`
  ADD PRIMARY KEY (`attribute_id`);

--
-- Indexes for table `eav_attribute_group`
--
ALTER TABLE `eav_attribute_group`
  ADD PRIMARY KEY (`attribute_group_id`);

--
-- Indexes for table `eav_attribute_option`
--
ALTER TABLE `eav_attribute_option`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `eav_attribute_option_value`
--
ALTER TABLE `eav_attribute_option_value`
  ADD PRIMARY KEY (`value_id`);

--
-- Indexes for table `eav_attribute_set`
--
ALTER TABLE `eav_attribute_set`
  ADD PRIMARY KEY (`attribute_set_id`);

--
-- Indexes for table `eav_entity_attribute`
--
ALTER TABLE `eav_entity_attribute`
  ADD PRIMARY KEY (`eav_entity_attribute`);

--
-- Indexes for table `eav_entity_store`
--
ALTER TABLE `eav_entity_store`
  ADD PRIMARY KEY (`entity_store_id`);

--
-- Indexes for table `eav_entity_type`
--
ALTER TABLE `eav_entity_type`
  ADD PRIMARY KEY (`entity_type_id`),
  ADD UNIQUE KEY `uix_eav_entity_type_entity_type_code` (`entity_type_code`);

--
-- Indexes for table `eml_template`
--
ALTER TABLE `eml_template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_company`
--
ALTER TABLE `ent_company`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`);

--
-- Indexes for table `ent_company_address`
--
ALTER TABLE `ent_company_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_company_announcement`
--
ALTER TABLE `ent_company_announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_company_attach`
--
ALTER TABLE `ent_company_attach`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_company_bak`
--
ALTER TABLE `ent_company_bak`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`);

--
-- Indexes for table `ent_company_bank`
--
ALTER TABLE `ent_company_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_company_downloads`
--
ALTER TABLE `ent_company_downloads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_company_link`
--
ALTER TABLE `ent_company_link`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_company_temp`
--
ALTER TABLE `ent_company_temp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`);

--
-- Indexes for table `ent_company_tnc`
--
ALTER TABLE `ent_company_tnc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_country`
--
ALTER TABLE `ent_country`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`);

--
-- Indexes for table `ent_location`
--
ALTER TABLE `ent_location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member`
--
ALTER TABLE `ent_member`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `code` (`code`),
  ADD KEY `nick_name` (`nick_name`),
  ADD KEY `last_name` (`last_name`),
  ADD KEY `first_name` (`first_name`),
  ADD KEY `status` (`status`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `updated_by` (`updated_by`),
  ADD KEY `updated_at` (`updated_at`);

--
-- Indexes for table `ent_member_2fa`
--
ALTER TABLE `ent_member_2fa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_address`
--
ALTER TABLE `ent_member_address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `state_id` (`state_id`),
  ADD KEY `city_id` (`city_id`);

--
-- Indexes for table `ent_member_bank`
--
ALTER TABLE `ent_member_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_change_rank`
--
ALTER TABLE `ent_member_change_rank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_contact`
--
ALTER TABLE `ent_member_contact`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `ent_member_custom_reentry`
--
ALTER TABLE `ent_member_custom_reentry`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `ent_member_gold_coin_no`
--
ALTER TABLE `ent_member_gold_coin_no`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_kyc`
--
ALTER TABLE `ent_member_kyc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_lot_queue`
--
ALTER TABLE `ent_member_lot_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `ent_member_lot_sponsor`
--
ALTER TABLE `ent_member_lot_sponsor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `i_lft` (`i_lft`),
  ADD KEY `i_rgt` (`i_rgt`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `member_lot` (`member_lot`);

--
-- Indexes for table `ent_member_oauth_login`
--
ALTER TABLE `ent_member_oauth_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_pin`
--
ALTER TABLE `ent_member_pin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_removed_tree_sponsor`
--
ALTER TABLE `ent_member_removed_tree_sponsor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `upline_id` (`upline_id`),
  ADD KEY `sponsor_id` (`sponsor_id`),
  ADD KEY `elite_id` (`elite_id`),
  ADD KEY `normal_package` (`normal_package`),
  ADD KEY `highest_package` (`highest_package`),
  ADD KEY `package` (`package`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `ent_member_replicate`
--
ALTER TABLE `ent_member_replicate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_replicate_slider`
--
ALTER TABLE `ent_member_replicate_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_replicate_testimonial`
--
ALTER TABLE `ent_member_replicate_testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_reset_bank`
--
ALTER TABLE `ent_member_reset_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_setting`
--
ALTER TABLE `ent_member_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_status_log`
--
ALTER TABLE `ent_member_status_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_subscription`
--
ALTER TABLE `ent_member_subscription`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `ent_member_tree_sponsor`
--
ALTER TABLE `ent_member_tree_sponsor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `upline_id` (`upline_id`),
  ADD KEY `sponsor_id` (`sponsor_id`),
  ADD KEY `package` (`package`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `ent_member_tree_sponsor_log`
--
ALTER TABLE `ent_member_tree_sponsor_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_member_type_menu`
--
ALTER TABLE `ent_member_type_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ent_user`
--
ALTER TABLE `ent_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country_id` (`country_id`,`id`);

--
-- Indexes for table `ewt_detail`
--
ALTER TABLE `ewt_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `ewallet_type_id` (`ewallet_type_id`),
  ADD KEY `member_ewallet_type` (`member_id`,`ewallet_type_id`),
  ADD KEY `doc_no` (`doc_no`);

--
-- Indexes for table `ewt_hide`
--
ALTER TABLE `ewt_hide`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ewt_limiter`
--
ALTER TABLE `ewt_limiter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ewt_payment`
--
ALTER TABLE `ewt_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ewt_setup`
--
ALTER TABLE `ewt_setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ewt_summary`
--
ALTER TABLE `ewt_summary`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`,`ewallet_type_id`) USING BTREE,
  ADD KEY `ewallet_type_id` (`ewallet_type_id`) USING BTREE;

--
-- Indexes for table `ewt_topup`
--
ALTER TABLE `ewt_topup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ewt_topup_queue`
--
ALTER TABLE `ewt_topup_queue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ewt_transfer`
--
ALTER TABLE `ewt_transfer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `doc_no` (`doc_no`);

--
-- Indexes for table `ewt_transfer_api_log`
--
ALTER TABLE `ewt_transfer_api_log`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`) USING BTREE;

--
-- Indexes for table `ewt_transfer_setup`
--
ALTER TABLE `ewt_transfer_setup`
  ADD PRIMARY KEY (`ewallet_type_id_from`,`transfer_type_id_to`),
  ADD KEY `b_transfer_other` (`transfer_other_member`),
  ADD KEY `b_transfer_upline` (`transfer_upline`),
  ADD KEY `b_transfer_sponsor` (`transfer_sponsor`),
  ADD KEY `b_transfer_same_nric` (`transfer_same_member`),
  ADD KEY `b_transfer_downline` (`transfer_downline`);

--
-- Indexes for table `ewt_type_api_setup`
--
ALTER TABLE `ewt_type_api_setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ewt_withdraw`
--
ALTER TABLE `ewt_withdraw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exchange_api_log`
--
ALTER TABLE `exchange_api_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exchange_profile_api_log`
--
ALTER TABLE `exchange_profile_api_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exchange_trans_api_log`
--
ALTER TABLE `exchange_trans_api_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exchange_trans_in`
--
ALTER TABLE `exchange_trans_in`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t_sub_id` (`member_id`);

--
-- Indexes for table `exchange_trans_out`
--
ALTER TABLE `exchange_trans_out`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exported_report_list`
--
ALTER TABLE `exported_report_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `export_file_api_log`
--
ALTER TABLE `export_file_api_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_api_log`
--
ALTER TABLE `general_api_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_password_resets`
--
ALTER TABLE `member_password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `merchants`
--
ALTER TABLE `merchants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `merchants_dev`
--
ALTER TABLE `merchants_dev`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `merchant_password_resets`
--
ALTER TABLE `merchant_password_resets`
  ADD KEY `merchant_password_resets_email_index` (`email`),
  ADD KEY `merchant_password_resets_token_index` (`token`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobile_debugger`
--
ALTER TABLE `mobile_debugger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `payment_type_country`
--
ALTER TABLE `payment_type_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pos_withdraw`
--
ALTER TABLE `pos_withdraw`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_brand`
--
ALTER TABLE `prd_brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_category`
--
ALTER TABLE `prd_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_category_image`
--
ALTER TABLE `prd_category_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_master`
--
ALTER TABLE `prd_master`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uix_prd_master_sku_code` (`sku_code`);

--
-- Indexes for table `prd_master_desc`
--
ALTER TABLE `prd_master_desc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_master_image`
--
ALTER TABLE `prd_master_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_price`
--
ALTER TABLE `prd_price`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prd_master_id` (`prd_master_id`);

--
-- Indexes for table `prd_price_calc`
--
ALTER TABLE `prd_price_calc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_price_country`
--
ALTER TABLE `prd_price_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_price_mem_type`
--
ALTER TABLE `prd_price_mem_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_price_type`
--
ALTER TABLE `prd_price_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prd_rating_review`
--
ALTER TABLE `prd_rating_review`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `product_attribute_type_varchar`
--
ALTER TABLE `product_attribute_type_varchar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_eav_attribute`
--
ALTER TABLE `product_eav_attribute`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_link`
--
ALTER TABLE `product_link`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_master`
--
ALTER TABLE `product_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report_exchange_import`
--
ALTER TABLE `report_exchange_import`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report_mast`
--
ALTER TABLE `report_mast`
  ADD PRIMARY KEY (`i_report_id`);

--
-- Indexes for table `reum_sato`
--
ALTER TABLE `reum_sato`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t_addr` (`crypto_addr`),
  ADD KEY `t_member_id` (`member_id`);

--
-- Indexes for table `robot_trap_log`
--
ALTER TABLE `robot_trap_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rwd_period`
--
ALTER TABLE `rwd_period`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type` (`type`,`batch_code`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `rwd_setup_master`
--
ALTER TABLE `rwd_setup_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rwd_type`
--
ALTER TABLE `rwd_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sdo_item`
--
ALTER TABLE `sdo_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sdo_master`
--
ALTER TABLE `sdo_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `center_id` (`center_id`),
  ADD KEY `doc_date` (`doc_date`),
  ADD KEY `doc_type` (`doc_type`),
  ADD KEY `sponsor_id` (`sponsor_id`),
  ADD KEY `doc_no` (`doc_no`),
  ADD KEY `promo_code` (`promo_code`),
  ADD KEY `courier_id` (`courier_id`),
  ADD KEY `ref_no` (`ref_no`),
  ADD KEY `shipping_address_id` (`shipping_address_id`),
  ADD KEY `billing_address_id` (`billing_address_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `second_auth_setting`
--
ALTER TABLE `second_auth_setting`
  ADD PRIMARY KEY (`action_id`),
  ADD UNIQUE KEY `path` (`path`);

--
-- Indexes for table `send_back_return_ewt_api_log`
--
ALTER TABLE `send_back_return_ewt_api_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `sku_code`
--
ALTER TABLE `sku_code`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uix_sku_code_sku_code` (`sku_code`);

--
-- Indexes for table `sku_code_photo_relationship`
--
ALTER TABLE `sku_code_photo_relationship`
  ADD UNIQUE KEY `uix_sku_code_photo_relationship_sku_id` (`sku_id`);

--
-- Indexes for table `sls_grp_type`
--
ALTER TABLE `sls_grp_type`
  ADD PRIMARY KEY (`grp_type`);

--
-- Indexes for table `sls_item`
--
ALTER TABLE `sls_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sls_master`
--
ALTER TABLE `sls_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `center_id` (`center_id`),
  ADD KEY `doc_date` (`doc_date`),
  ADD KEY `doc_type` (`doc_type`),
  ADD KEY `sponsor_id` (`sponsor_id`),
  ADD KEY `doc_no` (`doc_no`),
  ADD KEY `promo_code` (`promo_code`),
  ADD KEY `courier_id` (`courier_id`),
  ADD KEY `ref_no` (`ref_no`),
  ADD KEY `shipping_address_id` (`shipping_address_id`),
  ADD KEY `billing_address_id` (`billing_address_id`),
  ADD KEY `status` (`status`),
  ADD KEY `action` (`action`),
  ADD KEY `simple_id` (`simple_id`),
  ADD KEY `bns_batch` (`bns_batch`);

--
-- Indexes for table `sls_payment`
--
ALTER TABLE `sls_payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sls_master_id` (`sls_master_id`);

--
-- Indexes for table `sms_log`
--
ALTER TABLE `sms_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sso_item`
--
ALTER TABLE `sso_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sso_master`
--
ALTER TABLE `sso_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sls_master_id` (`sls_master_id`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `center_id` (`center_id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `sponsor_id` (`sponsor_id`),
  ADD KEY `shipping_address_id` (`shipping_address_id`),
  ADD KEY `billing_address_id` (`billing_address_id`),
  ADD KEY `pgw_trans_id` (`pgw_trans_id`),
  ADD KEY `status` (`status`),
  ADD KEY `promo_code` (`promo_code`);

--
-- Indexes for table `sso_payment`
--
ALTER TABLE `sso_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sso_pin`
--
ALTER TABLE `sso_pin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pin_code` (`pin_code`);

--
-- Indexes for table `sso_pin_payment`
--
ALTER TABLE `sso_pin_payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sso_pin_id` (`sso_pin_id`),
  ADD KEY `ewallet_type_id` (`ewallet_type_id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `store_group`
--
ALTER TABLE `store_group`
  ADD PRIMARY KEY (`group_id`),
  ADD UNIQUE KEY `uix_store_group_name` (`name`);

--
-- Indexes for table `sys_api`
--
ALTER TABLE `sys_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_bank`
--
ALTER TABLE `sys_bank`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `sys_courier`
--
ALTER TABLE `sys_courier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_courier_fees`
--
ALTER TABLE `sys_courier_fees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_currency_rate`
--
ALTER TABLE `sys_currency_rate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_datagrid`
--
ALTER TABLE `sys_datagrid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_default_password`
--
ALTER TABLE `sys_default_password`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_doc_no`
--
ALTER TABLE `sys_doc_no`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_doc_type`
--
ALTER TABLE `sys_doc_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_export_setting`
--
ALTER TABLE `sys_export_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_general`
--
ALTER TABLE `sys_general`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code_type` (`type`,`code`) USING BTREE,
  ADD KEY `id_type` (`id`,`type`);

--
-- Indexes for table `sys_general_setup`
--
ALTER TABLE `sys_general_setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_group`
--
ALTER TABLE `sys_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_group_menu`
--
ALTER TABLE `sys_group_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_group_menu_action`
--
ALTER TABLE `sys_group_menu_action`
  ADD UNIQUE KEY `sys_group_sys_menu` (`sys_group_id`,`sys_menu_id`);

--
-- Indexes for table `sys_language`
--
ALTER TABLE `sys_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_log`
--
ALTER TABLE `sys_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_login_attempts_log`
--
ALTER TABLE `sys_login_attempts_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_login_detail_log`
--
ALTER TABLE `sys_login_detail_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_login_failed_log`
--
ALTER TABLE `sys_login_failed_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_login_locked_account_log`
--
ALTER TABLE `sys_login_locked_account_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_login_log`
--
ALTER TABLE `sys_login_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_menu`
--
ALTER TABLE `sys_menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lftrgt` (`lft`,`rgt`);

--
-- Indexes for table `sys_mobile_api`
--
ALTER TABLE `sys_mobile_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_module`
--
ALTER TABLE `sys_module`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `sys_notification`
--
ALTER TABLE `sys_notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_package_setting`
--
ALTER TABLE `sys_package_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_payment_setting`
--
ALTER TABLE `sys_payment_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_replicate`
--
ALTER TABLE `sys_replicate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_tax_type`
--
ALTER TABLE `sys_tax_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_terms_conditions`
--
ALTER TABLE `sys_terms_conditions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sys_territory`
--
ALTER TABLE `sys_territory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `code` (`code`),
  ADD KEY `lft` (`lft`,`rgt`) USING BTREE;

--
-- Indexes for table `tbl_bns`
--
ALTER TABLE `tbl_bns`
  ADD PRIMARY KEY (`t_bns_id`,`t_member_id`),
  ADD KEY `t_upline_id` (`t_upline_id`,`t_upline_lot`,`t_leg_no`),
  ADD KEY `t_sponsor_id` (`t_sponsor_id`,`t_sponsor_lot`),
  ADD KEY `t_rank_cur` (`t_rank_cur`),
  ADD KEY `t_rank_pro` (`t_rank_pro`),
  ADD KEY `t_rank_eff` (`t_rank_eff`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `b_maintain` (`b_maintain`),
  ADD KEY `i_counter` (`i_counter`),
  ADD KEY `f_bns_gross` (`f_bns_gross`),
  ADD KEY `f_bns_tot` (`f_bns_tot`),
  ADD KEY `t_country_id` (`t_country_id`),
  ADD KEY `f_maintain` (`f_maintain`),
  ADD KEY `f_pretax` (`f_pretax`),
  ADD KEY `i_upline_lft` (`i_upline_lft`),
  ADD KEY `i_upline_rgt` (`i_upline_rgt`),
  ADD KEY `i_upline_lvl` (`i_upline_lvl`),
  ADD KEY `i_sponsor_lft` (`i_sponsor_lft`),
  ADD KEY `i_sponsor_rgt` (`i_sponsor_rgt`),
  ADD KEY `i_sponsor_lvl` (`i_sponsor_lvl`),
  ADD KEY `i_count_sponsor_lft` (`i_count_sponsor_lft`),
  ADD KEY `i_count_sponsor_rgt` (`i_count_sponsor_rgt`),
  ADD KEY `t_user_id` (`t_user_id`),
  ADD KEY `t_elite_id` (`t_elite_id`,`t_elite_lot`),
  ADD KEY `t_star_cur` (`t_star_cur`),
  ADD KEY `t_star_pro` (`t_star_pro`),
  ADD KEY `t_star_eff` (`t_star_eff`),
  ADD KEY `d_join` (`d_join`),
  ADD KEY `i_dri_cycle` (`i_dri_cycle`),
  ADD KEY `f_dri_cur` (`f_dri_cur`),
  ADD KEY `f_dri_eff` (`f_dri_eff`),
  ADD KEY `i_cdi_countdown` (`i_cdi_countdown`),
  ADD KEY `t_member_id` (`t_member_id`),
  ADD KEY `f_bns_cdi` (`f_bns_cdi`);

--
-- Indexes for table `tbl_bns_cdi`
--
ALTER TABLE `tbl_bns_cdi`
  ADD PRIMARY KEY (`t_bns_id`,`t_member_id`,`t_member_lot`,`t_downline_id`,`t_downline_lot`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_frontline_id` (`t_elite_id`,`t_elite_lot`),
  ADD KEY `t_downline_id` (`t_downline_id`,`t_downline_lot`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_elite_id` (`t_elite_id`),
  ADD KEY `t_member_id_2` (`t_member_id`),
  ADD KEY `f_bv_1_cur` (`f_bv_1_cur`);

--
-- Indexes for table `tbl_bns_cmb`
--
ALTER TABLE `tbl_bns_cmb`
  ADD KEY `t_member_id` (`t_member_id`),
  ADD KEY `t_downline_id` (`t_downline_id`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `i_lvl_paid` (`i_lvl_paid`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_item_id` (`t_item_id`),
  ADD KEY `t_frontline_id` (`t_frontline_id`);

--
-- Indexes for table `tbl_bns_dri`
--
ALTER TABLE `tbl_bns_dri`
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_frontline_id` (`t_frontline_id`,`t_frontline_lot`),
  ADD KEY `t_downline_id` (`t_downline_id`,`t_downline_lot`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `i_lvl_paid` (`i_lvl_paid`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_item_id` (`t_item_id`);

--
-- Indexes for table `tbl_bns_elite_adjust`
--
ALTER TABLE `tbl_bns_elite_adjust`
  ADD PRIMARY KEY (`t_bns_id`,`t_member_id`);

--
-- Indexes for table `tbl_bns_latest`
--
ALTER TABLE `tbl_bns_latest`
  ADD PRIMARY KEY (`t_bns_id`,`t_member_id`),
  ADD KEY `t_upline_id` (`t_upline_id`,`t_upline_lot`,`t_leg_no`),
  ADD KEY `t_sponsor_id` (`t_sponsor_id`,`t_sponsor_lot`),
  ADD KEY `t_rank_cur` (`t_rank_cur`),
  ADD KEY `t_rank_pro` (`t_rank_pro`),
  ADD KEY `t_rank_eff` (`t_rank_eff`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `b_maintain` (`b_maintain`),
  ADD KEY `i_counter` (`i_counter`),
  ADD KEY `f_bns_gross` (`f_bns_gross`),
  ADD KEY `f_bns_tot` (`f_bns_tot`),
  ADD KEY `t_country_id` (`t_country_id`),
  ADD KEY `f_maintain` (`f_maintain`),
  ADD KEY `f_pretax` (`f_pretax`),
  ADD KEY `i_upline_lft` (`i_upline_lft`),
  ADD KEY `i_upline_rgt` (`i_upline_rgt`),
  ADD KEY `i_upline_lvl` (`i_upline_lvl`),
  ADD KEY `i_sponsor_lft` (`i_sponsor_lft`),
  ADD KEY `i_sponsor_rgt` (`i_sponsor_rgt`),
  ADD KEY `i_sponsor_lvl` (`i_sponsor_lvl`),
  ADD KEY `i_count_sponsor_lft` (`i_count_sponsor_lft`),
  ADD KEY `i_count_sponsor_rgt` (`i_count_sponsor_rgt`),
  ADD KEY `t_user_id` (`t_user_id`),
  ADD KEY `t_elite_id` (`t_elite_id`,`t_elite_lot`),
  ADD KEY `t_star_cur` (`t_star_cur`),
  ADD KEY `t_star_pro` (`t_star_pro`),
  ADD KEY `t_star_eff` (`t_star_eff`),
  ADD KEY `d_join` (`d_join`),
  ADD KEY `i_dri_cycle` (`i_dri_cycle`),
  ADD KEY `f_dri_cur` (`f_dri_cur`),
  ADD KEY `f_dri_eff` (`f_dri_eff`),
  ADD KEY `i_cdi_countdown` (`i_cdi_countdown`),
  ADD KEY `t_member_id` (`t_member_id`),
  ADD KEY `f_bns_cdi` (`f_bns_cdi`);

--
-- Indexes for table `tbl_bns_log`
--
ALTER TABLE `tbl_bns_log`
  ADD PRIMARY KEY (`i_log`),
  ADD KEY `t_center_id` (`t_center_id`,`t_doc_no`),
  ADD KEY `dt_create` (`dt_create`);

--
-- Indexes for table `tbl_bns_msb`
--
ALTER TABLE `tbl_bns_msb`
  ADD KEY `t_member_id` (`t_member_id`),
  ADD KEY `t_downline_id` (`t_downline_id`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `i_lvl_paid` (`i_lvl_paid`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_item_id` (`t_item_id`),
  ADD KEY `t_frontline_id` (`t_frontline_id`);

--
-- Indexes for table `tbl_bns_passup`
--
ALTER TABLE `tbl_bns_passup`
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_downline_id` (`t_downline_id`,`t_downline_lot`),
  ADD KEY `t_leg_no` (`t_leg_no`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `b_sponsor` (`b_sponsor`),
  ADD KEY `t_country_id` (`t_country_id`),
  ADD KEY `t_country_id_passup` (`t_country_id_passup`);

--
-- Indexes for table `tbl_bns_rsb`
--
ALTER TABLE `tbl_bns_rsb`
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_frontline_id` (`t_frontline_id`,`t_frontline_lot`),
  ADD KEY `t_downline_id` (`t_downline_id`,`t_downline_lot`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `i_lvl_paid` (`i_lvl_paid`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_item_id` (`t_item_id`);

--
-- Indexes for table `tbl_bns_sai`
--
ALTER TABLE `tbl_bns_sai`
  ADD KEY `t_member_id` (`t_member_id`),
  ADD KEY `t_downline_id` (`t_downline_id`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `i_lvl_paid` (`i_lvl_paid`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_item_id` (`t_item_id`),
  ADD KEY `t_frontline_id` (`t_frontline_id`);

--
-- Indexes for table `tbl_bns_sales`
--
ALTER TABLE `tbl_bns_sales`
  ADD PRIMARY KEY (`t_bns_id`,`t_center_id`,`t_doc_no`) USING BTREE,
  ADD KEY `t_type` (`t_type`),
  ADD KEY `d_approve` (`d_approve`),
  ADD KEY `t_item_id` (`t_item_id`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_plan_type` (`t_plan_type`),
  ADD KEY `t_mobile_id` (`t_mobile_id`),
  ADD KEY `t_user_create` (`t_user_create`),
  ADD KEY `id` (`id`),
  ADD KEY `f_dp` (`f_dp`),
  ADD KEY `f_pv` (`f_pv`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_sv` (`f_sv`),
  ADD KEY `dt_user_create` (`dt_user_create`);

--
-- Indexes for table `tbl_bns_summary`
--
ALTER TABLE `tbl_bns_summary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bonus`
--
ALTER TABLE `tbl_bonus`
  ADD PRIMARY KEY (`t_bns_id`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `b_maintain` (`b_maintain`),
  ADD KEY `f_bns_gross` (`f_bns_gross`),
  ADD KEY `f_bns_tot` (`f_bns_tot`),
  ADD KEY `t_country_id` (`t_country_id`),
  ADD KEY `f_maintain` (`f_maintain`),
  ADD KEY `f_pretax` (`f_pretax`),
  ADD KEY `f_bns_pair_lvl` (`f_bns_matching`),
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_member_id` (`t_member_id`);

--
-- Indexes for table `tbl_bonus_custom_setting`
--
ALTER TABLE `tbl_bonus_custom_setting`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t_bns_id` (`t_bns_id`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_id_2` (`t_bns_id`),
  ADD KEY `t_member_id` (`t_member_id`),
  ADD KEY `t_member_id_2` (`t_member_id`,`t_member_lot`);

--
-- Indexes for table `tbl_bonus_distributor_passup`
--
ALTER TABLE `tbl_bonus_distributor_passup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_downline_id` (`t_downline_id`,`t_downline_lot`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `i_lvl_paid` (`i_lvl_paid`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`);

--
-- Indexes for table `tbl_bonus_dividend`
--
ALTER TABLE `tbl_bonus_dividend`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `t_bns_id_2` (`t_bns_id`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_member_id` (`t_member_id`);

--
-- Indexes for table `tbl_bonus_generation_passup`
--
ALTER TABLE `tbl_bonus_generation_passup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_downline_id` (`t_downline_id`,`t_downline_lot`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `i_lvl_paid` (`i_lvl_paid`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`);

--
-- Indexes for table `tbl_bonus_leverage_passup`
--
ALTER TABLE `tbl_bonus_leverage_passup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_downline_id` (`t_downline_id`,`t_downline_lot`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `i_lvl_paid` (`i_lvl_paid`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`);

--
-- Indexes for table `tbl_bonus_live_queue`
--
ALTER TABLE `tbl_bonus_live_queue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bonus_pair`
--
ALTER TABLE `tbl_bonus_pair`
  ADD PRIMARY KEY (`t_bns_fr`,`t_bns_to`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_id` (`t_bns_fr`),
  ADD KEY `t_rank_eff` (`t_rank_eff`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `dt_created` (`dt_created`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `f_b_match` (`f_b_match`),
  ADD KEY `i_b_pair` (`i_b_pair`),
  ADD KEY `b_latest` (`b_latest`);

--
-- Indexes for table `tbl_bonus_pair_1ab`
--
ALTER TABLE `tbl_bonus_pair_1ab`
  ADD PRIMARY KEY (`t_bns_fr`,`t_bns_to`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_id` (`t_bns_fr`),
  ADD KEY `t_rank_eff` (`t_rank_eff`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `dt_created` (`dt_created`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `f_b_match` (`f_b_match`),
  ADD KEY `i_b_pair` (`i_b_pair`),
  ADD KEY `b_latest` (`b_latest`);

--
-- Indexes for table `tbl_bonus_pair_2ac`
--
ALTER TABLE `tbl_bonus_pair_2ac`
  ADD PRIMARY KEY (`t_bns_fr`,`t_bns_to`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_id` (`t_bns_fr`),
  ADD KEY `t_rank_eff` (`t_rank_eff`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `dt_created` (`dt_created`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `f_b_match` (`f_b_match`),
  ADD KEY `i_b_pair` (`i_b_pair`),
  ADD KEY `b_latest` (`b_latest`);

--
-- Indexes for table `tbl_bonus_pair_3bc`
--
ALTER TABLE `tbl_bonus_pair_3bc`
  ADD PRIMARY KEY (`t_bns_fr`,`t_bns_to`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_id` (`t_bns_fr`),
  ADD KEY `t_rank_eff` (`t_rank_eff`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `dt_created` (`dt_created`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `f_b_match` (`f_b_match`),
  ADD KEY `i_b_pair` (`i_b_pair`),
  ADD KEY `b_latest` (`b_latest`);

--
-- Indexes for table `tbl_bonus_pair_4ad`
--
ALTER TABLE `tbl_bonus_pair_4ad`
  ADD PRIMARY KEY (`t_bns_fr`,`t_bns_to`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_id` (`t_bns_fr`),
  ADD KEY `t_rank_eff` (`t_rank_eff`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `dt_created` (`dt_created`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `f_b_match` (`f_b_match`),
  ADD KEY `i_b_pair` (`i_b_pair`),
  ADD KEY `b_latest` (`b_latest`);

--
-- Indexes for table `tbl_bonus_pair_5bd`
--
ALTER TABLE `tbl_bonus_pair_5bd`
  ADD PRIMARY KEY (`t_bns_fr`,`t_bns_to`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_id` (`t_bns_fr`),
  ADD KEY `t_rank_eff` (`t_rank_eff`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `dt_created` (`dt_created`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `f_b_match` (`f_b_match`),
  ADD KEY `i_b_pair` (`i_b_pair`),
  ADD KEY `b_latest` (`b_latest`);

--
-- Indexes for table `tbl_bonus_pair_6cd`
--
ALTER TABLE `tbl_bonus_pair_6cd`
  ADD PRIMARY KEY (`t_bns_fr`,`t_bns_to`,`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_id` (`t_bns_fr`),
  ADD KEY `t_rank_eff` (`t_rank_eff`),
  ADD KEY `t_status` (`t_status`),
  ADD KEY `dt_created` (`dt_created`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `f_b_match` (`f_b_match`),
  ADD KEY `i_b_pair` (`i_b_pair`),
  ADD KEY `b_latest` (`b_latest`);

--
-- Indexes for table `tbl_bonus_payout`
--
ALTER TABLE `tbl_bonus_payout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bonus_rank`
--
ALTER TABLE `tbl_bonus_rank`
  ADD PRIMARY KEY (`t_bns_fr`,`t_bns_to`,`t_member_id`,`t_member_lot`,`b_latest`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_bns_to` (`t_bns_to`),
  ADD KEY `t_bns_fr` (`t_bns_fr`);

--
-- Indexes for table `tbl_bonus_sales`
--
ALTER TABLE `tbl_bonus_sales`
  ADD PRIMARY KEY (`t_center_id`,`t_doc_no`,`t_member_id`,`t_member_lot`,`t_bns_id`),
  ADD KEY `t_type` (`t_type`),
  ADD KEY `d_approve` (`d_approve`),
  ADD KEY `t_item_id` (`t_item_id`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_plan_type` (`t_plan_type`),
  ADD KEY `t_mobile_id` (`t_mobile_id`),
  ADD KEY `t_user_create` (`t_user_create`),
  ADD KEY `t_batch` (`t_batch`),
  ADD KEY `t_doc_no` (`t_doc_no`);

--
-- Indexes for table `tbl_bonus_sales_adj`
--
ALTER TABLE `tbl_bonus_sales_adj`
  ADD PRIMARY KEY (`t_center_id`,`t_doc_no`,`t_member_id`,`t_member_lot`,`t_bns_id`),
  ADD KEY `t_type` (`t_type`),
  ADD KEY `d_approve` (`d_approve`),
  ADD KEY `t_item_id` (`t_item_id`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_plan_type` (`t_plan_type`),
  ADD KEY `t_mobile_id` (`t_mobile_id`),
  ADD KEY `t_user_create` (`t_user_create`),
  ADD KEY `t_batch` (`t_batch`);

--
-- Indexes for table `tbl_bonus_sponsor`
--
ALTER TABLE `tbl_bonus_sponsor`
  ADD PRIMARY KEY (`t_bns_id`,`t_member_id`,`t_member_lot`,`t_downline_id`,`t_downline_lot`,`t_doc_no`),
  ADD KEY `t_member_id` (`t_member_id`,`t_member_lot`),
  ADD KEY `t_downline_id` (`t_downline_id`,`t_downline_lot`),
  ADD KEY `i_lvl` (`i_lvl`),
  ADD KEY `i_lvl_paid` (`i_lvl_paid`),
  ADD KEY `f_bv` (`f_bv`),
  ADD KEY `f_perc` (`f_perc`),
  ADD KEY `f_bns` (`f_bns`),
  ADD KEY `t_bns_id` (`t_bns_id`),
  ADD KEY `t_item_id` (`t_item_id`);

--
-- Indexes for table `temp_mobile_prefix`
--
ALTER TABLE `temp_mobile_prefix`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tmp_member_reg`
--
ALTER TABLE `tmp_member_reg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `translations_locale_group_name_unique` (`locale`,`group`,`name`),
  ADD KEY `translations_locale_group_index` (`locale`,`group`),
  ADD KEY `index_name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wallet_api_log`
--
ALTER TABLE `wallet_api_log`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activation_code`
--
ALTER TABLE `activation_code`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admins_2fa`
--
ALTER TABLE `admins_2fa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `album_photo`
--
ALTER TABLE `album_photo`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `album_video`
--
ALTER TABLE `album_video`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blockchain_tran`
--
ALTER TABLE `blockchain_tran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bonus_detail`
--
ALTER TABLE `bonus_detail`
  MODIFY `bonus_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catalog_category_entity`
--
ALTER TABLE `catalog_category_entity`
  MODIFY `entity_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catalog_category_entity_int`
--
ALTER TABLE `catalog_category_entity_int`
  MODIFY `value_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catalog_category_entity_text`
--
ALTER TABLE `catalog_category_entity_text`
  MODIFY `value_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catalog_category_image`
--
ALTER TABLE `catalog_category_image`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catalog_category_product`
--
ALTER TABLE `catalog_category_product`
  MODIFY `entity_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catalog_product_entity_datetime`
--
ALTER TABLE `catalog_product_entity_datetime`
  MODIFY `value_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catalog_product_entity_decimal`
--
ALTER TABLE `catalog_product_entity_decimal`
  MODIFY `value_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `catalog_product_entity_int`
--
ALTER TABLE `catalog_product_entity_int`
  MODIFY `value_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `catalog_product_entity_text`
--
ALTER TABLE `catalog_product_entity_text`
  MODIFY `value_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `cms_page`
--
ALTER TABLE `cms_page`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cms_page_filter`
--
ALTER TABLE `cms_page_filter`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `connection`
--
ALTER TABLE `connection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contacts_audit`
--
ALTER TABLE `contacts_audit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `crypto_addr`
--
ALTER TABLE `crypto_addr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_group`
--
ALTER TABLE `customer_group`
  MODIFY `customer_group_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer_group_product`
--
ALTER TABLE `customer_group_product`
  MODIFY `entity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `dl_list_category`
--
ALTER TABLE `dl_list_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `eav_attribute`
--
ALTER TABLE `eav_attribute`
  MODIFY `attribute_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `eav_attribute_group`
--
ALTER TABLE `eav_attribute_group`
  MODIFY `attribute_group_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `eav_attribute_option`
--
ALTER TABLE `eav_attribute_option`
  MODIFY `option_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `eav_attribute_option_value`
--
ALTER TABLE `eav_attribute_option_value`
  MODIFY `value_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `eav_attribute_set`
--
ALTER TABLE `eav_attribute_set`
  MODIFY `attribute_set_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `eav_entity_attribute`
--
ALTER TABLE `eav_entity_attribute`
  MODIFY `eav_entity_attribute` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `eav_entity_store`
--
ALTER TABLE `eav_entity_store`
  MODIFY `entity_store_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `eav_entity_type`
--
ALTER TABLE `eav_entity_type`
  MODIFY `entity_type_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `eml_template`
--
ALTER TABLE `eml_template`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company`
--
ALTER TABLE `ent_company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company_address`
--
ALTER TABLE `ent_company_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company_announcement`
--
ALTER TABLE `ent_company_announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company_attach`
--
ALTER TABLE `ent_company_attach`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company_bak`
--
ALTER TABLE `ent_company_bak`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company_bank`
--
ALTER TABLE `ent_company_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company_downloads`
--
ALTER TABLE `ent_company_downloads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company_link`
--
ALTER TABLE `ent_company_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company_temp`
--
ALTER TABLE `ent_company_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_company_tnc`
--
ALTER TABLE `ent_company_tnc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_country`
--
ALTER TABLE `ent_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=440;

--
-- AUTO_INCREMENT for table `ent_location`
--
ALTER TABLE `ent_location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member`
--
ALTER TABLE `ent_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `ent_member_2fa`
--
ALTER TABLE `ent_member_2fa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_address`
--
ALTER TABLE `ent_member_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ent_member_bank`
--
ALTER TABLE `ent_member_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_change_rank`
--
ALTER TABLE `ent_member_change_rank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_contact`
--
ALTER TABLE `ent_member_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ent_member_custom_reentry`
--
ALTER TABLE `ent_member_custom_reentry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_gold_coin_no`
--
ALTER TABLE `ent_member_gold_coin_no`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_kyc`
--
ALTER TABLE `ent_member_kyc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_lot_queue`
--
ALTER TABLE `ent_member_lot_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ent_member_lot_sponsor`
--
ALTER TABLE `ent_member_lot_sponsor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `ent_member_oauth_login`
--
ALTER TABLE `ent_member_oauth_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_pin`
--
ALTER TABLE `ent_member_pin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_removed_tree_sponsor`
--
ALTER TABLE `ent_member_removed_tree_sponsor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_replicate`
--
ALTER TABLE `ent_member_replicate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_replicate_slider`
--
ALTER TABLE `ent_member_replicate_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_replicate_testimonial`
--
ALTER TABLE `ent_member_replicate_testimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_reset_bank`
--
ALTER TABLE `ent_member_reset_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_setting`
--
ALTER TABLE `ent_member_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_status_log`
--
ALTER TABLE `ent_member_status_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'This is a insert only table';

--
-- AUTO_INCREMENT for table `ent_member_subscription`
--
ALTER TABLE `ent_member_subscription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_tree_sponsor`
--
ALTER TABLE `ent_member_tree_sponsor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `ent_member_tree_sponsor_log`
--
ALTER TABLE `ent_member_tree_sponsor_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ent_member_type_menu`
--
ALTER TABLE `ent_member_type_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ent_user`
--
ALTER TABLE `ent_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ewt_detail`
--
ALTER TABLE `ewt_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ewt_hide`
--
ALTER TABLE `ewt_hide`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ewt_limiter`
--
ALTER TABLE `ewt_limiter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ewt_payment`
--
ALTER TABLE `ewt_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ewt_setup`
--
ALTER TABLE `ewt_setup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ewt_summary`
--
ALTER TABLE `ewt_summary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ewt_topup`
--
ALTER TABLE `ewt_topup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ewt_topup_queue`
--
ALTER TABLE `ewt_topup_queue`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ewt_transfer`
--
ALTER TABLE `ewt_transfer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ewt_transfer_api_log`
--
ALTER TABLE `ewt_transfer_api_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ewt_type_api_setup`
--
ALTER TABLE `ewt_type_api_setup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ewt_withdraw`
--
ALTER TABLE `ewt_withdraw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exchange_api_log`
--
ALTER TABLE `exchange_api_log`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exchange_profile_api_log`
--
ALTER TABLE `exchange_profile_api_log`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exchange_trans_api_log`
--
ALTER TABLE `exchange_trans_api_log`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exchange_trans_in`
--
ALTER TABLE `exchange_trans_in`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exchange_trans_out`
--
ALTER TABLE `exchange_trans_out`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exported_report_list`
--
ALTER TABLE `exported_report_list`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `export_file_api_log`
--
ALTER TABLE `export_file_api_log`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `general_api_log`
--
ALTER TABLE `general_api_log`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `merchants`
--
ALTER TABLE `merchants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `merchants_dev`
--
ALTER TABLE `merchants_dev`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `mobile_debugger`
--
ALTER TABLE `mobile_debugger`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_type_country`
--
ALTER TABLE `payment_type_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pos_withdraw`
--
ALTER TABLE `pos_withdraw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_brand`
--
ALTER TABLE `prd_brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_category`
--
ALTER TABLE `prd_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_category_image`
--
ALTER TABLE `prd_category_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_master`
--
ALTER TABLE `prd_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `prd_master_desc`
--
ALTER TABLE `prd_master_desc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_master_image`
--
ALTER TABLE `prd_master_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `prd_price`
--
ALTER TABLE `prd_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_price_calc`
--
ALTER TABLE `prd_price_calc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_price_country`
--
ALTER TABLE `prd_price_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_price_mem_type`
--
ALTER TABLE `prd_price_mem_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_price_type`
--
ALTER TABLE `prd_price_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prd_rating_review`
--
ALTER TABLE `prd_rating_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_attribute_type_varchar`
--
ALTER TABLE `product_attribute_type_varchar`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_eav_attribute`
--
ALTER TABLE `product_eav_attribute`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_link`
--
ALTER TABLE `product_link`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_master`
--
ALTER TABLE `product_master`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_exchange_import`
--
ALTER TABLE `report_exchange_import`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_mast`
--
ALTER TABLE `report_mast`
  MODIFY `i_report_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reum_sato`
--
ALTER TABLE `reum_sato`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `robot_trap_log`
--
ALTER TABLE `robot_trap_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rwd_period`
--
ALTER TABLE `rwd_period`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rwd_setup_master`
--
ALTER TABLE `rwd_setup_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rwd_type`
--
ALTER TABLE `rwd_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sdo_item`
--
ALTER TABLE `sdo_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sdo_master`
--
ALTER TABLE `sdo_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `second_auth_setting`
--
ALTER TABLE `second_auth_setting`
  MODIFY `action_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `send_back_return_ewt_api_log`
--
ALTER TABLE `send_back_return_ewt_api_log`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sku_code`
--
ALTER TABLE `sku_code`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sls_item`
--
ALTER TABLE `sls_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sls_master`
--
ALTER TABLE `sls_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sls_payment`
--
ALTER TABLE `sls_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sms_log`
--
ALTER TABLE `sms_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sso_item`
--
ALTER TABLE `sso_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sso_master`
--
ALTER TABLE `sso_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sso_payment`
--
ALTER TABLE `sso_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sso_pin`
--
ALTER TABLE `sso_pin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sso_pin_payment`
--
ALTER TABLE `sso_pin_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `store_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `store_group`
--
ALTER TABLE `store_group`
  MODIFY `group_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sys_api`
--
ALTER TABLE `sys_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_bank`
--
ALTER TABLE `sys_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sys_courier`
--
ALTER TABLE `sys_courier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_courier_fees`
--
ALTER TABLE `sys_courier_fees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_currency_rate`
--
ALTER TABLE `sys_currency_rate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_datagrid`
--
ALTER TABLE `sys_datagrid`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_default_password`
--
ALTER TABLE `sys_default_password`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_doc_no`
--
ALTER TABLE `sys_doc_no`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `sys_doc_type`
--
ALTER TABLE `sys_doc_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_export_setting`
--
ALTER TABLE `sys_export_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_general`
--
ALTER TABLE `sys_general`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=212;

--
-- AUTO_INCREMENT for table `sys_general_setup`
--
ALTER TABLE `sys_general_setup`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_group`
--
ALTER TABLE `sys_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sys_group_menu`
--
ALTER TABLE `sys_group_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sys_language`
--
ALTER TABLE `sys_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_log`
--
ALTER TABLE `sys_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_login_attempts_log`
--
ALTER TABLE `sys_login_attempts_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_login_detail_log`
--
ALTER TABLE `sys_login_detail_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_login_failed_log`
--
ALTER TABLE `sys_login_failed_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_login_locked_account_log`
--
ALTER TABLE `sys_login_locked_account_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_login_log`
--
ALTER TABLE `sys_login_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_menu`
--
ALTER TABLE `sys_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1413;

--
-- AUTO_INCREMENT for table `sys_mobile_api`
--
ALTER TABLE `sys_mobile_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_module`
--
ALTER TABLE `sys_module`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `sys_notification`
--
ALTER TABLE `sys_notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_package_setting`
--
ALTER TABLE `sys_package_setting`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_payment_setting`
--
ALTER TABLE `sys_payment_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sys_replicate`
--
ALTER TABLE `sys_replicate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_tax_type`
--
ALTER TABLE `sys_tax_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_terms_conditions`
--
ALTER TABLE `sys_terms_conditions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sys_territory`
--
ALTER TABLE `sys_territory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=606;

--
-- AUTO_INCREMENT for table `tbl_bns_log`
--
ALTER TABLE `tbl_bns_log`
  MODIFY `i_log` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bns_summary`
--
ALTER TABLE `tbl_bns_summary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bonus_custom_setting`
--
ALTER TABLE `tbl_bonus_custom_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bonus_distributor_passup`
--
ALTER TABLE `tbl_bonus_distributor_passup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bonus_dividend`
--
ALTER TABLE `tbl_bonus_dividend`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bonus_generation_passup`
--
ALTER TABLE `tbl_bonus_generation_passup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bonus_leverage_passup`
--
ALTER TABLE `tbl_bonus_leverage_passup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bonus_live_queue`
--
ALTER TABLE `tbl_bonus_live_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bonus_payout`
--
ALTER TABLE `tbl_bonus_payout`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `temp_mobile_prefix`
--
ALTER TABLE `temp_mobile_prefix`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tmp_member_reg`
--
ALTER TABLE `tmp_member_reg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wallet_api_log`
--
ALTER TABLE `wallet_api_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
